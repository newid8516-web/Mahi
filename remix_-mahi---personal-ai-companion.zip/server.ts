import express from 'express';
import type { Request, Response } from 'express';
import cors from 'cors';
import { GoogleGenAI } from "@google/genai";
import { createClient } from "@supabase/supabase-js";
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { WebSocketServer, WebSocket } from 'ws';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProd = process.env.NODE_ENV === 'production';

async function createServer() {
  const app = express();
  const port = 3000;

  app.use(cors());
  app.use(express.json());

  // Lazy initialization of Gemini client
  let genAI: GoogleGenAI | null = null;

  function getGenAI() {
    if (!genAI) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('GEMINI_API_KEY environment variable is required');
      }
      genAI = new GoogleGenAI({ apiKey });
    }
    return genAI;
  }

  // --- Supabase Configuration ---
  let supabaseClientInstance: any = null;
  function getSupabase() {
    if (!supabaseClientInstance) {
      const url = process.env.SUPABASE_URL;
      const key = process.env.SUPABASE_ANON_KEY;
      if (url && key) {
        try {
          supabaseClientInstance = createClient(url, key);
        } catch (e) {
          console.error("Failed to initialize Supabase client: ", e);
        }
      }
    }
    return supabaseClientInstance;
  }

  // General helper to handle Supabase query execution or connectivity failures gracefully
  function handleSupabaseError(res: Response, error: any, context: string) {
    const errorStr = String(error) + (error?.stack || '') + (error?.message || '') + JSON.stringify(error);
    const isNetworkError = 
      error?.message?.includes('fetch') || 
      error?.code === 'ENOTFOUND' || 
      errorStr.includes('ENOTFOUND') || 
      errorStr.includes('fetch failed') || 
      errorStr.includes('TypeError: fetch failed');

    if (isNetworkError) {
      console.log(`[Supabase Status] Fallback active for context: ${context}`);
      res.status(503).json({ error: 'Supabase host unreachable', details: 'Offline fallback active' });
    } else {
      console.log(`[Supabase Status] Query bypassed or fallbacked for context: ${context}`);
      res.status(500).json({ error: 'Database fallback query active' });
    }
  }

  // Supabase connection status check API
  app.get('/api/supabase-status', (req: Request, res: Response) => {
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_ANON_KEY;
    const isConfigured = !!(url && key);
    res.json({
      configured: isConfigured,
      supabaseUrl: url ? `${url.substring(0, 20)}...` : null
    });
  });

  // Get user preferences from Supabase
  app.get('/api/preferences', async (req: Request, res: Response) => {
    try {
      const client = getSupabase();
      if (!client) {
        res.status(404).json({ error: 'Supabase is not configured yet on server.' });
        return;
      }
      const { data, error } = await client
        .from('user_preferences')
        .select('*')
        .eq('id', 'mahendra_preferences')
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (!data) {
        res.json({ status: 'not_found' });
        return;
      }

      // Map snake_case to camelCase for the frontend context
      res.json({
        username: data.username,
        nickname: data.nickname,
        relationship: data.relationship,
        interests: data.interests,
        sassyness: data.sassyness,
        customNotes: data.custom_notes
      });
    } catch (error: any) {
      handleSupabaseError(res, error, 'preferences fetch');
    }
  });

  // Save/Update user preferences to Supabase
  app.post('/api/preferences', async (req: Request, res: Response) => {
    try {
      const client = getSupabase();
      if (!client) {
        res.status(400).json({ error: 'Supabase is not configured on server.' });
        return;
      }
      const prefs = req.body;
      const { error } = await client
        .from('user_preferences')
        .upsert({
          id: 'mahendra_preferences',
          username: prefs.username,
          nickname: prefs.nickname,
          relationship: prefs.relationship,
          interests: prefs.interests,
          sassyness: prefs.sassyness,
          custom_notes: prefs.customNotes,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      res.json({ success: true });
    } catch (error: any) {
      handleSupabaseError(res, error, 'preferences save');
    }
  });

  // Get all chat sessions from Supabase
  app.get('/api/sessions', async (req: Request, res: Response) => {
    try {
      const client = getSupabase();
      if (!client) {
        res.status(404).json({ error: 'Supabase is not configured.' });
        return;
      }
      const { data, error } = await client
        .from('chat_sessions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(15);

      if (error) throw error;

      // Map DB schema to front-end schema keys
      const formatted = (data || []).map((sess: any) => ({
        id: sess.id,
        sessionName: sess.session_name,
        messages: sess.messages || [],
        createdAt: Number(sess.created_at)
      }));

      res.json(formatted);
    } catch (error: any) {
      handleSupabaseError(res, error, 'sessions listing');
    }
  });

  // Create a new session in Supabase
  app.post('/api/sessions', async (req: Request, res: Response) => {
    try {
      const client = getSupabase();
      if (!client) {
        res.status(400).json({ error: 'Supabase is not configured.' });
        return;
      }
      const { id, sessionName, createdAt } = req.body;
      const { error } = await client
        .from('chat_sessions')
        .insert({
          id,
          session_name: sessionName,
          messages: [],
          created_at: createdAt
        });

      if (error) throw error;
      res.json({ success: true, id });
    } catch (error: any) {
      handleSupabaseError(res, error, 'session creation');
    }
  });

  // Append a message to a session in Supabase
  app.post('/api/sessions/message', async (req: Request, res: Response) => {
    try {
      const client = getSupabase();
      if (!client) {
        res.status(400).json({ error: 'Supabase is not configured.' });
        return;
      }
      const { sessionId, sender, text } = req.body;
      
      const { data, error: selectError } = await client
        .from('chat_sessions')
        .select('messages')
        .eq('id', sessionId)
        .maybeSingle();

      if (selectError) throw selectError;

      const currentMessages = data?.messages || [];
      const updatedMessages = [...currentMessages, {
        sender,
        text,
        timestamp: Date.now()
      }];

      const { error: updateError } = await client
        .from('chat_sessions')
        .update({ messages: updatedMessages })
        .eq('id', sessionId);

      if (updateError) throw updateError;
      res.json({ success: true });
    } catch (error: any) {
      handleSupabaseError(res, error, 'append message');
    }
  });

  // Delete session in Supabase
  app.post('/api/sessions/delete', async (req: Request, res: Response) => {
    try {
      const client = getSupabase();
      if (!client) {
        res.status(400).json({ error: 'Supabase is not configured.' });
        return;
      }
      const { sessionId } = req.body;
      const { error } = await client
        .from('chat_sessions')
        .delete()
        .eq('id', sessionId);

      if (error) throw error;
      res.json({ success: true });
    } catch (error: any) {
      handleSupabaseError(res, error, 'delete session');
    }
  });

  // Chat API route
  app.post('/chat', async (req: Request, res: Response) => {
    try {
      const { message } = req.body;

      if (!message) {
         res.status(400).json({ error: 'Message is required' });
         return;
      }

      const ai = getGenAI();
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: message,
      });

      res.json({ reply: response.text });
    } catch (error: any) {
      console.error('Chat error:', error);
      res.status(500).json({ 
        error: 'Failed to generate response', 
        details: error.message 
      });
    }
  });

  if (!isProd) {
    // In development: use Vite middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // In production: serve static files
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = app.listen(port, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${port}`);
  });

  const wss = new WebSocketServer({ server, path: '/live' });

  wss.on('connection', (clientWs) => {
    let session: any = null;
    let isClosed = false;

    clientWs.on('message', async (data) => {
      try {
        const parsed = JSON.parse(data.toString());

        if (parsed.type === 'setup') {
          try {
            const ai = getGenAI();
            session = await ai.live.connect({
              model: parsed.model || "gemini-3.1-flash-live-preview",
              config: parsed.config,
              callbacks: {
                onmessage: (message: any) => {
                  if (clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(JSON.stringify(message));
                  }
                },
                onclose: () => {
                  if (!isClosed) {
                    isClosed = true;
                    clientWs.close();
                  }
                },
                onerror: (err: any) => {
                  console.error("Gemini LIVE API session error:", err);
                  if (clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(JSON.stringify({ type: 'error', error: err?.message || String(err) }));
                  }
                }
              }
            });
          } catch (err: any) {
            console.error("Failed to establish Gemini Live connection:", err);
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'error', error: `Connection failed: ${err.message}` }));
              clientWs.close();
            }
          }
        } else if (session) {
          if (parsed.type === 'realtimeInput') {
            session.sendRealtimeInput(parsed.input);
          } else if (parsed.type === 'toolResponse') {
            session.sendToolResponse(parsed.response);
          }
        }
      } catch (err) {
        console.error("Error processing client ws message:", err);
      }
    });

    clientWs.on('close', () => {
      isClosed = true;
      if (session) {
        try {
          session.close();
        } catch (e) {
          // ignore
        }
        session = null;
      }
    });

    clientWs.on('error', (err) => {
      console.error("Client WS connection error:", err);
    });
  });
}

createServer();
