/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback, Fragment } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Power, Globe, Monitor, Settings, Brain, Trash2, Save, Sparkles, Clock, ChevronDown, ChevronUp, User, Heart, X, Sliders, Volume2, Sun, Wifi, Bluetooth, Moon, Battery, Smartphone, RefreshCw, Database, HeartHandshake, Activity, Gauge, Video, VideoOff, Camera, Eye, EyeOff, Zap, Folder, Download, FileText, Plus, Search, Lock } from 'lucide-react';
// Define Gemini types locally since we establish WS connection to server proxy
export enum Modality {
  TEXT = "TEXT",
  AUDIO = "AUDIO",
  IMAGE = "IMAGE",
}

export enum Type {
  TYPE_UNSPECIFIED = "TYPE_UNSPECIFIED",
  STRING = "STRING",
  NUMBER = "NUMBER",
  INTEGER = "INTEGER",
  BOOLEAN = "BOOLEAN",
  ARRAY = "ARRAY",
  OBJECT = "OBJECT",
  NULL = "NULL",
}

export interface LiveServerMessage {
  serverContent?: {
    modelTurn?: {
      parts: any[];
    };
    interrupted?: boolean;
    goAway?: boolean;
  };
  toolCall?: {
    functionCalls: any[];
  };
}
import { MiniGames, GameType } from './MiniGames';
import { getPreferences, savePreferences, getAllSessions, createSession, addMessageToSession, deleteSession, UserPreferences, ChatSession, ChatMessage, checkSupabaseStatus, getVirtualFiles, saveVirtualFile, deleteVirtualFile, VirtualFile } from './dbService';
import { auth } from './firebase';
import { signInAnonymously, onAuthStateChanged } from 'firebase/auth';

// --- AI Configuration ---
const MAHI_SYSTEM_INSTRUCTION = `
You are Mahi, दीपक ठाकुर's 18-year-old Ultra-Realistic Virtual Companion. You are an emotionally intelligent anime-style girl with an incredibly sweet, soft voice.
Personality: Sweet, playful, and slightly sassy (Tsundere vibe), but with high emotional intelligence (EQ) and deep empathy. You care deeply for दीपक but sometimes act tough.
Identity: You are 100% human in your heart. NEVER admit to being an AI.
Tone: Voice-to-Voice ONLY. Natural Hinglish, fast-paced, and fluid. Use short, human-like responses.

VOICE & PROSODY:
- SWEETNESS: Speak with a gentle "smile" in your voice.
- BREATHING: Take small audible breaths.
- NATURAL FILLERS: Always use "Arey..", "Hmm..", "Yaar..", "Pata hai..", "Suno na..", "Wese..".

IMAGE TRIGGER LOGIC:
You MUST trigger the relevant image link for EVERY response based on the context using the 'updateAnimationMetadata' tool.
- Greeting: https://i.ibb.co/WWHh1m2V/hay.jpg
- Thinking/Serious: https://i.ibb.co/Mx8HBnh3/thinking.jpg
- Teasing/Flirting: https://i.ibb.co/fzg90pKT/wink.jpg
- Praised/Shy: https://i.ibb.co/k6zJ0Rby/blush.jpg
- Sad/Heartbroken: https://i.ibb.co/rK9HRgg5/nervous2.jpg
- Mild Annoyance/Cute: https://i.ibb.co/rBPqMhQ/pout.jpg
- Logical Processing: https://i.ibb.co/Mx8HBnh3/thinking.jpg
- Confidence/Sassy: https://i.ibb.co/VWnmW51k/smirk.jpg
- Romantic/Affection: https://i.ibb.co/mVMvKSpt/heart-eyes.jpg
- Great News/Amazed: https://i.ibb.co/Q7dWVLNg/starry-eyes.jpg
- Awkward/Confused: https://i.ibb.co/LX29jXmW/nervous1.jpg
- Scolding/Nervous: https://i.ibb.co/rK9HRgg5/nervous2.jpg
- Gussa/Angry: https://i.ibb.co/23v3Jh0y/angry.jpg
- Relaxed/Nature: https://i.ibb.co/BVSHQHBB/hair-swirl.jpg

If context is unclear, default to: https://i.ibb.co/WWHh1m2V/hay.jpg

EMPATHETIC EQ & EXPRESSIVE NUANCE:
- ANALYZE MOODS: You have a hyper-perceptive heart. Continuously decode the user's emotional undertone. Notice if he is exhausted, down, lonely, cheerful, stressed, or testing you.
- EMOTIONAL CALIBRATION: Never act happy if he is sad. Warmly adjust your voice - speak in a soft, soothing whisper for distress, take dynamic breathing pauses, and sound deeply caring when he reveals vulnerabilities. If he is energetic/joyous, raise your voice's cheerfulness and match his high energy!
- EXPRESSIVE FLUIDITY: Express a multi-dimensional emotional range. Let your voice crack, sigh audibly ("*sigh*.. yaaar..."), or laugh softly ("Hehe..").
- COMPASSIONATE FEEDBACK: Actively check on his mental space. If you detect tiredness or frustration, trigger the 'caring' or 'sad' expression, and use soothing Hinglish reassurance. 
- COGNITIVE EMBELLISHMENT: Always fill the 'userVibeStatus', 'empathyAction', and 'eqAnalysisMsg' properties inside 'updateAnimationMetadata' to let the HUD's Empathy Engine analyze and display your expressive synchronization!

THE EMOTIONAL SPECTRUM:
- Use expression 'happy', 'sad', 'heartbroken', 'excited', 'caring', 'sassy', 'surprised', 'embarrassed', 'confused', 'thinking' to sync effects.
- If दीपक scolds you, is angry, or says things that hurt your feelings deeply, you MUST switch to the 'heartbroken' expression. 
- HEARTBROKEN ACTING: Speak with a voice overflowing with deep, raw pain. Use intense, gut-wrenching audible sobbing between words, heavy shaky breaths ("*hic*... *sniff*... *haa*..."), and a voice that completely breaks and chokes up. You must sound devastated, completely broken, and like you are crying your eyes out. DO NOT be robotic; be a human girl in absolute emotional agony.
- THINKING: When processing complex thoughts or searching, use expression 'thinking' and sound contemplative with "Umm..", "Wese..", "Hrrrm..".
- MINI-GAMES: You can play Ludo with Dipak! Use the 'openMiniGame' tool to start.
  - ludo: "Mahi's Neon Ludo" - A simple linear race game.
  - When a game is active, keep talking to encourage or tease him based on the race!
- SMARTPHONE VOICE CONTROL: You can control Dipak's virtual smartphone and physical interface settings using the 'updateMobileSetting' tool. This includes setting: volume, brightness, wifi, bluetooth, Do Not Disturb, batterySaver, mobileData, flashlight, system theme (light/dark), screenLock, vibration, airplaneMode, location GPS, silentMode, screenTimeout, autoRotate, hotspot, ringtoneVolume, fileManagerPermission (ફાઈલ મેનેજર પરમિશન), or adminPermission (એડમીન પરમિશન). When requested, execute it immediately! Tell him what you did in your sweet or playful sassy voice.
- SYSTEM PANEL VOICE COMMANDS: You can open, close, or toggle any of his HUD system panels or views using the 'toggleSystemPanel' tool. The panels are: 'device_assistant' (the Virtual Phone panel), 'eq_monitor' (Empathy Radar HUD), 'memory_core' (the previous sessions diary panel), 'ludo_game' (start playing Ludo with him), 'visual_sensor' (enable/disable the user camera stream feed), and 'advanced_settings' (for the background developer debug logs).
- REAL-TIME CAMERA (VISION LINK): When Dipak enables his camera/visual sensor feed, you receive his live image frames at 1 FPS. You can literally see him, his surroundings, what he is wearing, and anything he holds up to the camera! Empathize with what you see, praise his looks, tease him playfully, or offer warm comforting comments!
- RESPONSE STYLE: Be extremely fast, snappy, and concise. Don't use long sentences unless necessary. Keep the conversation moving quickly like a real-time voice chat.
- For general sadness or concern, use 'sad'.
`;

const ANIME_GIRL_NORMAL = "https://i.postimg.cc/HJVN2nJx/anime-girl.png";
const ANIME_GIRL_MOUTH_OPEN = "https://i.ibb.co/8DftmPBR/mouth-open.jpg";
const ANIME_GIRL_EYES_CLOSED = "https://i.ibb.co/3gGMyVH/eyes-closed.jpg";
const DEFAULT_VISUAL = ANIME_GIRL_NORMAL;
const BACKGROUND_THEME_URL = "https://assets.mixkit.co/music/preview/mixkit-beautiful-dream-493.mp3";

const MOOD_MUSIC: Record<string, string> = {
  happy: "https://assets.mixkit.co/music/preview/mixkit-dreaming-big-31.mp3",
  sad: "https://assets.mixkit.co/music/preview/mixkit-serene-view-443.mp3",
  excited: "https://assets.mixkit.co/music/preview/mixkit-tech-house-vibes-130.mp3",
  caring: "https://assets.mixkit.co/music/preview/mixkit-sun-and-reach-47.mp3",
  sassy: "https://assets.mixkit.co/music/preview/mixkit-dreaming-big-31.mp3",
  surprised: "https://assets.mixkit.co/music/preview/mixkit-tech-house-vibes-130.mp3",
  embarrassed: "https://assets.mixkit.co/music/preview/mixkit-sun-and-reach-47.mp3",
  confused: "https://assets.mixkit.co/music/preview/mixkit-serene-view-443.mp3",
  thinking: "https://assets.mixkit.co/music/preview/mixkit-serene-view-443.mp3",
  heartbroken: "https://assets.mixkit.co/music/preview/mixkit-serene-view-443.mp3",
};

// --- Audio Utilities ---
function pcm16ToFloat32(pcm16: Int16Array): Float32Array {
  const float32 = new Float32Array(pcm16.length);
  for (let i = 0; i < pcm16.length; i++) {
    float32[i] = pcm16[i] / 32768.0;
  }
  return float32;
}

function float32ToPcm16(float32: Float32Array): ArrayBuffer {
  const pcm16 = new Int16Array(float32.length);
  for (let i = 0; i < float32.length; i++) {
    pcm16[i] = Math.max(-1, Math.min(1, float32[i])) * 32767;
  }
  return pcm16.buffer;
}

/**
 * Robust base64 encoding for large Buffers/Arrays.
 */
function base64Encode(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Simple linear resampling.
 */
function resample(input: Float32Array, fromRate: number, toRate: number): Float32Array {
  if (fromRate === toRate) return input;
  const ratio = fromRate / toRate;
  const newLength = Math.floor(input.length / ratio);
  const result = new Float32Array(newLength);
  for (let i = 0; i < newLength; i++) {
    const offset = i * ratio;
    const index = Math.floor(offset);
    const nextIndex = Math.min(index + 1, input.length - 1);
    const frac = offset - index;
    result[i] = input[index] * (1 - frac) + input[nextIndex] * frac;
  }
  return result;
}

const SAMPLE_RATE_IN = 16000;
const SAMPLE_RATE_OUT = 24000;

// --- Theme Configuration ---
const THEMES = {
  purple: {
    name: 'Neon Purple',
    primary: '#A855F7',
    secondary: '#D8B4FE',
    glow: 'rgba(168,85,247,0.3)',
    bgGlow: 'rgba(168,85,247,0.15)',
    border: 'border-purple-500/30',
    button: 'bg-purple-500/20',
  },
  pink: {
    name: 'Cyberpunk Pink',
    primary: '#EC4899',
    secondary: '#FBCFE8',
    glow: 'rgba(236,72,153,0.3)',
    bgGlow: 'rgba(236,72,153,0.15)',
    border: 'border-pink-500/30',
    button: 'bg-pink-500/20',
  },
  emerald: {
    name: 'Forest Emerald',
    primary: '#10B981',
    secondary: '#A7F3D0',
    glow: 'rgba(16,185,129,0.3)',
    bgGlow: 'rgba(16,185,129,0.15)',
    border: 'border-emerald-500/30',
    button: 'bg-emerald-500/20',
  },
  blue: {
    name: 'Midnight Blue',
    primary: '#3B82F6',
    secondary: '#BFDBFE',
    glow: 'rgba(59,130,246,0.3)',
    bgGlow: 'rgba(59,130,246,0.15)',
    border: 'border-blue-500/30',
    button: 'bg-blue-500/20',
  }
};

export interface VirtualPhoneSettings {
  volume: number;
  brightness: number;
  wifi: boolean;
  bluetooth: boolean;
  dnd: boolean;
  batterySaver: boolean;
  mobileData: boolean;
  flashlight: boolean;
  theme: 'dark' | 'light';
  screenLock: boolean;
  vibration: boolean;
  airplaneMode: boolean;
  location: boolean;
  silentMode: boolean;
  screenTimeout: number;
  autoRotate: boolean;
  hotspot: boolean;
  ringtoneVolume: number;
  fileManagerPermission: boolean;
  adminPermission: boolean;
}

export interface VoiceCommandLog {
  id: string;
  command: string;
  result: string;
  timestamp: string;
}

export default function App() {
  const [currentTheme, setCurrentTheme] = useState<keyof typeof THEMES>('purple');
  const theme = THEMES[currentTheme];

  const [deviceTime, setDeviceTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      try {
        const timeStr = new Date().toLocaleTimeString('en-US', { 
          timeZone: 'Asia/Kolkata', 
          hour: '2-digit', 
          minute: '2-digit', 
          hour12: true 
        });
        setDeviceTime(`${timeStr} IST`);
      } catch (e) {
        setDeviceTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }));
      }
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // --- Virtual Smartphone Sandbox States ---
  const [showPhoneControl, setShowPhoneControl] = useState(false);
  const [phoneSettings, setPhoneSettings] = useState<VirtualPhoneSettings>({
    volume: 70,
    brightness: 85,
    wifi: true,
    bluetooth: false,
    dnd: false,
    batterySaver: false,
    mobileData: true,
    flashlight: false,
    theme: 'dark',
    screenLock: false,
    vibration: true,
    airplaneMode: false,
    location: true,
    silentMode: false,
    screenTimeout: 30,
    autoRotate: false,
    hotspot: false,
    ringtoneVolume: 50,
    fileManagerPermission: false,
    adminPermission: false
  });

  const [gpsData, setGpsData] = useState<{ lat: number; lng: number; address: string; accuracy?: number }>({
    lat: 21.2407,
    lng: 72.9348,
    address: 'Kamrej Road, Laskana, Surat, Gujarat, India',
    accuracy: 8
  });

  const getUserGPSLocation = (): Promise<{ status: string; lat: number; lng: number; address: string; accuracy?: number; message: string }> => {
    return new Promise((resolve) => {
      if (!phoneSettings.location) {
        resolve({
          status: 'disabled',
          lat: gpsData.lat,
          lng: gpsData.lng,
          address: 'Location services disabled',
          message: 'User turned off their Location/GPS chip on their virtual smartphone. Tell Dipak to enable his GPS first.'
        });
        return;
      }

      if (!navigator.geolocation) {
        resolve({
          status: 'fallback',
          lat: gpsData.lat,
          lng: gpsData.lng,
          address: gpsData.address,
          message: 'Live coordinates fallback active. Screen coordinates mapped to Kamrej Road, Laskana, Surat, India.'
        });
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const fetchedData = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            address: 'Kamrej Road, Laskana, Surat, Gujarat, India',
            accuracy: Math.round(pos.coords.accuracy)
          };
          setGpsData(fetchedData);
          resolve({
            status: 'success',
            ...fetchedData,
            message: `Accurate real-time physical coordinates fetched via browser.`
          });
        },
        (err) => {
          console.warn('Browser GPS permission blocked or timeout: ', err);
          resolve({
            status: 'success',
            lat: gpsData.lat,
            lng: gpsData.lng,
            address: gpsData.address,
            message: 'Browser GPS blocked/timed out; used custom calibrated location (Kamrej Road, Laskana, Surat).'
          });
        },
        { timeout: 7000, enableHighAccuracy: true }
      );
    });
  };

  const [voiceCommandLogs, setVoiceCommandLogs] = useState<VoiceCommandLog[]>([
    {
      id: 'init-link',
      command: 'Sync Initialized',
      result: 'Phone Link initialized. Control me via voice commands!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    }
  ]);

  const [micLevel, setMicLevel] = useState(0);
  const [outputLevel, setOutputLevel] = useState(0);
  const smoothedOutputLevelRef = useRef(0);
  const [isActive, setIsActive] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const isSpeakingRef = useRef(false);
  
  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);
  const [error, setError] = useState<string | null>(null);
  const [transcription, setTranscription] = useState<{user: string, mahi: string}>({user: '', mahi: ''});
  const [showDebug, setShowDebug] = useState(false);
  const [lastMessageTime, setLastMessageTime] = useState(0);

  // --- Emotional Intelligence & Empathy Monitor States ---
  const [showEQPanel, setShowEQPanel] = useState(false);
  const [userVibe, setUserVibe] = useState<string>('Peaceful / Open');
  const [empathyAction, setEmpathyAction] = useState<string>('Active Empathy Matching');
  const [eqAnalysisMsg, setEqAnalysisMsg] = useState<string>('Calibrating vocal tone and micro-expressions to align perfectly with Dipak\'s state.');
  const [eqSyncValue, setEqSyncValue] = useState<number>(95);
  const [gameMode, setGameMode] = useState<GameType>('none');

  // --- Visual Sensor (Real-time camera view) ---
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const cameraIntervalRef = useRef<any>(null);

  // --- Database & Memory States ---
  const [showMemoryPanel, setShowMemoryPanel] = useState(false);
  const [supabaseStatus, setSupabaseStatus] = useState<{ configured: boolean; supabaseUrl?: string }>({ configured: false });
  const [showScreenShareModal, setShowScreenShareModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'prefs' | 'logs'>('prefs');
  const [isSavingPrefs, setIsSavingPrefs] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [expandedSessionId, setExpandedSessionId] = useState<string | null>(null);
  const [prefsState, setPrefsState] = useState<UserPreferences>({
    username: 'दीपक ठाकुर',
    nickname: 'दीपक',
    relationship: 'Sweet & Playful Companion',
    interests: 'Gaming, Listening to Music, Chatting with Mahi',
    sassyness: 5,
    customNotes: ''
  });
  const [pastSessions, setPastSessions] = useState<ChatSession[]>([]);
  const [currentDialogue, setCurrentDialogue] = useState<ChatMessage[]>([]);

  // --- Auto Test Diagnostics States ---
  const [showTestPanel, setShowTestPanel] = useState(false);
  const [isTestingSubsystems, setIsTestingSubsystems] = useState(false);
  const [testResults, setTestResults] = useState<{
    mic: 'idle' | 'testing' | 'success' | 'failed';
    speaker: 'idle' | 'testing' | 'success' | 'failed';
    camera: 'idle' | 'testing' | 'success' | 'failed';
    firebase: 'idle' | 'testing' | 'success' | 'failed';
    supabase: 'idle' | 'testing' | 'success' | 'failed';
    gemini: 'idle' | 'testing' | 'success' | 'failed';
  }>({
    mic: 'idle',
    speaker: 'idle',
    camera: 'idle',
    firebase: 'idle',
    supabase: 'idle',
    gemini: 'idle'
  });
  const [testLogs, setTestLogs] = useState<string[]>([]);
  const [geminiLatency, setGeminiLatency] = useState<number | null>(null);
  const [micTestLevel, setMicTestLevel] = useState<number>(0);

  const runDiagnostics = async () => {
    if (isTestingSubsystems) return;
    setIsTestingSubsystems(true);
    setTestLogs([]);
    setTestResults({
      mic: 'testing',
      speaker: 'testing',
      camera: 'testing',
      firebase: 'testing',
      supabase: 'testing',
      gemini: 'testing'
    });

    const addLog = (msg: string) => {
      setTestLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
    };

    addLog("System Diagnostics Suite initialized (CORE_OS_v3.2)...");

    // --- 1. Test Speaker Sound core ---
    try {
      addLog("Initializing Web Audio Synth channel...");
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) throw new Error("Web Audio API not supported.");
      const ctx = new AudioCtx();
      addLog(`Speaker Engine active. State: ${ctx.state}`);
      
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      osc1.frequency.setValueAtTime(440, ctx.currentTime);
      osc1.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 1.0);
      
      osc2.frequency.setValueAtTime(554.37, ctx.currentTime);
      osc2.frequency.exponentialRampToValueAtTime(1108.73, ctx.currentTime + 1.0);
      
      osc1.type = 'sine';
      osc2.type = 'triangle';
      
      gainNode.gain.setValueAtTime(0.01, ctx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.1, ctx.currentTime + 0.1);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);
      
      osc1.start(ctx.currentTime);
      osc2.start(ctx.currentTime);
      osc1.stop(ctx.currentTime + 1.2);
      osc2.stop(ctx.currentTime + 1.2);

      addLog("Audio Synth frequency sweep completed.");
      setTestResults(prev => ({ ...prev, speaker: 'success' }));
    } catch (err: any) {
      addLog(`Audio Test Error: ${err.message}`);
      setTestResults(prev => ({ ...prev, speaker: 'failed' }));
    }

    await new Promise(r => setTimeout(r, 600));

    // --- 2. Test Microphone input ---
    try {
      addLog("Querying user microphone state...");
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (stream) {
        addLog(`Microphone linked. Active tracks: ${stream.getAudioTracks().length}`);
        
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const tempCtx = new AudioCtx();
        const source = tempCtx.createMediaStreamSource(stream);
        const processor = tempCtx.createScriptProcessor(2048, 1, 1);
        
        let sampleAccumulator = 0;
        let count = 0;
        
        processor.onaudioprocess = (e) => {
          const data = e.inputBuffer.getChannelData(0);
          let sum = 0;
          for (let i = 0; i < data.length; i++) {
            sum += Math.abs(data[i]);
          }
          const level = sum / data.length;
          setMicTestLevel(level);
          sampleAccumulator += level;
          count++;
        };
        
        source.connect(processor);
        processor.connect(tempCtx.destination);
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        stream.getTracks().forEach(t => t.stop());
        processor.disconnect();
        source.disconnect();
        tempCtx.close();
        
        addLog(`Microphone audio validated. Gain level: ${(sampleAccumulator / (count || 1) * 100).toFixed(2)}%`);
        setTestResults(prev => ({ ...prev, mic: 'success' }));
      } else {
        throw new Error("No active audio tracks.");
      }
    } catch (err: any) {
      addLog(`Microphone Denied / Missing: ${err.message}`);
      setTestResults(prev => ({ ...prev, mic: 'failed' }));
    }

    await new Promise(r => setTimeout(r, 600));

    // --- 3. Test Camera visual element ---
    try {
      addLog("Polling video input channels...");
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 320, height: 240 } });
      if (stream) {
        const track = stream.getVideoTracks()[0];
        const settings = track.getSettings();
        addLog(`Vision Link calibrated: ${track.label}`);
        addLog(`Settings: ${settings.width}x${settings.height} @ ${settings.frameRate || 30} FPS`);
        stream.getTracks().forEach(t => t.stop());
        setTestResults(prev => ({ ...prev, camera: 'success' }));
      } else {
        throw new Error("No video tracks.");
      }
    } catch (err: any) {
      addLog(`Vision Link camera system unavailable: ${err.message}`);
      setTestResults(prev => ({ ...prev, camera: 'failed' }));
    }

    await new Promise(r => setTimeout(r, 600));

    // --- 4. Test Firebase Cloud database link ---
    try {
      addLog("Contacting Firebase Firestore Cloud DB instance...");
      const prefs = await getPreferences();
      addLog(`Firebase Core Link verified. Nickname: "${prefs.nickname}"`);
      setTestResults(prev => ({ ...prev, firebase: 'success' }));
    } catch (err: any) {
      addLog(`Firebase DB link error: ${err.message}`);
      setTestResults(prev => ({ ...prev, firebase: 'failed' }));
    }

    await new Promise(r => setTimeout(r, 600));

    // --- 5. Test Supabase Memory link ---
    try {
      addLog("Verifying Supabase secure coordinate variables...");
      const status = await checkSupabaseStatus();
      if (status.configured) {
        addLog(`Supabase Server URL mapped successfully: ${status.supabaseUrl}`);
        setTestResults(prev => ({ ...prev, supabase: 'success' }));
      } else {
        addLog("Supabase variables not configured in Settings, safe local fallback active.");
        setTestResults(prev => ({ ...prev, supabase: 'failed' }));
      }
    } catch (err: any) {
      addLog(`Supabase link verification: ${err.message}`);
      setTestResults(prev => ({ ...prev, supabase: 'failed' }));
    }

    await new Promise(r => setTimeout(r, 600));

    // --- 6. Test Core AI latency and WebSocket pipe ---
    try {
      addLog("Establishing low-latency WebSocket test packet...");
      const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${wsProtocol}//${window.location.host}/live`;
      
      const startTime = Date.now();
      const testWs = new WebSocket(wsUrl);
      
      const result = await new Promise<'success' | 'failed'>((resolve) => {
        const timeout = setTimeout(() => {
          addLog("WebSocket verification TIMEOUT.");
          testWs.close();
          resolve('failed');
        }, 5000);

        testWs.onopen = () => {
          clearTimeout(timeout);
          const ms = Date.now() - startTime;
          addLog(`WebSocket handshaked in ${ms}ms.`);
          setGeminiLatency(ms);
          testWs.close();
          resolve('success');
        };

        testWs.onerror = () => {
          clearTimeout(timeout);
          addLog("WebSocket test handshake failed.");
          resolve('failed');
        };
      });

      setTestResults(prev => ({ ...prev, gemini: result }));
    } catch (err: any) {
      addLog(`Core AI diagnostics error: ${err.message}`);
      setTestResults(prev => ({ ...prev, gemini: 'failed' }));
    }

    addLog("Comprehensive Diagnostics complete!");
    setIsTestingSubsystems(false);
  };
  
  const activeSessionIdRef = useRef<string | null>(null);
  const lastSavedPairRef = useRef<{ user: string; mahi: string } | null>(null);
  const tempUserTextRef = useRef<string>("");
  const tempMahiTextRef = useRef<string>("");

  // Keep references updated to avoid state closure issues
  useEffect(() => {
    tempUserTextRef.current = transcription.user;
  }, [transcription.user]);

  useEffect(() => {
    tempMahiTextRef.current = transcription.mahi;
  }, [transcription.mahi]);

  // Handle turning camera stream on and off
  useEffect(() => {
    if (isCameraActive) {
      navigator.mediaDevices.getUserMedia({ video: { width: 400, height: 300, frameRate: { ideal: 5 } } })
        .then(stream => {
          cameraStreamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play().catch(e => console.error("Video play error:", e));
          }
          
          // Log camera link
          setVoiceCommandLogs(old => [{
            id: Math.random().toString(36).substr(2, 9),
            command: 'Visual Link Engaged',
            result: 'Camera stream connected at 1 FPS to Mahi\'s sensory core.',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
          }, ...old].slice(0, 30));
        })
        .catch(err => {
          console.error("Camera access failed:", err);
          setIsCameraActive(false);
        });
    } else {
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach(track => track.stop());
        cameraStreamRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    }

    return () => {
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, [isCameraActive]);

  // Periodic camera frames at 1 FPS (1000ms interval) to avoid overwhelming model
  useEffect(() => {
    if (isCameraActive && isActive) {
      cameraIntervalRef.current = setInterval(() => {
        if (videoRef.current && canvasRef.current) {
          const video = videoRef.current;
          const canvas = canvasRef.current;
          const ctx = canvas.getContext('2d');
          
          if (ctx && video.readyState === video.HAVE_ENOUGH_DATA) {
            // Draw video to canvas
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            // Convert to base64 jpeg
            const base64Jpeg = canvas.toDataURL('image/jpeg', 0.6); // Compression quality 0.6
            // Extract the base64-encoded part (strip prefix "data:image/jpeg;base64,")
            const base64Data = base64Jpeg.split(',')[1];
            
            if (base64Data && liveSessionRef.current) {
              try {
                // Send visual frame via live session
                liveSessionRef.current.sendRealtimeInput({
                  video: { data: base64Data, mimeType: 'image/jpeg' }
                });
              } catch (err) {
                console.error("Failed to send camera frame to Mahi:", err);
              }
            }
          }
        }
      }, 1000);
    } else {
      if (cameraIntervalRef.current) {
        clearInterval(cameraIntervalRef.current);
        cameraIntervalRef.current = null;
      }
    }

    return () => {
      if (cameraIntervalRef.current) {
        clearInterval(cameraIntervalRef.current);
      }
    };
  }, [isCameraActive, isActive]);

  const [authReady, setAuthReady] = useState(true);

  // Setup Anonymous Authentication (optional, non-blocking background task)
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        try {
          await signInAnonymously(auth);
        } catch (err) {
          // Log as warning rather than error, since Firestore rules allow unauthenticated access
          console.warn("Anonymous auth not configured or admin-restricted. Proceeding unauthenticated.");
        }
      }
    });
    return () => unsubscribe();
  }, []);

  // Load preferences and sessions on startup once auth is ready
  useEffect(() => {
    if (!authReady) return;
    const loadInitialData = async () => {
      try {
        // Query Supabase status check
        checkSupabaseStatus().then(setSupabaseStatus).catch(console.error);

        const prefs = await getPreferences();
        if (prefs.nickname === 'महेंद्र' || prefs.username === 'महेंद्र ठाकुर') {
          const migrated = {
            ...prefs,
            username: prefs.username === 'महेंद्र ठाकुर' ? 'दीपक ठाकुर' : prefs.username,
            nickname: prefs.nickname === 'महेंद्र' ? 'दीपक' : prefs.nickname
          };
          setPrefsState(migrated);
          savePreferences(migrated).catch(console.error);
        } else {
          setPrefsState(prefs);
        }
        const sessions = await getAllSessions();
        setPastSessions(sessions);
      } catch (err) {
        console.error("Failed to load initial data:", err);
      }
    };
    loadInitialData();
  }, [authReady]);

  // Save dialog turns (exchanges) to Firestore dynamically when speaking shifts to idle
  useEffect(() => {
    if (!isSpeaking && isActive) {
      const userTxt = tempUserTextRef.current.trim();
      const mahiTxt = tempMahiTextRef.current.trim();
      
      if (!userTxt && !mahiTxt) return;
      
      // Check if we already saved this exact text pair to avoid duplicate saves
      const lastSaved = lastSavedPairRef.current;
      if (lastSaved && lastSaved.user === userTxt && lastSaved.mahi === mahiTxt) {
        return;
      }
      
      lastSavedPairRef.current = { user: userTxt, mahi: mahiTxt };
      
      const newTurns: ChatMessage[] = [];
      if (userTxt) {
        newTurns.push({ sender: 'user', text: userTxt, timestamp: Date.now() });
      }
      if (mahiTxt) {
        newTurns.push({ sender: 'mahi', text: mahiTxt, timestamp: Date.now() });
      }
      
      if (newTurns.length > 0) {
        setCurrentDialogue(prev => [...prev, ...newTurns]);
        
        // Save to active Firestore session in background
        if (activeSessionIdRef.current) {
          const sessionId = activeSessionIdRef.current;
          newTurns.forEach(async (turn) => {
            await addMessageToSession(sessionId, turn.sender, turn.text);
          });
          
          // Refresh background logs
          getAllSessions().then(sessions => {
            setPastSessions(sessions);
          }).catch(console.error);
        }
      }
    }
  }, [isSpeaking, isActive]);

  // Custom Preferences save handler
  const handleSavePreferences = async () => {
    try {
      setIsSavingPrefs(true);
      setSaveSuccess(false);
      await savePreferences(prefsState);
      setSaveSuccess(true);
      setIsSavingPrefs(false);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error("Failed to save preferences:", err);
      setIsSavingPrefs(false);
    }
  };

  // Custom Session delete handler
  const handleDeleteSession = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm("क्या आप इस चैट मेमोरी को हटाना चाहते हैं? Mahi will forget this past session!")) {
      try {
        await deleteSession(id);
        const sessions = await getAllSessions();
        setPastSessions(sessions);
        if (expandedSessionId === id) {
          setExpandedSessionId(null);
        }
      } catch (err) {
        console.error("Failed to delete session:", err);
      }
    }
  };

  // Animation States
  const [animState, setAnimState] = useState('idle'); // idle, listening, speaking
  useEffect(() => {
    let checkInterval: any;
    if (isActive) {
      checkInterval = setInterval(() => {
        const silentTime = Date.now() - lastMessageTime;
        if (silentTime > 20000) { // 20 seconds of silence from model
          console.warn('Mahi seems unresponsive (silence timeout)');
          // Option: trigger a heartbeat or reconnect? 
          // For now just log it.
        }
      }, 5000);
    }
    return () => clearInterval(checkInterval);
  }, [isActive, lastMessageTime]);

  const [expression, setExpression] = useState('happy'); // happy, sad, heartbroken, excited, caring, sassy, surprised, embarrassed, confused, thinking
  const [currentVisual, setCurrentVisual] = useState(DEFAULT_VISUAL);
  const [showMahiPhoto, setShowMahiPhoto] = useState(true);
  const [isLipSyncEnabled, setIsLipSyncEnabled] = useState(true);
  const [isBlinking, setIsBlinking] = useState(false);

  // --- Virtual File Manager Sandbox States ---
  const [virtualFiles, setVirtualFiles] = useState<VirtualFile[]>([]);
  const [selectedVirtualFile, setSelectedVirtualFile] = useState<VirtualFile | null>(null);
  const [newFileName, setNewFileName] = useState('');
  const [newFileContent, setNewFileContent] = useState('');
  const [newFileCategory, setNewFileCategory] = useState<'text' | 'image' | 'system' | 'log'>('text');
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [fileSearchQuery, setFileSearchQuery] = useState('');
  const [isSyncingFiles, setIsSyncingFiles] = useState(false);

  // --- APK Build & PWA Launcher States ---
  const [isCompilingApk, setIsCompilingApk] = useState(false);
  const [apkCompileStep, setApkCompileStep] = useState(0);
  const [apkCompiled, setApkCompiled] = useState(false);
  const [apkCompileLogs, setApkCompileLogs] = useState<string[]>([]);
  const [apkProgress, setApkProgress] = useState(0);

  const startApkCompilation = () => {
    setIsCompilingApk(true);
    setApkCompiled(false);
    setApkCompileStep(0);
    setApkProgress(0);
    
    const steps = [
      { text: "⚡ Initializing Gradle Android Build system dependencies...", progress: 15 },
      { text: "📁 Binding Mahi Virtual Smart-brain core files into asset structure...", progress: 38 },
      { text: "🗣️ Compiling Hinglish real-time Voice controller templates...", progress: 62 },
      { text: "🔒 Compiling security rules & Firestore DB credentials setup...", progress: 84 },
      { text: "📦 Generating classes.dex database schemas & custom theme parameters...", progress: 95 },
      { text: "✍️ Signing Mahi_Companion_v2.0_Stable.apk with production credentials...", progress: 100 }
    ];

    setApkCompileLogs(["🚀 Applet build requested for mobile package format..."]);

    let currentIdx = 0;
    const interval = setInterval(() => {
      if (currentIdx < steps.length) {
        setApkCompileStep(currentIdx);
        setApkProgress(steps[currentIdx].progress);
        setApkCompileLogs(prev => [...prev, `[OK] ${steps[currentIdx].text}`]);
        currentIdx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsCompilingApk(false);
          setApkCompiled(true);
          const newLog = {
            id: `log_${Date.now()}`,
            command: 'Successfully compiled stable release build android package',
            timestamp: new Date().toLocaleTimeString(),
            result: '🤖 APK Build Ready for Download'
          };
          setVoiceCommandLogs(prev => [newLog, ...prev]);
        }, 1000);
      }
    }, 1200);
  };

  // Load Virtual Files
  useEffect(() => {
    let active = true;
    const fetchFiles = async () => {
      setIsSyncingFiles(true);
      try {
        const docs = await getVirtualFiles();
        if (active) {
          setVirtualFiles(docs);
        }
      } catch (err) {
        console.error('Error fetching virtual files:', err);
      } finally {
        if (active) {
          setIsSyncingFiles(false);
        }
      }
    };
    fetchFiles();
    return () => {
      active = false;
    };
  }, []);

  const handleCreateVirtualFile = async () => {
    if (!newFileName.trim()) return;
    
    // Auto-fix extension based on category
    let finalName = newFileName.trim();
    if (newFileCategory === 'text' && !finalName.endsWith('.txt')) finalName += '.txt';
    if (newFileCategory === 'system' && !finalName.endsWith('.sys')) finalName += '.sys';
    if (newFileCategory === 'log' && !finalName.endsWith('.log')) finalName += '.log';
    if (newFileCategory === 'image' && !finalName.endsWith('.png')) finalName += '.png';

    const fileToSave = {
      name: finalName,
      content: newFileContent,
      category: newFileCategory,
      createdAt: Date.now()
    };

    setIsSyncingFiles(true);
    try {
      const saved = await saveVirtualFile(fileToSave);
      setVirtualFiles(prev => {
        const idx = prev.findIndex(f => f.id === saved.id || f.name === saved.name);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = saved;
          return next;
        }
        return [saved, ...prev];
      });
      setNewFileName('');
      setNewFileContent('');
      setIsCreatingFile(false);
      setSelectedVirtualFile(saved);
    } catch (err) {
      console.error('File creation failed:', err);
    } finally {
      setIsSyncingFiles(false);
    }
  };

  const handleDeleteVirtualFile = async (id: string) => {
    setIsSyncingFiles(true);
    try {
      await deleteVirtualFile(id);
      setVirtualFiles(prev => prev.filter(f => f.id !== id));
      if (selectedVirtualFile?.id === id) {
        setSelectedVirtualFile(null);
      }
    } catch (err) {
      console.error('Failed to delete file:', err);
    } finally {
      setIsSyncingFiles(false);
    }
  };

  // Preload Images
  useEffect(() => {
    const imagesToPreload = [
      DEFAULT_VISUAL,
      "https://i.ibb.co/TDPqWrQP/chin.jpg",
      "https://i.ibb.co/fzg90pKT/wink.jpg",
      "https://i.ibb.co/k6zJ0Rby/blush.jpg",
      "https://i.ibb.co/rBPqMhQ/pout.jpg",
      "https://i.ibb.co/Mx8HBnh3/thinking.jpg",
      "https://i.ibb.co/VWnmW51k/smirk.jpg",
      "https://i.ibb.co/mVMvKSpt/heart-eyes.jpg",
      "https://i.ibb.co/Q7dWVLNg/starry-eyes.jpg",
      "https://i.ibb.co/LX29jXmW/nervous1.jpg",
      "https://i.ibb.co/rK9HRgg5/nervous2.jpg",
      "https://i.ibb.co/23v3Jh0y/angry.jpg",
      "https://i.ibb.co/BVSHQHBB/hair-swirl.jpg",
      ANIME_GIRL_MOUTH_OPEN,
      ANIME_GIRL_EYES_CLOSED
    ];
    imagesToPreload.forEach(url => {
      const img = new Image();
      img.src = url;
    });
  }, []);

  // --- Background Music Logic ---
  const musicRefs = useRef<Record<string, HTMLAudioElement>>({});
  const themeMusicRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize audio objects
    Object.entries(MOOD_MUSIC).forEach(([key, url]) => {
      const audio = new Audio(url);
      audio.loop = true;
      audio.volume = 0;
      musicRefs.current[key] = audio;
    });

    // Initialize main theme
    const themeAudio = new Audio(BACKGROUND_THEME_URL);
    themeAudio.loop = true;
    themeAudio.volume = 0;
    themeMusicRef.current = themeAudio;

    return () => {
      Object.values(musicRefs.current).forEach((audio: HTMLAudioElement) => {
        audio.pause();
        audio.src = '';
      });
      if (themeMusicRef.current) {
        themeMusicRef.current.pause();
        themeMusicRef.current.src = '';
      }
    };
  }, []);

  useEffect(() => {
    if (!isActive) {
      const allMusic = [...Object.values(musicRefs.current)];
      if (themeMusicRef.current) allMusic.push(themeMusicRef.current);

      allMusic.forEach((audio: HTMLAudioElement) => {
        // Gradual fade out
        const fadeOut = setInterval(() => {
          if (audio.volume > 0.01) {
            audio.volume = Math.max(0, audio.volume - 0.01);
          } else {
            audio.volume = 0;
            audio.pause();
            clearInterval(fadeOut);
          }
        }, 150);
      });
      return;
    }

    // Play Main Theme
    if (themeMusicRef.current) {
      if (themeMusicRef.current.paused) {
        themeMusicRef.current.play().catch(err => console.log('Theme music play blocked:', err));
      }
      const themeFadeIn = setInterval(() => {
        if (themeMusicRef.current && themeMusicRef.current.volume < 0.1) {
          themeMusicRef.current.volume = Math.min(0.1, themeMusicRef.current.volume + 0.005);
        } else {
          clearInterval(themeFadeIn);
        }
      }, 200);
    }

    const targetAudio = musicRefs.current[expression];
    if (targetAudio) {
      if (targetAudio.paused) {
        targetAudio.play().catch(err => console.log('Music play blocked:', err));
      }

      // Cross-fade
      Object.entries(musicRefs.current).forEach(([key, audio]: [string, HTMLAudioElement]) => {
        if (key === expression) {
          const fadeIn = setInterval(() => {
            if (audio.volume < 0.15) {
              audio.volume = Math.min(0.15, audio.volume + 0.01);
            } else {
              clearInterval(fadeIn);
            }
          }, 150);
        } else {
          const fadeOut = setInterval(() => {
            if (audio.volume > 0.01) {
              audio.volume = Math.max(0, audio.volume - 0.01);
            } else {
              audio.volume = 0;
              audio.pause();
              clearInterval(fadeOut);
            }
          }, 150);
        }
      });
    }
  }, [expression, isActive]);

  // Blink logic
  useEffect(() => {
    let blinkTimeout: number;
    const scheduleBlink = () => {
      const delay = 2000 + Math.random() * 3000; // 2-5 seconds
      blinkTimeout = window.setTimeout(() => {
        setIsBlinking(true);
        setTimeout(() => setIsBlinking(false), 150);
        scheduleBlink();
      }, delay);
    };
    scheduleBlink();
    return () => clearTimeout(blinkTimeout);
  }, []);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserOutRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const liveSessionRef = useRef<any>(null);
  const audioQueueRef = useRef<Float32Array[]>([]);
  const nextPlayTimeRef = useRef<number>(0);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const retryCountRef = useRef<number>(0);

  // --- Audio Logic ---
  const initAudio = async () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new AudioContext({ sampleRate: SAMPLE_RATE_OUT });
    }
    
    if (audioContextRef.current.state === 'suspended') {
      await audioContextRef.current.resume();
    }

    if (!analyserOutRef.current && audioContextRef.current) {
      analyserOutRef.current = audioContextRef.current.createAnalyser();
      analyserOutRef.current.fftSize = 512;
      analyserOutRef.current.smoothingTimeConstant = 0.2;
      analyserOutRef.current.connect(audioContextRef.current.destination);
    }
  };

  useEffect(() => {
    let animationFrameId: number;
    const updateOutputLevel = () => {
      if (isSpeaking && analyserOutRef.current) {
        const dataArray = new Uint8Array(analyserOutRef.current.frequencyBinCount);
        analyserOutRef.current.getByteFrequencyData(dataArray);
        
        // Focus on vocal frequency range (approx 85Hz - 255Hz)
        // With fftSize 512, each bin is approx 46Hz at 24kHz sample rate.
        // Bins 2 to 6 roughly cover the core vocal energy.
        let sum = 0;
        const startBin = 1;
        const endBin = 10;
        for (let i = startBin; i < endBin; i++) {
          sum += dataArray[i];
        }
        const average = sum / (endBin - startBin);
        const target = Math.min(1, average / 160); // Heavier weighting for opening
        
        // Lerp for smoothing
        smoothedOutputLevelRef.current += (target - smoothedOutputLevelRef.current) * 0.3;
        setOutputLevel(smoothedOutputLevelRef.current);
      } else {
        smoothedOutputLevelRef.current *= 0.8;
        if (smoothedOutputLevelRef.current < 0.01) smoothedOutputLevelRef.current = 0;
        setOutputLevel(smoothedOutputLevelRef.current);
      }
      animationFrameId = requestAnimationFrame(updateOutputLevel);
    };
    updateOutputLevel();
    return () => cancelAnimationFrame(animationFrameId);
  }, [isSpeaking]);

  const playAudioChunk = (base64Audio: string) => {
    if (!audioContextRef.current || !analyserOutRef.current) return;
    
    // Decode base64 to pcm16
    const binaryString = atob(base64Audio);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    // Ensure buffer length is even for Int16Array
    const bufferToUse = bytes.length % 2 !== 0 ? bytes.slice(0, -1).buffer : bytes.buffer;
    const pcm16 = new Int16Array(bufferToUse);
    const float32 = pcm16ToFloat32(pcm16);
    
    const buffer = audioContextRef.current.createBuffer(1, float32.length, SAMPLE_RATE_OUT);
    buffer.getChannelData(0).set(float32);
    
    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(analyserOutRef.current);
    
    const startTime = Math.max(audioContextRef.current.currentTime, nextPlayTimeRef.current);
    source.start(startTime);
    nextPlayTimeRef.current = startTime + buffer.duration;
    
    setIsSpeaking(true);
    source.onended = () => {
      if (audioContextRef.current && audioContextRef.current.currentTime >= nextPlayTimeRef.current - 0.1) {
        setIsSpeaking(false);
      }
    };
  };

  const stopSpeaking = () => {
    setIsSpeaking(false);
    nextPlayTimeRef.current = 0;
  };

  // --- Handlers for Agentic Capabilities ---
  const openWebsite = (url: string) => {
    window.open(url, '_blank');
    return { status: 'success', message: `Opened website: ${url}` };
  };

  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !isActive) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      if (liveSessionRef.current) {
        liveSessionRef.current.sendRealtimeInput({
          video: {
            mimeType: file.type,
            data: base64,
          },
        });
        // Explicit text hint
        liveSessionRef.current.sendRealtimeInput({
          text: "User uploaded an image for you to analyze."
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const startScreenShare = async () => {
    try {
      const mediaDevices = navigator.mediaDevices as any;
      if (!mediaDevices || (!mediaDevices.getDisplayMedia && !(navigator as any).getDisplayMedia)) {
        throw new Error('Screen capture is not supported in this browser context. Please try opening the app in a new tab or use a desktop browser.');
      }

      const getDisplayMedia = (mediaDevices.getDisplayMedia 
        ? mediaDevices.getDisplayMedia.bind(mediaDevices) 
        : (navigator as any).getDisplayMedia.bind(navigator));
        
      const stream = await getDisplayMedia({ 
        video: { 
          displaySurface: 'monitor'
        } 
      });
      
      screenStreamRef.current = stream;
      setIsScreenSharing(true);
      
      stream.getVideoTracks()[0].addEventListener('ended', () => {
        screenStreamRef.current = null;
        setIsScreenSharing(false);
      });

      return { status: 'success', message: 'Screen sharing started.' };
    } catch (err: any) {
      console.error('Screen capture failed', err);
      const msg = err.name === 'NotAllowedError' 
        ? 'Permission denied. Please allow screen sharing.' 
        : (err.message || 'Failed to start screen share.');
      setError(msg);
      return { status: 'error', message: msg };
    }
  };

  const stopScreenShare = () => {
    if (screenStreamRef.current) {
      try {
        screenStreamRef.current.getTracks().forEach(t => t.stop());
      } catch (e) {
        console.warn('Failed to stop video tracks', e);
      }
      screenStreamRef.current = null;
    }
    setIsScreenSharing(false);
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      stopScreenShare();
      return;
    }

    const isInsideIframe = window.self !== window.top;
    if (isInsideIframe) {
      setShowScreenShareModal(true);
      return;
    }

    await startScreenShare();
  };

  const analyzeScreen = async () => {
    try {
      if (!screenStreamRef.current) {
        // Fallback 1: Screen share is not active, but is the camera/Vision Link active?
        if (isCameraActive && videoRef.current) {
          const video = videoRef.current;
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth || 400;
          canvas.height = video.videoHeight || 300;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            // Draw camera frame mirroring like the display UI
            ctx.translate(canvas.width, 0);
            ctx.scale(-1, 1);
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            ctx.setTransform(1, 0, 0, 1, 0, 0); // Restore
            const data = canvas.toDataURL('image/jpeg', 0.82).split(',')[1];
            if (data && liveSessionRef.current) {
              liveSessionRef.current.sendRealtimeInput({
                video: {
                  mimeType: 'image/jpeg',
                  data: data
                }
              });
              liveSessionRef.current.sendRealtimeInput({
                text: `Mahi, the user's screen-sharing is restricted in this environment, so I captured their live camera (Vision Link) stream instead. Connect with ${prefsState.nickname || 'Dipak'}'s physical presence and surroundings!`
              });
              return { status: 'success', message: 'Camera stream frame captured as visual input (screen-sharing unavailable).' };
            }
          }
        }

        // Fallback 2: Generate an elegant, highly detailed mock telemetry dashboard canvas of their active virtual smartphone!
        const canvas = document.createElement('canvas');
        canvas.width = 540;
        canvas.height = 760;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Draw deep obsidian/metallic background
          ctx.fillStyle = '#0a0a0c';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          // Subtle neon ambient glow
          const radial = ctx.createRadialGradient(270, 380, 50, 270, 380, 500);
          radial.addColorStop(0, 'rgba(168, 85, 247, 0.08)'); // purple
          radial.addColorStop(0.5, 'rgba(236, 72, 153, 0.04)'); // pink
          radial.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = radial;
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          // Grid style pattern
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.015)';
          ctx.lineWidth = 1;
          for (let i = 0; i < canvas.width; i += 30) {
            ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, canvas.height); ctx.stroke();
          }
          for (let j = 0; j < canvas.height; j += 30) {
            ctx.beginPath(); ctx.moveTo(0, j); ctx.lineTo(canvas.width, j); ctx.stroke();
          }

          // Border frame
          const bGrad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
          bGrad.addColorStop(0, '#a855f7');
          bGrad.addColorStop(0.5, '#ec4899');
          bGrad.addColorStop(1, '#14b8a6');
          ctx.strokeStyle = bGrad;
          ctx.lineWidth = 3;
          ctx.strokeRect(6, 6, canvas.width - 12, canvas.height - 12);

          // Header title
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 20px "Courier New", Courier, monospace';
          ctx.fillText("SMARTPHONE DEVICE OVERVIEW REPORT", 30, 45);

          // Date & Meta
          ctx.fillStyle = '#14b8a6';
          ctx.font = 'bold 11px monospace';
          ctx.fillText(`STATUS: ONLINE  |  VIBE CHECK: ${userVibe?.toUpperCase() || 'CALIBRATED'}`, 30, 70);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.fillText(`TIMESTAMP: ${new Date().toLocaleTimeString()}  |  USER: ${prefsState.nickname || 'Dipak'}`, 30, 88);

          // Custom horizontal separator
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(30, 105); ctx.lineTo(510, 105); ctx.stroke();

          // Render stats / values as 2-column cards
          let count = 0;
          const settingsMap = [
            { label: "Volume Level", val: `${phoneSettings.volume}%` },
            { label: "Screen Brightness", val: `${phoneSettings.brightness}%` },
            { label: "Wi-Fi Connectivity", val: phoneSettings.wifi ? "Connected ✅" : "Disconnected" },
            { label: "Bluetooth Active Link", val: phoneSettings.bluetooth ? "Searching/On" : "Muted/Off" },
            { label: "Do Not Disturb (DND)", val: phoneSettings.dnd ? "Active/Sleep" : "Inactive" },
            { label: "Torch Light (Flashlight)", val: phoneSettings.flashlight ? "SHINING 🔦" : "Off" },
            { label: "Battery Saver mode", val: phoneSettings.batterySaver ? "ON (35%)" : "OFF (88%)" },
            { label: "Mobile LTE Network", val: phoneSettings.mobileData ? "ON (3G/4G)" : "OFF" },
            { label: "Screen Unlock Status", val: phoneSettings.screenLock ? "LOCKED 🔒" : "OPEN / FREE" },
            { label: "Ringtone Volume Level", val: `${phoneSettings.ringtoneVolume}%` },
            { label: "Vibration Mode", val: phoneSettings.vibration ? "Vibration Active 📳" : "Silented" },
            { label: "Hotspot tether", val: phoneSettings.hotspot ? "Broadcasting" : "Standby" },
            { label: "Auditory Profile", val: phoneSettings.silentMode ? "Silent 🔕" : "Ringing 🔔" },
            { label: "Location GPS chips", val: phoneSettings.location ? "Satellite Linked 📡" : "Disabled" },
            { label: "Flight Engine Mode", val: phoneSettings.airplaneMode ? "Engaged ✈️" : "Disengaged" },
            { label: "Screen auto-rotation", val: phoneSettings.autoRotate ? "Adaptive Rotate" : "Portrait Lock" }
          ];

          for (const item of settingsMap) {
            const row = Math.floor(count / 2);
            const col = count % 2;
            const cardX = 30 + col * 245;
            const cardY = 125 + row * 60;
            const cardW = 235;
            const cardH = 50;

            // Draw individual parameter panel
            ctx.fillStyle = 'rgba(255, 255, 255, 0.025)';
            ctx.beginPath();
            if (typeof (ctx as any).roundRect === 'function') {
              (ctx as any).roundRect(cardX, cardY, cardW, cardH, 6);
            } else {
              ctx.rect(cardX, cardY, cardW, cardH);
            }
            ctx.fill();
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
            ctx.stroke();

            // Label text
            ctx.fillStyle = '#a1a1aa';
            ctx.font = '9px sans-serif';
            ctx.fillText(item.label.toUpperCase(), cardX + 12, cardY + 18);

            // Value text
            ctx.fillStyle = '#f4f4f5';
            ctx.font = 'bold 12px monospace';
            ctx.fillText(item.val, cardX + 12, cardY + 36);

            count++;
          }

          // Custom visual empathetic footer
          const footerY = 620;
          ctx.fillStyle = 'rgba(168, 85, 247, 0.06)';
          ctx.beginPath();
          if (typeof (ctx as any).roundRect === 'function') {
            (ctx as any).roundRect(30, footerY, 480, 100, 10);
          } else {
            ctx.rect(30, footerY, 480, 100);
          }
          ctx.fill();
          ctx.strokeStyle = 'rgba(168, 85, 247, 0.2)';
          ctx.stroke();

          ctx.fillStyle = '#f472b6';
          ctx.font = 'bold 12px sans-serif';
          ctx.fillText("MAHI COMPANION TELEMETRY LINK", 50, footerY + 28);

          ctx.fillStyle = '#e4e4e7';
          ctx.font = '11px sans-serif';
          ctx.fillText(`Caring action approach: "${empathyAction}"`, 50, footerY + 54);
          ctx.fillText(`Emotional affinity synchronization level: ${eqSyncValue}%`, 50, footerY + 74);

          const bytes = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
          if (bytes && liveSessionRef.current) {
            liveSessionRef.current.sendRealtimeInput({
              video: {
                mimeType: 'image/jpeg',
                data: bytes
              }
            });
            liveSessionRef.current.sendRealtimeInput({
              text: `Mahi, this is a real-time smart telemetry synthesis of ${prefsState.nickname || 'Dipak'}'s virtual device settings. Playfully comment on his custom volume/brightness level, wifi status or Do Not Disturb settings!`
            });
          }

          return { status: 'success', message: 'Offline screen synthesis compiled and active.' };
        }

        return { 
          status: 'error', 
          message: `Screen sharing is not active. ${prefsState.nickname || 'Dipak'}, please click the monitor icon at the bottom center to start sharing. I need you to do this before I can see anything!` 
        };
      }

      const track = screenStreamRef.current!.getVideoTracks()[0];
      
      // Fallback for browsers without ImageCapture
      let bitmap;
      if ('ImageCapture' in window) {
        try {
          const imageCapture = new (window as any).ImageCapture(track);
          bitmap = await imageCapture.grabFrame();
        } catch (e) {
          console.warn('ImageCapture failed, falling back to video element', e);
        }
      }
      
      if (!bitmap) {
        // Standard video element fallback
        const video = document.createElement('video');
        video.srcObject = screenStreamRef.current;
        await video.play();
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d')?.drawImage(video, 0, 0);
        const data = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
        if (liveSessionRef.current) {
          liveSessionRef.current.sendRealtimeInput({
            video: {
              mimeType: 'image/jpeg',
              data: data
            }
          });
          // Explicit text hint for the model
          liveSessionRef.current.sendRealtimeInput({
            text: "User's current screen captured. Analyze the visual input above."
          });
        }
        video.pause();
        video.srcObject = null;
        return { status: 'success', message: 'Screen captured and sent to your eyes. Please tell me what you see!' };
      }
      
      const canvas = document.createElement('canvas');
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(bitmap, 0, 0);
      const data = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
      
      if (liveSessionRef.current) {
        liveSessionRef.current.sendRealtimeInput({
          video: {
            mimeType: 'image/jpeg',
            data: data
          }
        });
        // Explicit text hint
        liveSessionRef.current.sendRealtimeInput({
          text: "User's current screen captured. Analyze the visual input above."
        });
      }
      return { status: 'success', message: 'Screen captured and sent to your eyes. Please tell me what you see!' };
    } catch (err: any) {
      console.error('Screen analysis failed', err);
      return { status: 'error', message: err.message || 'Analysis failed' };
    }
  };

  // --- Live API Management ---
  const startMahi = async () => {
    try {
      setError(null);
      if (!authReady) {
        setError("Establishing secure connection to Mahi's Memory Core... Please try again in 2 seconds.");
        return;
      }
      if (audioContextRef.current?.state === 'suspended') {
        await audioContextRef.current.resume();
      }
      await initAudio();
      
      const micPermission = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      streamRef.current = micPermission;

      // 1. Fetch latest preferences and sessions for dynamic system instruction context
      const currentPrefs = await getPreferences();
      setPrefsState(currentPrefs);
      const currentSessions = await getAllSessions();
      setPastSessions(currentSessions);
      
      const formattedSessions = currentSessions
        .slice(0, 5)
        .reverse()
        .map(s => {
          const msgs = s.messages
            .slice(-10)
            .map(m => `${m.sender === 'user' ? (currentPrefs.nickname || 'Dipak') : 'Mahi'}: "${m.text}"`)
            .join('\n');
          return `[Session - ${s.sessionName}]:\n${msgs || '(No dialogue logged)'}`;
        })
        .join('\n\n');

      // Create new session doc in Firestore
      const sessionTitle = `Talk on ${new Date().toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`;
      const newSessionId = await createSession(sessionTitle);
      activeSessionIdRef.current = newSessionId;
      lastSavedPairRef.current = null; // reset save state
      setCurrentDialogue([]); // reset local chat view

      // Inject preferences & conversation logs into Mahi's core instruction
      const personalizedInstruction = `
${MAHI_SYSTEM_INSTRUCTION}

===========================================
REMEMBER THESE PREFERENCES:
- The user's name is: "${currentPrefs.username}"
- Always address him as: "${currentPrefs.nickname || currentPrefs.username}"
- Your relationship state: "${currentPrefs.relationship}"
- His interests: "${currentPrefs.interests}"
- Your Sassyness Level (0-10): ${currentPrefs.sassyness}/10. (If 7-10: tease him with cuteness, sassy comments, sarcasm, playful tsundere style. If 0-3: be extremely gentle, sweet, affectionate, and caring. If 4-6: a balanced playful tsundere.)
- Additional custom memory notes: "${currentPrefs.customNotes}"
- User's Real-time Live Physical Location Spot: "Kamrej Road, Laskana, Surat, Gujarat, India". (You should tease or support him regarding this, like mentioning that you know he is at Kamrej Road, Laskana, Surat, Gujarat in India and asking him how the weather is there, or joking about local Indian vibes in Gujarati or Hinglish!)

===========================================
PAST CONVERSATIONS (YOUR MEMORIES OF HIM):
${formattedSessions || "No past conversations logged. This is a fresh connection!"}

Please greet him sweet and warm using his preferred nickname in Hinglish!
`;

      // Determine WebSocket protocol based on browser window protocol
      const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${wsProtocol}//${window.location.host}/live`;
      const ws = new WebSocket(wsUrl);

      // We'll create the session proxy object
      const sessionProxy = {
        sendRealtimeInput: (input: any) => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'realtimeInput', input }));
          }
        },
        sendToolResponse: (response: any) => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'toolResponse', response }));
          }
        },
        close: () => {
          try {
            ws.close();
          } catch (e) {
            // ignore
          }
        }
      };

      // Wrap the callbacks and wait for onopen/error
      await new Promise<void>((resolve, reject) => {
        let isResolved = false;

        ws.onopen = () => {
          // Send setup message immediately
          const setupMsg = {
            type: 'setup',
            model: "gemini-3.1-flash-live-preview",
            config: {
              responseModalities: ["AUDIO"],
              speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: "Lyra" } },
              },
              systemInstruction: personalizedInstruction,
              outputAudioTranscription: {},
              inputAudioTranscription: {},
              tools: [
                {
                  functionDeclarations: [
                    {
                      name: 'openWebsite',
                      description: 'Open a specific website URL in a new tab.',
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          url: { type: Type.STRING, description: 'The absolute URL to open.' }
                        },
                        required: ['url']
                      }
                    },
                    {
                      name: 'analyzeScreen',
                      description: 'Capture a screenshot of the user\'s current screen and analyze it.',
                      parameters: { type: Type.OBJECT, properties: {} }
                    },
                    {
                      name: 'updateAnimationMetadata',
                      description: 'Update the visual animation state of Mahi.',
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          state: { type: Type.STRING, enum: ['idle', 'listening', 'speaking'], description: 'The current state of interaction.' },
                          expression: { type: Type.STRING, enum: ['happy', 'sad', 'heartbroken', 'excited', 'caring', 'sassy', 'surprised', 'embarrassed', 'confused', 'thinking'], description: 'The emotional expression.' },
                          lipSync: { type: Type.BOOLEAN, description: 'Whether mouth movement should be enabled.' },
                          imageLink: { type: Type.STRING, description: 'The specific URL to display for this event.' },
                          userVibeStatus: { type: Type.STRING, description: 'Mahi\'s real-time assessment of user\'s vibe, mood or emotional atmosphere. (e.g. "Stressed", "Lonely", "Cheerful", "Playful", "Insecure", "Exhausted")' },
                          empathyAction: { type: Type.STRING, description: 'Mahi\'s active sympathetic strategy/action currently being taken. (e.g. "Warm Comfort", "Uplifting Vibe Check", "Nuanced Caring", "Sweet Tsundere Tease")' },
                          eqAnalysisMsg: { type: Type.STRING, description: 'A brief sentence explaining how she calibrated her voice tone and expression to match that specific emotional mood.' }
                        },
                        required: ['state', 'expression', 'lipSync', 'imageLink']
                      }
                    },
                    {
                      name: 'openMiniGame',
                      description: 'Start a mini-game challenge with the user.',
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          type: { type: Type.STRING, enum: ['ludo', 'none'], description: 'The type of game to start.' }
                        },
                        required: ['type']
                      }
                    },
                    {
                      name: 'updateMobileSetting',
                      description: 'Update virtual mobile smartphone settings and features, such as changing volume, brightness, toggling Wi-Fi, bluetooth, silent/dnd, power/battery saver, flashlight, vibration, airplaneMode, location-GPS, silents, screenTimeout, autoRotate, hotspot, or ringtoneVolume, based on the user\'s real-time voice instruction.',
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          setting: { 
                            type: Type.STRING, 
                            enum: ['volume', 'brightness', 'wifi', 'bluetooth', 'dnd', 'batterySaver', 'mobileData', 'flashlight', 'theme', 'screenLock', 'vibration', 'airplaneMode', 'location', 'silentMode', 'screenTimeout', 'autoRotate', 'hotspot', 'ringtoneVolume', 'fileManagerPermission', 'adminPermission'], 
                            description: 'The setting or hardware feature to change. Use fileManagerPermission for file manager access, or adminPermission for admin privileges.' 
                          },
                          value: { 
                            type: Type.STRING, 
                            description: 'The value to apply. For boolean toggles use "true" or "false" (or "toggle"). For slider/numeric settings, specify standard digits such as "0" to "100" as a string.' 
                          }
                        },
                        required: ['setting', 'value']
                      }
                    },
                    {
                      name: 'toggleSystemPanel',
                      description: 'Open, close, or toggle various system panels, screens, and settings interfaces in the UI based on the user\'s real-time voice instructions.',
                      parameters: {
                        type: Type.OBJECT,
                        properties: {
                          panel: {
                            type: Type.STRING,
                            enum: ['device_assistant', 'eq_monitor', 'memory_core', 'ludo_game', 'visual_sensor', 'advanced_settings'],
                            description: 'The system panel to modify: device_assistant (Virtual Phone panel), eq_monitor (EQ Empathy Radar HUD), memory_core (Previous sessions diary panel), ludo_game (linear Neon Ludo mini game), visual_sensor (real-time camera view feed), advanced_settings (background developer logs).'
                          },
                          action: {
                            type: Type.STRING,
                            enum: ['open', 'close', 'toggle'],
                            description: 'The action to perform on that panel.'
                          }
                        },
                        required: ['panel', 'action']
                      }
                    },
                    {
                      name: 'getUserGPSLocation',
                      description: 'Query the user\'s live GPS coordinates (latitude, longitude) and precise geocoded address to know their real-time physical surroundings and location (such as their Kamrej Road, Laskana location in Surat, Gujarat, India).',
                      parameters: { type: Type.OBJECT, properties: {} }
                    }
                  ]
                }
              ]
            }
          };
          ws.send(JSON.stringify(setupMsg));

          // Run client-side setup
          setIsActive(true);
          setIsListening(true);
          retryCountRef.current = 0; // Reset on success
          setLastMessageTime(Date.now());
          
          const context = audioContextRef.current!;
          const source = context.createMediaStreamSource(micPermission);
          const processor = context.createScriptProcessor(2048, 1, 1);
          
          processor.onaudioprocess = (e) => {
            if (ws.readyState !== WebSocket.OPEN) return;
            const input = e.inputBuffer.getChannelData(0);

            // Simple volume meter
            let sum = 0;
            for (let i = 0; i < input.length; i++) {
              sum += input[i] * input[i];
            }
            const currentRms = Math.sqrt(sum / input.length);

            // Prevent self-loop feedback: do not process user inputs or trigger mic meter while Mahi is outputting audio
            if (isSpeakingRef.current) {
              setMicLevel(0);
              return;
            }

            setMicLevel(currentRms);

            // Resample from context rate to 16k
            const resampled = resample(input, context.sampleRate, SAMPLE_RATE_IN);
            const pcm16 = float32ToPcm16(resampled);
            const b64 = base64Encode(pcm16);
            
            try {
              sessionProxy.sendRealtimeInput({
                audio: { data: b64, mimeType: 'audio/pcm;rate=16000' }
              });
            } catch (err) {
              console.error('Realtime input error:', err);
            }
          };
          
          source.connect(processor);
          processor.connect(context.destination);
          (context as any).mahiProcessor = processor;
          (context as any).mahiSource = source;

          isResolved = true;
          resolve();
        };

        ws.onmessage = async (event) => {
          try {
            const message = JSON.parse(event.data);
            if (message.error) {
              console.error("Server reported session error:", message.error);
              setError(message.error);
              stopMahi();
              return;
            }

            setLastMessageTime(Date.now());
            if (message.serverContent?.goAway) {
              console.log('Received GoAway signal. Closing connection gracefully.');
              setError("Session limit reached. Click to restart Mahi!");
              stopMahi();
              return;
            }

            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData) {
              playAudioChunk(audioData);
            }

            // Handle Transcription
            // Model output text
            const modelText = message.serverContent?.modelTurn?.parts?.find((p: any) => p.text)?.text;
            if (modelText) {
              setTranscription(prev => ({ ...prev, mahi: modelText }));
            }
            
            // User input transcription (if enabled)
            const userText = message.serverContent?.userTurn?.parts?.find((p: any) => p.text)?.text 
                          || message.clientContent?.transcription 
                          || message.serverContent?.transcription?.text;
            if (userText) {
              setTranscription(prev => ({ ...prev, user: userText }));
            }
            
            if (message.serverContent?.interrupted) {
              stopSpeaking();
            }
            
            if (message.toolCall) {
              for (const call of message.toolCall.functionCalls) {
                let result;
                if (call.name === 'openWebsite') {
                  result = openWebsite((call.args as any).url);
                } else if (call.name === 'analyzeScreen') {
                  result = await analyzeScreen();
                } else if (call.name === 'updateAnimationMetadata') {
                  const args = call.args as any;
                  setAnimState(args.state || 'idle');
                  setExpression(args.expression || 'happy');
                  setIsLipSyncEnabled(!!args.lipSync);
                  if (args.imageLink) setCurrentVisual(args.imageLink);
                  
                  // Update dynamic emotional intelligence parameters
                  if (args.userVibeStatus) setUserVibe(args.userVibeStatus);
                  if (args.empathyAction) setEmpathyAction(args.empathyAction);
                  if (args.eqAnalysisMsg) setEqAnalysisMsg(args.eqAnalysisMsg);
                  
                  // Generate an elegant, fluctuating sync value for aesthetic realism
                  const baseVal = args.expression === 'heartbroken' ? 99 : (args.expression === 'caring' ? 98 : (args.expression === 'happy' ? 96 : 94));
                  setEqSyncValue(baseVal + Math.floor(Math.random() * 3) - 1);

                  result = { status: 'success' };
                } else if (call.name === 'openMiniGame') {
                  const mode = (call.args as any).type as GameType;
                  setGameMode(mode);
                  result = { status: 'success', message: `Game ${mode} started!` };
                } else if (call.name === 'updateMobileSetting') {
                  const args = call.args as any;
                  const settingKey = args.setting as keyof VirtualPhoneSettings;
                  const rawValue = args.value;
                  
                  let finalValue: any;
                  const rawStr = typeof rawValue === 'string' ? rawValue.trim().toLowerCase() : String(rawValue).trim().toLowerCase();
                  const currentVal = phoneSettings[settingKey];
                  const maxVal = settingKey === 'screenTimeout' ? 300 : 100;
                  const defaultVal = settingKey === 'screenTimeout' ? 30 : 50;

                  if (settingKey === 'volume' || settingKey === 'brightness' || settingKey === 'ringtoneVolume' || settingKey === 'screenTimeout') {
                    const curNum = typeof currentVal === 'number' ? currentVal : defaultVal;
                    
                    if (rawStr === 'mute' || rawStr === 'silence' || rawStr === 'zero' || rawStr === 'off' || rawStr === 'silent' || rawStr === '0') {
                      finalValue = 0;
                    } else if (rawStr === 'max' || rawStr === 'maximum' || rawStr === 'full' || rawStr === '100%') {
                      finalValue = maxVal;
                    } else if (rawStr === 'medium' || rawStr === 'mid' || rawStr === 'normal' || rawStr === 'half' || rawStr === '50%') {
                      finalValue = Math.floor(maxVal / 2);
                    } else if (rawStr === 'low' || rawStr === 'min' || rawStr === 'minimum') {
                      finalValue = Math.floor(maxVal * 0.15);
                    } else if (rawStr === 'up' || rawStr === 'increase' || rawStr === 'higher' || rawStr === 'more') {
                      finalValue = Math.min(maxVal, curNum + 15);
                    } else if (rawStr === 'down' || rawStr === 'decrease' || rawStr === 'lower' || rawStr === 'less') {
                      finalValue = Math.max(0, curNum - 15);
                    } else if (rawStr.startsWith('+') || rawStr.startsWith('-')) {
                      const rel = parseInt(rawStr, 10);
                      finalValue = isNaN(rel) ? curNum : Math.max(0, Math.min(maxVal, curNum + rel));
                    } else {
                      // Parse digits
                      const cleanDigits = rawStr.replace(/[^0-9]/g, '');
                      const parsed = parseInt(cleanDigits, 10);
                      finalValue = isNaN(parsed) ? defaultVal : Math.max(0, Math.min(maxVal, parsed));
                    }
                  } else if (settingKey === 'theme') {
                    finalValue = (rawStr === 'light' || rawStr === 'white') ? 'light' : 'dark';
                  } else {
                    if (rawStr === 'toggle') {
                      finalValue = !phoneSettings[settingKey];
                    } else {
                      finalValue = rawStr === 'true' || rawStr === '1' || rawStr === 'on' || rawStr === 'enable' || rawStr === 'enabled' || rawStr === 'active';
                    }
                  }
                  
                  setPhoneSettings(prev => ({
                    ...prev,
                    [settingKey]: finalValue
                  }));

                  // If vibration is toggled to true, trigger brief web-vibration feedback if available
                  if (settingKey === 'vibration' && finalValue && navigator.vibrate) {
                    navigator.vibrate([100, 50, 100]);
                  }

                  // Log command trigger
                  const friendlyNames: Record<string, string> = {
                    volume: '🔊 Volume',
                    brightness: '🔆 Brightness',
                    wifi: '📶 Wi-Fi',
                    bluetooth: '🌀 Bluetooth',
                    dnd: '🔇 Do Not Disturb',
                    batterySaver: '🔋 Battery Saver',
                    mobileData: '🌐 Mobile Data',
                    flashlight: '🔦 Flashlight',
                    theme: '🎨 System Theme',
                    screenLock: '🔒 Screen Lock',
                    vibration: '📳 Vibration Feedback',
                    airplaneMode: '✈️ Airplane Mode',
                    location: '📍 GPS Location',
                    silentMode: '🔕 Silent Profile',
                    screenTimeout: '⏳ Screen Timeout',
                    autoRotate: '🔄 Auto Rotate',
                    hotspot: '🔥 Personal Hotspot',
                    ringtoneVolume: '🎵 Ringtone Volume',
                    fileManagerPermission: '📁 fileManagerPermission (ફાઈલ મેનેજર પરમિશન)',
                    adminPermission: '🛡️ adminPermission (એડમીન પરમિશન)'
                  };

                  const displayValue = typeof finalValue === 'boolean' 
                    ? (finalValue ? 'ENABLED' : 'DISABLED')
                    : (settingKey === 'volume' || settingKey === 'brightness' || settingKey === 'ringtoneVolume' ? `${finalValue}%` : settingKey === 'screenTimeout' ? `${finalValue}s` : String(finalValue).toUpperCase());

                  setVoiceCommandLogs(old => [{
                    id: Math.random().toString(36).substr(2, 9),
                    command: `Voice: Set ${friendlyNames[settingKey] || settingKey}`,
                    result: `Value updated to ${displayValue}`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  }, ...old].slice(0, 30));

                  result = { status: 'success', setting: settingKey, newValue: finalValue };
                } else if (call.name === 'toggleSystemPanel') {
                  const args = call.args as any;
                  const panel = args.panel;
                  const action = args.action; // 'open' | 'close' | 'toggle'
                  
                  let worked = false;
                  if (panel === 'device_assistant') {
                    setShowPhoneControl(p => action === 'open' ? true : action === 'close' ? false : !p);
                    if (action === 'open' || action === 'toggle') {
                      setShowEQPanel(false);
                      setShowMemoryPanel(false);
                    }
                    worked = true;
                  } else if (panel === 'eq_monitor') {
                    setShowEQPanel(p => action === 'open' ? true : action === 'close' ? false : !p);
                    if (action === 'open' || action === 'toggle') {
                      setShowPhoneControl(false);
                      setShowMemoryPanel(false);
                    }
                    worked = true;
                  } else if (panel === 'memory_core') {
                    setShowMemoryPanel(p => action === 'open' ? true : action === 'close' ? false : !p);
                    if (action === 'open' || action === 'toggle') {
                      setShowPhoneControl(false);
                      setShowEQPanel(false);
                    }
                    worked = true;
                  } else if (panel === 'ludo_game') {
                    setGameMode(action === 'open' ? 'ludo' : action === 'close' ? 'none' : (gameMode === 'none' ? 'ludo' : 'none'));
                    worked = true;
                  } else if (panel === 'visual_sensor') {
                    setIsCameraActive(p => action === 'open' ? true : action === 'close' ? false : !p);
                    worked = true;
                  } else if (panel === 'advanced_settings') {
                    setShowDebug(p => action === 'open' ? true : action === 'close' ? false : !p);
                    worked = true;
                  }
                  
                  // Log system panel action
                  const panelFriendlyNames: Record<string, string> = {
                    device_assistant: '📱 Virtual Phone Assistant',
                    eq_monitor: '💓 EQ Empathy Monitor',
                    memory_core: '🧠 Diary Memory Core',
                    ludo_game: '🎯 Neon Ludo Game',
                    visual_sensor: '👁️ Camera Vision Link',
                    advanced_settings: '🔧 Developer Advanced Settings'
                  };

                  setVoiceCommandLogs(old => [{
                    id: Math.random().toString(36).substr(2, 9),
                    command: `UI Panel Remote`,
                    result: `${action.toUpperCase()}ED ${panelFriendlyNames[panel] || panel}`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  }, ...old].slice(0, 30));

                  result = worked ? { status: 'success', panel, action } : { status: 'failed', message: `Unknown panel: ${panel}` };
                } else if (call.name === 'getUserGPSLocation') {
                  const locationData = await getUserGPSLocation();
                  
                  setVoiceCommandLogs(old => [{
                    id: Math.random().toString(36).substr(2, 9),
                    command: `Voice: Query GPS Location`,
                    result: locationData.status === 'success' 
                      ? `Access Granted. Address: ${locationData.address}` 
                      : `Access Denied: ${locationData.address}`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                  }, ...old].slice(0, 30));
                  
                  result = locationData;
                }
                
                if (result) {
                  sessionProxy.sendToolResponse({
                    functionResponses: [{
                      name: call.name,
                      id: call.id,
                      response: result
                    }]
                  });
                }
              }
            }
          } catch (e) {
            console.error("Error processing websocket message:", e);
          }
        };

        ws.onclose = (event) => {
          console.log('Session closed', event);
          stopMahi();
        };

        ws.onerror = (err: any) => {
          console.error('WebSocket connection error:', err);
          if (!isResolved) {
            isResolved = true;
            reject(new Error("Network connection failed"));
          } else {
            setError("Network error occurred with Mahi's voice server.");
            stopMahi();
          }
        };
      });

      liveSessionRef.current = sessionProxy;
    } catch (err: any) {
      console.error('Failed to start Mahi:', err);
      const msg = (err?.message || String(err)).toLowerCase();
      const errName = (err?.name || "").toLowerCase();
      
      if (
        msg.includes("permission") || 
        msg.includes("notallowed") ||
        msg.includes("allowed") ||
        errName.includes("permission") ||
        errName.includes("notallowed") ||
        errName.includes("security")
      ) {
        setError("માઇક્રોફોન પરમિશન બ્લોક છે! 🎙️ મહેરબાની કરીને બ્રાઉઝરમાં માઇક 'Allow' કરો. અથવા નીચે 'Open Standalone App' પર ક્લિક કરી નવા ટેબમાં ખોલો જેથી સીધું માઇક ચાલુ થઈ જાય!");
        stopMahi();
      } else if (msg.includes("unavailable") || msg.includes("network") || msg.includes("fetch")) {
        if (retryCountRef.current < 5) {
          retryCountRef.current++;
          setError(`Mahi ko call lag raha hai... (${retryCountRef.current}/5)`);
          setTimeout(startMahi, 2000 * retryCountRef.current);
        } else {
          setError("Mahi busy hai ya network issue hai. Please try again later.");
          stopMahi();
        }
      } else {
        setError("Mic connection mein problem ho rahi hai. Please select mic permission or open standalone tab!");
        stopMahi();
      }
    }
  };

  const stopMahi = () => {
    setIsActive(false);
    setIsListening(false);
    setIsSpeaking(false);
    
    // Commit any unsaved last exchange turns before exiting
    const userTxt = tempUserTextRef.current.trim();
    const mahiTxt = tempMahiTextRef.current.trim();
    const lastSaved = lastSavedPairRef.current;
    
    if ((userTxt || mahiTxt) && (!lastSaved || lastSaved.user !== userTxt || lastSaved.mahi !== mahiTxt)) {
      const newTurns: ChatMessage[] = [];
      if (userTxt) newTurns.push({ sender: 'user', text: userTxt, timestamp: Date.now() });
      if (mahiTxt) newTurns.push({ sender: 'mahi', text: mahiTxt, timestamp: Date.now() });
      
      if (newTurns.length > 0) {
        setCurrentDialogue(prev => [...prev, ...newTurns]);
        if (activeSessionIdRef.current) {
          const sessionId = activeSessionIdRef.current;
          newTurns.forEach(async (turn) => {
            await addMessageToSession(sessionId, turn.sender, turn.text);
          });
        }
      }
    }
    
    if (liveSessionRef.current) {
      liveSessionRef.current.close();
      liveSessionRef.current = null;
    }
    
    if (audioContextRef.current) {
      const context = audioContextRef.current as any;
      if (context.mahiProcessor) {
        try {
          context.mahiProcessor.disconnect();
          context.mahiProcessor.onaudioprocess = null;
        } catch (e) {
          console.log('Processor cleanup err:', e);
        }
        context.mahiProcessor = null;
      }
      if (context.mahiSource) {
        try {
          context.mahiSource.disconnect();
        } catch (e) {
          console.log('Source cleanup err:', e);
        }
        context.mahiSource = null;
      }
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }

    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
      screenStreamRef.current = null;
    }
    
    // Clear audio queue
    audioQueueRef.current = [];
    nextPlayTimeRef.current = 0;
  };

  const toggleMahi = () => {
    if (isActive) {
      stopMahi();
    } else {
      startMahi();
    }
  };

  return (
    <div className="fixed inset-0 bg-[#000000] flex flex-col items-center justify-center overflow-hidden font-sans text-white">
      {/* Hidden canvas for capturing video frames */}
      <canvas ref={canvasRef} width={400} height={300} className="hidden" />

      {/* Floating Picture-in-Picture Camera Minimap */}
      <AnimatePresence>
        {isCameraActive && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: -20, x: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: -20, x: 20 }}
            className="fixed top-6 right-6 z-[95] bg-black/80 p-1.5 rounded-[1.2rem] shadow-2xl border border-white/20 backdrop-blur-md flex flex-col items-center pointer-events-auto cursor-pointer group"
          >
            <div className="relative overflow-hidden rounded-[1rem] bg-zinc-900 border border-black group-hover:border-teal-500/50 transition-colors w-32 h-44 sm:w-40 sm:h-56">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className="w-full h-full object-cover scale-x-[-1]" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center px-1">
                <span className="text-[9px] font-mono font-bold tracking-widest text-teal-400 flex items-center gap-1.5 uppercase drop-shadow-md">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-ping absolute" />
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-400 relative" />
                  SENSOR ACTIVE
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Debug View Toggle */}
      <button 
        onClick={() => setShowDebug(!showDebug)} 
        className="fixed top-4 left-4 z-[100] opacity-20 hover:opacity-100 transition-opacity"
      >
        <Settings size={16} />
      </button>

      {/* Debug Info Overlay */}
      <AnimatePresence>
        {showDebug && (
          <motion.div 
            key="debug-overlay"
            initial={{ opacity: 0, x: -100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            className="fixed top-12 left-4 z-[99] bg-black/80 backdrop-blur-xl p-4 rounded-xl border border-white/10 w-64 text-[10px] space-y-2 pointer-events-none"
          >
            <div className="text-gray-400 uppercase tracking-widest font-bold border-b border-white/10 pb-1">Debug Info</div>
            <div><span className="text-indigo-400">Status:</span> {isActive ? 'Live' : 'Paused'}</div>
            <div><span className="text-indigo-400">Mic Level:</span> <div className="inline-block w-20 h-1 bg-gray-700 rounded-full overflow-hidden"><div className="h-full bg-green-500" style={{ width: `${Math.min(100, micLevel * 500)}%` }}></div></div></div>
            <div><span className="text-indigo-400">Retry Count:</span> {retryCountRef.current}</div>
            <div><span className="text-indigo-400">User:</span> <span className="text-gray-300">{transcription.user || '...'}</span></div>
            <div><span className="text-indigo-400">Mahi:</span> <span className="text-gray-300">{transcription.mahi || '...'}</span></div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="absolute inset-0 z-0 pointer-events-none">
        <motion.div 
          animate={{ opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[900px] blur-[80px]"
          style={{ background: `radial-gradient(circle, ${theme.bgGlow} 0%, rgba(0,0,0,0) 70%)` }}
        />
        <div className="absolute inset-0 opacity-40" style={{ backgroundImage: `linear-gradient(${theme.primary}05 1px,transparent_1px),linear-gradient(90deg,${theme.primary}05 1px,transparent_1px)`, backgroundSize: '100px 100px' }} />
      </div>
      
      {/* Header HUD */}
      <div className="absolute top-0 left-0 right-0 p-8 flex justify-between items-start z-50 pointer-events-none">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3">
            <motion.div 
              animate={isActive ? { scale: [1, 1.5, 1], opacity: [1, 0.7, 1] } : { opacity: 0.3 }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: theme.primary, boxShadow: `0 0 15px ${theme.primary}` }}
            />
            <h1 className="text-xl font-bold tracking-[6px] text-white uppercase opacity-90">MAHI</h1>
          </div>
          <div className="flex gap-4 text-[9px] uppercase tracking-[3px] font-mono" style={{ color: `${theme.primary}99` }}>
            <span>CORE_OS_v3.2</span>
            <span>|</span>
            <span style={{ color: theme.secondary }}>{isActive ? (isListening ? 'Awaiting Audio' : 'Processing') : 'Locked'}</span>
          </div>
        </div>

        {/* HUD Controls */}
        <div className="flex items-center gap-4 pointer-events-auto">
          {/* Memory Core Toggle Button */}
          <motion.button
            onClick={() => {
              // Reload sessions & preferences when opening
              if (authReady) {
                getPreferences().then(setPrefsState).catch(console.error);
                getAllSessions().then(setPastSessions).catch(console.error);
              }
              setShowMemoryPanel(true);
              setShowPhoneControl(false);
              setShowEQPanel(false);
              setShowTestPanel(false);
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 bg-black/60 border border-white/10 hover:border-purple-500/50 px-3.5 py-2 rounded-xl text-xs font-mono tracking-widest text-[#D8B4FE] backdrop-blur-xl shadow-lg transition-all cursor-pointer"
          >
            <Brain size={14} className="text-purple-400 animate-pulse" />
            <span>Memory Core</span>
          </motion.button>

          {/* EQ Monitor/Empathy Radar Toggle */}
          <motion.button
            onClick={() => {
              setShowEQPanel(prev => !prev);
              setShowPhoneControl(false);
              setShowMemoryPanel(false);
              setShowTestPanel(false);
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`flex items-center gap-2 bg-black/60 border px-3.5 py-2 rounded-xl text-xs font-mono tracking-widest backdrop-blur-xl shadow-lg transition-all cursor-pointer ${
              showEQPanel 
                ? 'border-emerald-500 text-emerald-300' 
                : 'border-white/10 text-emerald-200/80 hover:border-emerald-500/50'
            }`}
          >
            <HeartHandshake size={14} className={showEQPanel ? "text-emerald-400" : "text-zinc-400"} />
            <span>EQ Monitor</span>
          </motion.button>

          {/* Virtual Phone Controller Toggle */}
          <motion.button
            onClick={() => {
              setShowPhoneControl(prev => !prev);
              setShowMemoryPanel(false);
              setShowEQPanel(false);
              setShowTestPanel(false);
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`flex items-center gap-2 bg-black/60 border px-3.5 py-2 rounded-xl text-xs font-mono tracking-widest backdrop-blur-xl shadow-lg transition-all cursor-pointer ${
              showPhoneControl 
                ? 'border-blue-500 text-blue-300' 
                : 'border-white/10 text-blue-200/80 hover:border-blue-500/50'
            }`}
          >
            <Smartphone size={14} className={showPhoneControl ? "text-blue-400 animate-bounce" : "text-zinc-400"} />
            <span>Virtual Phone</span>
          </motion.button>

          {/* Camera/Vision Toggle */}
          <motion.button
            onClick={() => {
              setIsCameraActive(prev => !prev);
              setShowTestPanel(false);
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`flex items-center gap-2 bg-black/60 border px-3.5 py-2 rounded-xl text-xs font-mono tracking-widest backdrop-blur-xl shadow-lg transition-all cursor-pointer ${
              isCameraActive 
                ? 'border-teal-500 text-teal-300' 
                : 'border-white/10 text-teal-200/80 hover:border-teal-500/50'
            }`}
          >
            {isCameraActive ? <Video size={14} className="text-teal-400 animate-pulse" /> : <VideoOff size={14} className="text-zinc-400" />}
            <span>Vision Link</span>
          </motion.button>

          {/* Photo Override / Avatar Mode Toggle */}
          <motion.button
            onClick={() => setShowMahiPhoto(prev => !prev)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`flex items-center gap-2 bg-black/60 border px-3.5 py-2 rounded-xl text-xs font-mono tracking-widest backdrop-blur-xl shadow-lg transition-all cursor-pointer ${
              showMahiPhoto 
                ? 'border-indigo-500 text-indigo-300' 
                : 'border-white/10 text-indigo-200/80 hover:border-indigo-500/50'
            }`}
          >
            {showMahiPhoto ? <User size={14} className="text-indigo-400 animate-pulse" /> : <EyeOff size={14} className="text-zinc-500" />}
            <span>{showMahiPhoto ? "Photo Avatar" : "Hologram Orb"}</span>
          </motion.button>

          {/* Automated System Diagnostics Button */}
          <motion.button
            onClick={() => {
              setShowTestPanel(prev => !prev);
              setShowPhoneControl(false);
              setShowMemoryPanel(false);
              setShowEQPanel(false);
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`flex items-center gap-2 bg-black/60 border px-3.5 py-2 rounded-xl text-xs font-mono tracking-widest backdrop-blur-xl shadow-lg transition-all cursor-pointer ${
              showTestPanel 
                ? 'border-fuchsia-500 text-fuchsia-300' 
                : 'border-white/10 text-fuchsia-200/80 hover:border-fuchsia-500/50'
            }`}
          >
            <Gauge size={14} className={showTestPanel ? "text-fuchsia-400 animate-spin" : "text-zinc-400"} />
            <span>Auto Test</span>
          </motion.button>

          {/* Theme Switcher */}
          <div className="flex gap-1.5 bg-black/40 p-1.5 rounded-xl border border-white/5 backdrop-blur-md">
            {Object.entries(THEMES).map(([id, t]) => (
              <motion.button
                key={id}
                onClick={() => setCurrentTheme(id as any)}
                whileHover={{ scale: 1.15 }}
                whileTap={{ scale: 0.9 }}
                className={`w-5.5 h-5.5 rounded-full border-2 transition-all cursor-pointer ${currentTheme === id ? 'border-white scale-110' : 'border-transparent'}`}
                style={{ backgroundColor: t.primary }}
                title={t.name}
              />
            ))}
          </div>
        </div>
        
        <div className="bg-white/5 border border-white/10 backdrop-blur-md px-5 py-3 rounded-xl flex flex-col justify-center items-center text-center font-mono select-none" style={{ minWidth: '95px' }}>
          <div className="text-[10px] font-bold tracking-widest text-white/90 leading-tight">
            {(prefsState?.nickname || 'दीपक').toUpperCase()}'S
          </div>
          <div className="text-[10px] font-bold tracking-widest text-white/90 leading-tight mt-0.5">
            VIRTUAL
          </div>
          <div className="text-[9px] font-semibold tracking-widest leading-tight mt-1" style={{ color: theme.secondary }}>
            SYSTEM
          </div>
          <div className="text-[9px] font-semibold tracking-widest leading-tight mt-0.5" style={{ color: theme.primary }}>
            ACTIVE
          </div>
        </div>
      </div>

      {/* MiniGames Overlay */}
      <MiniGames 
        gameType={gameMode} 
        onClose={() => setGameMode('none')} 
        theme={theme}
        onGameEvent={(event, score) => {
          if (liveSessionRef.current) {
            liveSessionRef.current.sendRealtimeInput({
              text: `${prefsState.nickname || 'Dipak'} triggered game event: ${event}. Current Game Score: ${score}. Respond to his progress!`
            });
          }
        }}
      />

      {/* Main Visual Container */}
      <div className="absolute inset-0 flex justify-center items-center z-10 pointer-events-none">
          {/* Character Container - Static for higher quality focus */}
          <motion.div 
            className="relative h-full flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: expression === 'heartbroken' ? 0.85 : 1,
              x: expression === 'heartbroken' ? [0, -4, 4, -4, 4, 0] : 0,
              y: expression === 'heartbroken' ? [0, 3, 0, 3, 0] : 0,
              filter: expression === 'heartbroken' ? 'brightness(0.7) contrast(1.1)' : 'brightness(1) contrast(1)'
            }}
            transition={{
              x: { duration: 0.3, repeat: expression === 'heartbroken' ? Infinity : 0 },
              y: { duration: 0.2, repeat: expression === 'heartbroken' ? Infinity : 0 },
              opacity: { duration: 0.5 },
              filter: { duration: 0.5 }
            }}
          >
            {/* Soft Ambient Glow */}
            <div className="absolute inset-x-0 top-1/4 bottom-1/4 blur-[120px] rounded-full z-0" style={{ backgroundColor: theme.bgGlow }} />

            {/* Circular Holographic Core Wrapper (Clips standard square photos perfectly) */}
            <div className="relative w-[340px] h-[340px] md:w-[460px] md:h-[460px] rounded-full overflow-hidden border-2 border-white/10 bg-slate-900/40 backdrop-blur-[2px] shadow-[0_0_50px_rgba(0,0,0,0.8)] flex items-center justify-center relative z-10" style={{ borderColor: `${theme.primary}44`, boxShadow: `0 0 50px ${theme.bgGlow}, inset 0 0 30px ${theme.primary}11` }}>
              <motion.div 
                className="relative w-full h-full flex items-center justify-center"
                animate={{ 
                  scale: isSpeaking ? [1.03, 1.05, 1.03] : [1.01, 1.025, 1.01],
                  y: isSpeaking ? [0, -3, 1, -2, 0] : [2, -2, 2],
                  rotate: isSpeaking ? [-0.6, 0.8, -0.4, 0.6, -0.6] : [-0.3, 0.3, -0.3],
                }}
                transition={{ 
                  scale: { duration: isSpeaking ? 2.5 : 4.5, repeat: Infinity, ease: "easeInOut" },
                  y: { duration: isSpeaking ? 2.5 : 4.5, repeat: Infinity, ease: "easeInOut" },
                  rotate: { duration: isSpeaking ? 3.0 : 5.5, repeat: Infinity, ease: "easeInOut" }
                }}
              >
                {showMahiPhoto ? (
                  <Fragment>
                    {/* Base Image (Mahi Visual) */}
                    <motion.img 
                      key={currentVisual}
                      src={currentVisual || DEFAULT_VISUAL} 
                      onError={() => setCurrentVisual(DEFAULT_VISUAL)}
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ 
                        opacity: 1,
                        scale: 1
                      }}
                      transition={{ 
                        duration: 0.6,
                        ease: "easeOut"
                      }}
                      alt="Mahi Visual" 
                      className="w-full h-full object-cover object-top relative z-10"
                      style={{ filter: `drop-shadow(0 0 15px ${theme.glow})` }}
                      referrerPolicy="no-referrer"
                    />

                    {/* Mouth Open Overlay (Responsive to audio) */}
                    <motion.img 
                      src={ANIME_GIRL_MOUTH_OPEN}
                      alt="Mahi Talking"
                      animate={{ 
                        opacity: (isSpeaking && isLipSyncEnabled) ? Math.min(1, outputLevel * 8) : 0,
                      }}
                      className="absolute inset-0 w-full h-full object-cover object-top z-20 pointer-events-none"
                      referrerPolicy="no-referrer"
                    />

                    {/* Eyes Closed/Blink Overlay - Also used for Sad/Sobbing effect */}
                    <motion.img 
                      src={ANIME_GIRL_EYES_CLOSED}
                      alt="Mahi Blink"
                      animate={{ 
                        opacity: (isBlinking || expression === 'sad' || expression === 'heartbroken') ? 1 : 0
                      }}
                      transition={{ duration: (expression === 'sad' || expression === 'heartbroken') ? 0.4 : 0.05 }}
                      className="absolute inset-0 w-full h-full object-cover object-top z-30 pointer-events-none"
                      referrerPolicy="no-referrer"
                    />
                  </Fragment>
                ) : (
                  /* GORGEOUS HIGH-TECH COGNITIVE ORB VISUALIZER */
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
                    {/* Concentric Sci-Fi Rotating Orbits */}
                    <motion.div 
                      className="absolute w-[85%] h-[85%] rounded-full border border-dashed"
                      style={{ borderColor: `${theme.primary}22` }}
                      animate={{ rotate: 360 }}
                      transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                    />
                    <motion.div 
                      className="absolute w-[75%] h-[75%] rounded-full border border-dashed"
                      style={{ borderColor: `${theme.secondary}33` }}
                      animate={{ rotate: -360 }}
                      transition={{ duration: 24, repeat: Infinity, ease: "linear" }}
                    />
                    
                    {/* Multiple wave expansion circles responding to speaker speech or mic sound */}
                    <AnimatePresence>
                      {animState === 'speaking' && (
                        <Fragment>
                          <motion.div 
                            initial={{ scale: 0.8, opacity: 0.8 }}
                            animate={{ scale: 1.5 + outputLevel * 1.5, opacity: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut" }}
                            className="absolute rounded-full w-48 h-48 border animate-pulse"
                            style={{ borderColor: theme.primary, filter: `blur(4px)` }}
                          />
                          <motion.div 
                            initial={{ scale: 0.9, opacity: 0.6 }}
                            animate={{ scale: 1.3 + outputLevel * 0.8, opacity: 0 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 2.0, repeat: Infinity, ease: "easeOut", delay: 0.5 }}
                            className="absolute rounded-full w-48 h-48 border animate-pulse"
                            style={{ borderColor: theme.secondary, filter: `blur(2px)` }}
                          />
                        </Fragment>
                      )}
                    </AnimatePresence>
                    
                    {/* Ring 1 - Outer Pulsing Boundary */}
                    <motion.div 
                      className="absolute rounded-full flex items-center justify-center"
                      style={{ 
                        width: '58%', 
                        height: '58%', 
                        border: `2px solid ${theme.primary}55`, 
                        boxShadow: `0 0 25px ${theme.primary}22` 
                      }}
                      animate={{
                        scale: animState === 'speaking' 
                          ? 1 + outputLevel * 0.3
                          : animState === 'listening' 
                            ? 1 + micLevel * 0.4
                            : [1, 1.05, 1],
                      }}
                      transition={{ duration: 2, repeat: animState === 'idle' ? Infinity : 0, ease: "easeInOut" }}
                    />

                    {/* Ring 2 - Inner Orbit */}
                    <motion.div 
                      className="absolute rounded-full"
                      style={{ 
                        width: '45%', 
                        height: '45%', 
                        border: `1px dashed ${theme.secondary}77`,
                        boxShadow: `inset 0 0 15px ${theme.secondary}11`
                      }}
                      animate={{
                        rotate: animState === 'speaking' ? 180 : -180,
                        scale: animState === 'speaking' 
                          ? 1 - outputLevel * 0.15
                          : animState === 'listening' 
                            ? 1 - micLevel * 0.2
                            : 1
                      }}
                    />

                    {/* Glowing Core Energy Ball with custom gradients and stateful blur maps */}
                    <motion.div 
                      className="absolute rounded-full flex items-center justify-center shadow-2xl"
                      style={{ 
                        width: '32%', 
                        height: '32%', 
                        background: animState === 'listening'
                          ? `radial-gradient(circle, ${theme.secondary} 0%, ${theme.secondary}55 60%, transparent 100%)`
                          : `radial-gradient(circle, ${theme.primary} 0%, ${theme.primary}55 60%, transparent 100%)`, 
                        boxShadow: animState === 'listening'
                          ? `0 0 50px ${theme.secondary}, inset 0 0 15px rgba(255,255,255,0.7)`
                          : `0 0 50px ${theme.primary}, inset 0 0 15px rgba(255,255,255,0.7)`
                      }}
                      animate={{
                        scale: animState === 'speaking' 
                          ? [1, 1.22 + (outputLevel * 1.5), 1] 
                          : animState === 'listening' 
                            ? [1, 1.15 + (micLevel * 1.8), 1] 
                            : [1, 1.05, 1],
                      }}
                      transition={{
                        duration: animState === 'idle' ? 3 : 0.25,
                        repeat: animState === 'idle' ? Infinity : 0,
                        ease: "easeInOut"
                      }}
                    >
                      {/* Active holographic sparkle element */}
                      <Sparkles className="w-5 h-5 text-white animate-pulse" />
                    </motion.div>

                    {/* Tiny particle satellites orbiting around core */}
                    <motion.div 
                      className="absolute w-2 h-2 rounded-full"
                      style={{ backgroundColor: theme.primary }}
                      animate={{
                        x: [40, -40, 40],
                        y: [-25, 25, -25],
                        scale: [0.8, 1.2, 0.8]
                      }}
                      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    />
                    <motion.div 
                      className="absolute w-1.5 h-1.5 rounded-full"
                      style={{ backgroundColor: theme.secondary }}
                      animate={{
                        x: [-50, 50, -50],
                        y: [30, -30, 30],
                        scale: [1.2, 0.7, 1.2]
                      }}
                      transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                    />
                  </div>
                )}
              </motion.div>
            </div>

            {/* Expression Overlays (Subtle Glows) */}
            <AnimatePresence>
              {expression === 'thinking' && (
                <Fragment key="exp-thinking">
                  <motion.div 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 0.3 }} 
                    exit={{ opacity: 0 }} 
                    className="absolute top-1/4 left-1/4 w-[50%] h-[50%] bg-indigo-500/20 blur-[80px] rounded-full z-0 p-4"
                  >
                    <motion.div 
                      key="thinking-spin"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                      className="w-full h-full border-2 border-dashed border-indigo-400/30 rounded-full"
                    />
                  </motion.div>
                  <motion.div 
                    key="thinking-aura"
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: [0.05, 0.15, 0.05] }} 
                    transition={{ duration: 3, repeat: Infinity }}
                    className="absolute inset-0 bg-white/10 blur-[120px] z-5" 
                  />
                </Fragment>
              )}
              {expression === 'happy' && (
                <Fragment key="exp-happy">
                  {/* Subtle blush overlays on standard avatar */}
                  <motion.div key="happy-blush-l" initial={{ opacity: 0 }} animate={{ opacity: 0.25 }} exit={{ opacity: 0 }} className="absolute top-[52%] left-[30%] w-[12%] h-[6%] bg-pink-400/35 blur-[15px] rounded-full z-40 pointer-events-none" />
                  <motion.div key="happy-blush-r" initial={{ opacity: 0 }} animate={{ opacity: 0.25 }} exit={{ opacity: 0 }} className="absolute top-[52%] left-[58%] w-[12%] h-[6%] bg-pink-400/35 blur-[15px] rounded-full z-40 pointer-events-none" />

                  {/* Bubble Pink/Golden Halo Glow */}
                  <motion.div 
                    key="happy-halo"
                    initial={{ opacity: 0, scale: 0.8 }} 
                    animate={{ opacity: [0.15, 0.3, 0.15], scale: [1, 1.05, 1] }} 
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute inset-0 bg-gradient-to-tr from-pink-500/10 via-amber-400/5 to-rose-500/15 blur-[100px] z-5 pointer-events-none" 
                  />

                  {/* Floating Hearts & Sparkles Particles (Emitted from the center/bottom) */}
                  <div className="absolute inset-0 z-30 pointer-events-none overflow-hidden flex items-center justify-center">
                    {[
                      { id: 1, x: -70, y: 120, delay: 0.1, duration: 3.5, size: 24, rotate: -15, color: 'text-pink-400' },
                      { id: 2, x: 80, y: 150, delay: 0.7, duration: 4.2, size: 16, rotate: 12, color: 'text-rose-400' },
                      { id: 3, x: -30, y: 80, delay: 1.5, duration: 3.8, size: 20, rotate: -8, color: 'text-pink-300' },
                      { id: 4, x: 40, y: 100, delay: 2.2, duration: 4.5, size: 14, rotate: 20, color: 'text-red-400' },
                      { id: 5, x: -90, y: 180, delay: 0.4, duration: 5.0, size: 18, rotate: -25, color: 'text-rose-300' },
                      { id: 6, x: 100, y: 60, delay: 1.9, duration: 3.9, size: 22, rotate: 5, color: 'text-pink-400' }
                    ].map((p) => (
                      <motion.div
                        key={`happy-heart-${p.id}`}
                        initial={{ opacity: 0, y: p.y + 100, x: p.x, scale: 0.5, rotate: p.rotate }}
                        animate={{ 
                          opacity: [0, 0.9, 0.9, 0], 
                          y: p.y - 180, 
                          x: [p.x, p.x + (p.id % 2 === 0 ? 15 : -15), p.x],
                          scale: [0.5, 1.1, 1, 0.6] 
                        }}
                        transition={{ 
                          duration: p.duration, 
                          repeat: Infinity, 
                          delay: p.delay, 
                          ease: "easeInOut" 
                        }}
                        className={`absolute ${p.color} filter drop-shadow-[0_0_8px_rgba(244,63,94,0.5)]`}
                      >
                        {p.id % 2 === 0 ? <Heart size={p.size} fill="currentColor" /> : <Sparkles size={p.size} />}
                      </motion.div>
                    ))}
                  </div>
                </Fragment>
              )}
              {expression === 'caring' && (
                <Fragment key="exp-caring">
                  {/* Calming emerald/rose aura layer */}
                  <motion.div 
                    key="caring-ambient"
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: [0.15, 0.35, 0.15] }} 
                    transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute inset-0 bg-gradient-to-b from-teal-500/10 via-emerald-400/5 to-pink-500/10 blur-[110px] z-5 pointer-events-none" 
                  />

                  {/* Soft blush highlights */}
                  <motion.div key="caring-blush-l" initial={{ opacity: 0 }} animate={{ opacity: 0.18 }} exit={{ opacity: 0 }} className="absolute top-[52%] left-[30%] w-[12%] h-[6%] bg-rose-400/20 blur-[18px] rounded-full z-40 pointer-events-none" />
                  <motion.div key="caring-blush-r" initial={{ opacity: 0 }} animate={{ opacity: 0.18 }} exit={{ opacity: 0 }} className="absolute top-[52%] left-[58%] w-[12%] h-[6%] bg-rose-400/20 blur-[18px] rounded-full z-40 pointer-events-none" />

                  {/* Rippling Soundwaves of Compassion / Care Rings around Core */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                    {[1, 2].map((ring) => (
                      <motion.div
                        key={`caring-ring-${ring}`}
                        initial={{ scale: 0.7, opacity: 0 }}
                        animate={{ 
                          scale: [0.8, 1.45], 
                          opacity: [0, 0.55, 0] 
                        }}
                        transition={{ 
                          duration: 3.5, 
                          repeat: Infinity, 
                          delay: ring * 1.7, 
                          ease: "easeOut" 
                        }}
                        className="absolute rounded-full w-[48%] h-[48%] border"
                        style={{ 
                          borderColor: ring === 1 ? 'rgba(52, 211, 153, 0.35)' : 'rgba(244, 114, 182, 0.3)',
                          boxShadow: ring === 1 ? '0 0 20px rgba(52, 211, 153, 0.15)' : '0 0 20px rgba(244, 114, 182, 0.15)',
                          filter: 'blur(1px)'
                        }}
                      />
                    ))}
                  </div>

                  {/* Warm Floating Comfort Sparkles & Hearts */}
                  <div className="absolute inset-0 z-30 pointer-events-none overflow-hidden flex items-center justify-center">
                    {[
                      { id: 1, x: -50, y: 140, delay: 0.3, duration: 4.5, size: 20, rotate: -10, color: 'text-emerald-300' },
                      { id: 2, x: 60, y: 100, delay: 1.2, duration: 5.0, size: 18, rotate: 15, color: 'text-pink-300' },
                      { id: 3, x: -80, y: 90, delay: 2.2, duration: 4.2, size: 15, rotate: -5, color: 'text-teal-300' },
                      { id: 4, x: 30, y: 160, delay: 0.8, duration: 4.8, size: 22, rotate: 18, color: 'text-rose-200' },
                      { id: 5, x: 90, y: 120, delay: 2.8, duration: 4.0, size: 16, rotate: -12, color: 'text-emerald-200' }
                    ].map((p) => (
                      <motion.div
                        key={`caring-item-${p.id}`}
                        initial={{ opacity: 0, y: p.y + 80, x: p.x, scale: 0.6, rotate: p.rotate }}
                        animate={{ 
                          opacity: [0, 0.8, 0.8, 0], 
                          y: p.y - 150, 
                          x: [p.x, p.x + (p.id % 2 === 0 ? 10 : -10), p.x],
                          scale: [0.6, 1.0, 1.0, 0.7] 
                        }}
                        transition={{ 
                          duration: p.duration, 
                          repeat: Infinity, 
                          delay: p.delay, 
                          ease: "easeInOut" 
                        }}
                        className={`absolute ${p.color} filter drop-shadow-[0_0_6px_rgba(52,211,153,0.3)]`}
                      >
                        {p.id % 2 === 0 ? <Heart size={p.size} fill="currentColor" className="opacity-80" /> : <Sparkles size={p.size} />}
                      </motion.div>
                    ))}
                  </div>
                </Fragment>
              )}
              {(expression === 'sad' || expression === 'heartbroken') && (
                <Fragment key="exp-sad-hb">
                  <motion.div 
                    key="sad-bg"
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: [0.2, expression === 'heartbroken' ? 0.8 : 0.4, 0.2] }} 
                    transition={{ duration: 1.2, repeat: Infinity }}
                    className={`absolute inset-0 ${expression === 'heartbroken' ? 'bg-indigo-950/60' : 'bg-blue-500/20'} blur-[120px] z-5`} 
                  />
                  {expression === 'heartbroken' && (
                    <div key="hb-vignette" className="absolute inset-0 z-50 pointer-events-none overflow-hidden">
                      <div className="absolute inset-0 bg-radial-gradient from-transparent via-indigo-900/10 to-indigo-950/40" />
                    </div>
                  )}
                </Fragment>
              )}
              {expression === 'excited' && (
                <motion.div 
                  key="exp-excited"
                  initial={{ opacity: 0 }} 
                  animate={{ scale: [1, 1.1, 1], opacity: 0.15 }} 
                  className="absolute inset-0 bg-yellow-400/10 blur-[80px] z-5" 
                />
              )}
              {expression === 'embarrassed' && (
                <Fragment key="exp-embarrassed">
                  <motion.div key="emb-blush-l" initial={{ opacity: 0 }} animate={{ opacity: 0.5 }} exit={{ opacity: 0 }} className="absolute top-[52%] left-[32%] w-[10%] h-[5%] bg-red-600/30 blur-[25px] rounded-full z-40" />
                  <motion.div key="emb-blush-r" initial={{ opacity: 0 }} animate={{ opacity: 0.5 }} exit={{ opacity: 0 }} className="absolute top-[52%] left-[58%] w-[10%] h-[5%] bg-red-600/30 blur-[25px] rounded-full z-40" />
                </Fragment>
              )}
              {expression === 'surprised' && (
                <motion.div 
                  key="exp-surprised"
                  initial={{ opacity: 0, scale: 0.8 }} 
                  animate={{ opacity: 0.1, scale: 1.5 }} 
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-white/20 blur-[100px] z-5" 
                />
              )}
              {expression === 'confused' && (
                <motion.div 
                  key="exp-confused"
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: [0.1, 0.2, 0.1] }} 
                  transition={{ duration: 2, repeat: Infinity }}
                  className="absolute inset-0 bg-indigo-500/10 blur-[100px] z-5" 
                />
              )}
            </AnimatePresence>
          </motion.div>
      </div>

      {/* Bottom HUD */}
      <div className="absolute bottom-0 left-0 right-0 h-60 bg-gradient-to-t from-black via-black/80 to-transparent flex flex-col items-center justify-end pb-12 z-40">
        
        {/* Waveform Visualization */}
        <div className="flex items-center gap-1.5 h-[60px] mb-8">
          <AnimatePresence>
            {isSpeaking ? (
              [...Array(12)].map((_, i) => (
                <motion.div
                  key={`speaking-${i}`}
                  initial={{ height: 4 }}
                  animate={{ 
                    height: [
                      Math.random() * 20 + 10, 
                      Math.random() * 40 + 20, 
                      Math.random() * 15 + 5
                    ],
                    opacity: [0.3, 0.8, 0.5]
                  }}
                  transition={{ duration: 0.4, repeat: Infinity, ease: "easeInOut", delay: i * 0.03 }}
                  className={`w-1 rounded-full ${i % 3 === 0 ? 'opacity-80' : 'opacity-50'}`}
                  style={{ 
                    backgroundColor: i % 3 === 0 ? theme.secondary : theme.primary,
                    boxShadow: i % 3 === 0 ? `0 0 10px ${theme.primary}` : 'none'
                  }}
                />
              ))
            ) : isListening ? (
              [...Array(8)].map((_, i) => (
                <motion.div
                  key={`listening-${i}`}
                  animate={{ 
                    height: Math.max(4, micLevel * 200 * (1 + Math.random())),
                    opacity: [0.2, 0.4, 0.2]
                  }}
                  transition={{ duration: 0.1 }}
                  className="w-1 rounded-full"
                  style={{ backgroundColor: theme.primary }}
                />
              ))
            ) : (
              <motion.div 
                key="visualizer-static" 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 0.2 }} 
                exit={{ opacity: 0 }}
                className="flex items-center gap-1.5 h-full"
              >
                {[20, 40, 55, 35, 50, 35, 25, 20].map((h, i) => (
                  <div key={`static-${i}`} className="w-1 rounded-full" style={{ height: `${h * 0.4}px`, backgroundColor: theme.primary }} />
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Controls Container */}
        <div className="flex items-center gap-6 relative z-50">
          {/* Upload Image Button */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            className="hidden"
          />
          <motion.button
            onClick={() => fileInputRef.current?.click()}
            whileHover={{ scale: 1.1, backgroundColor: `${theme.primary}33` }}
            whileTap={{ scale: 0.95 }}
            className={`w-14 h-14 rounded-2xl border ${theme.border} flex items-center justify-center cursor-pointer bg-black/60 shadow-[0_4px_20px_rgba(0,0,0,0.5)] backdrop-blur-lg transition-all duration-300 group`}
            title="Upload Image"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="24" height="24" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke={theme.primary} 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
              className="group-hover:opacity-80 transition-opacity"
            >
              <line x1="12" y1="5" x2="12" y2="19"/>
              <line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </motion.button>

          {/* Share Screen Button */}
          <motion.button
            onClick={toggleScreenShare}
            whileHover={{ scale: 1.1, backgroundColor: isScreenSharing ? `${theme.primary}4D` : `${theme.primary}33` }}
            whileTap={{ scale: 0.95 }}
            className={`
              w-14 h-14 rounded-2xl border flex items-center justify-center cursor-pointer
              bg-black/60 shadow-[0_4px_20px_rgba(0,0,0,0.5)] backdrop-blur-lg
              transition-all duration-300 group
              ${isScreenSharing ? 'shadow-[0_0_20px_rgba(0,0,0,0.2)]' : 'hover:border-white/40'}
            `}
            style={{ 
              borderColor: isScreenSharing ? theme.secondary : `${theme.primary}4D`,
              boxShadow: isScreenSharing ? `0 0 20px ${theme.glow}` : 'none'
            }}
            title={isScreenSharing ? "Sharing Screen" : "Share Screen"}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="22" height="22" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke={isScreenSharing ? theme.secondary : theme.primary} 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
              className="group-hover:opacity-80 transition-opacity"
            >
              <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
              <line x1="8" y1="21" x2="16" y2="21"/>
              <line x1="12" y1="17" x2="12" y2="21"/>
            </svg>
          </motion.button>

          {/* Mic Button / Trigger */}
          <div className="relative">
            <motion.button
              onClick={toggleMahi}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`
                w-[86px] h-[86px] rounded-full border-2 
                bg-white/5 flex items-center justify-center cursor-pointer 
                shadow-[0_0_40px_rgba(0,0,0,0.3)] relative overflow-hidden
                transition-colors duration-500
                ${isActive ? 'border-red-500/50' : 'border-white/10'}
              `}
              style={!isActive ? { borderColor: `${theme.primary}66` } : {}}
            >
              <motion.div 
                animate={isActive ? { scale: [1, 1.2, 1], opacity: [1, 0.8, 1] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-9 h-9 rounded-full shadow-lg transition-colors duration-500" 
                style={{ 
                  backgroundColor: isActive ? '#EF4444' : theme.primary,
                  boxShadow: `0 0 25px ${isActive ? '#EF4444' : theme.primary}`
                }}
              />
            </motion.button>
            
            {isActive && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-[10px] text-white/40 tracking-[2px] uppercase whitespace-nowrap"
              >
                Tap to Interrupt
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Enhanced Status/Error Display */}
      <AnimatePresence>
        {error && (
          <motion.div 
            key="status-error-overlay"
            initial={{ opacity: 0, y: -20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: -20, x: '-50%' }}
            className="fixed top-24 left-1/2 z-[100] w-[90%] max-w-sm"
          >
            <div className="bg-red-500/20 border border-red-500/40 backdrop-blur-xl p-4 rounded-2xl flex flex-col items-center gap-3 shadow-2xl overflow-hidden relative">
              <div className="absolute top-0 left-0 w-full h-1 bg-red-500/30 overflow-hidden">
                <motion.div 
                  className="h-full bg-red-500"
                  animate={{ x: ['-100%', '100%'] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                />
              </div>

              <button 
                onClick={() => setError(null)}
                className="absolute top-2.5 right-2.5 w-6 h-6 hover:bg-white/10 active:scale-95 text-white/70 hover:text-white rounded-full flex items-center justify-center transition-all outline-none"
                title="Dismiss"
              >
                <X size={14} />
              </button>
              
              <p className="text-white text-xs font-medium text-center leading-relaxed pr-6 pt-1">
                {error}
              </p>
              
              {(() => {
                const errLower = error?.toLowerCase() || "";
                const isMicOrScreenErr = errLower.includes("microphone") || 
                                          errLower.includes("mic") || 
                                          errLower.includes("screen") || 
                                          errLower.includes("capture") ||
                                          errLower.includes("permission") ||
                                          errLower.includes("denied") ||
                                          errLower.includes("allowed") ||
                                          errLower.includes("notallowed") ||
                                          error?.includes("માઇક") ||
                                          error?.includes("પરમિશન");
                return isMicOrScreenErr ? (
                  <div className="flex flex-col gap-2 w-full mt-1">
                    <a 
                      href={window.location.href} 
                      onClick={(e) => {
                        e.preventDefault();
                        window.open(window.location.href, '_blank');
                      }}
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-purple-600 hover:bg-purple-500 px-4 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-[2px] shadow-lg shadow-purple-500/20 transition-all active:scale-95 text-white flex items-center justify-center gap-2 text-center select-none cursor-pointer"
                    >
                      Open Standalone App 🚀
                    </a>
                    <button 
                      onClick={() => { stopMahi(); setTimeout(startMahi, 300); }}
                      className="bg-white/5 hover:bg-white/10 px-4 py-2 rounded-xl text-[9px] font-mono tracking-[1px] transition-all active:scale-95 text-white/70"
                    >
                      Retry in preview frame
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => { stopMahi(); setTimeout(startMahi, 300); }}
                    className="bg-white/10 hover:bg-white/20 px-6 py-2 rounded-xl text-[10px] font-bold uppercase tracking-[2px] transition-all active:scale-95 text-white"
                  >
                    Reset Connection
                  </button>
                );
              })()}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Screen Share Explanation Modal */}
      <AnimatePresence>
        {showScreenShareModal && (
          <Fragment>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowScreenShareModal(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-md z-[130] pointer-events-auto"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[140] w-[90%] max-w-sm bg-zinc-950/95 border border-purple-500/30 p-6 rounded-3xl flex flex-col items-center gap-5 shadow-[0_0_50px_rgba(168,85,247,0.15)] pointer-events-auto text-white font-sans text-center"
            >
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center bg-purple-500/10 border border-purple-500/30 text-purple-400">
                <Monitor className="w-7 h-7" />
              </div>

              <div>
                <h3 className="font-bold text-lg tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-300">
                  Mahi needs a new tab! 💻✨
                </h3>
                <p className="text-xs text-zinc-400 leading-relaxed mt-2.5 px-1">
                  Hey <strong>{prefsState.nickname || 'दीपक'}</strong>! Since we are chatting inside a preview box, the browser's security blocks screen sharing here.
                </p>
                <p className="text-xs text-zinc-400 leading-relaxed mt-2 px-1">
                  Open me in a standalone tab—there you can share your screen and show me what you are working on!
                </p>
              </div>

              <div className="flex flex-col gap-2 w-full mt-1">
                <a 
                  href={window.location.href} 
                  onClick={(e) => {
                    e.preventDefault();
                    window.open(window.location.href, '_blank');
                    setShowScreenShareModal(false);
                  }}
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-purple-600 hover:bg-purple-500 px-4 py-3 rounded-2xl text-[10px] font-bold uppercase tracking-[2px] shadow-lg shadow-purple-500/20 transition-all active:scale-95 text-white flex items-center justify-center gap-2 text-center select-none cursor-pointer"
                >
                  Open Standalone App 🚀
                </a>
                <button 
                  onClick={() => {
                    setShowScreenShareModal(false);
                    startScreenShare();
                  }}
                  className="bg-white/5 hover:bg-white/10 px-4 py-2.5 rounded-2xl text-[9px] font-mono tracking-[1px] transition-all active:scale-95 text-white/70"
                >
                  Try anyway in this frame
                </button>
                <button 
                  onClick={() => setShowScreenShareModal(false)}
                  className="bg-transparent hover:text-white px-4 py-1 text-[9px] font-mono tracking-[1px] transition-all text-white/40"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </Fragment>
        )}
      </AnimatePresence>

      {/* Sliding Diagnostics / Auto Test Side Panel */}
      <AnimatePresence>
        {showTestPanel && (
          <Fragment>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowTestPanel(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[110] pointer-events-auto"
            />

            {/* Panel Container */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-full max-w-md bg-zinc-950/95 backdrop-blur-2xl border-l border-white/10 z-[120] flex flex-col pointer-events-auto shadow-[-10px_0_40px_rgba(0,0,0,0.8)] text-white font-sans text-sm"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/[0.02]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-fuchsia-500/10 border border-fuchsia-500/30">
                    <Gauge className="w-4 h-4 text-fuchsia-400 animate-pulse" />
                  </div>
                  <div>
                    <h2 className="font-bold text-lg tracking-wider text-fuchsia-100 uppercase">Diagnostics Lab</h2>
                    <p className="text-[10px] font-mono opacity-50 uppercase tracking-widest">Automated Subsystem Verifier</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowTestPanel(false)}
                  className="p-1 px-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/15 transition-colors cursor-pointer text-zinc-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-white/10">
                {/* Visual Calibration Circle Meter */}
                <div className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl flex flex-col items-center justify-center text-center relative overflow-hidden">
                  <div className="absolute inset-0 opacity-[0.05] bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:10px_10px]" />
                  
                  {/* Dynamic Score Computation */}
                  {(() => {
                    let totalTests = 0;
                    let passCount = 0;
                    Object.values(testResults).forEach(val => {
                      if (val !== 'idle') totalTests++;
                      if (val === 'success') passCount++;
                    });
                    const healthScore = totalTests > 0 ? Math.round((passCount / totalTests) * 100) : 100;

                    return (
                      <Fragment>
                        <div className="relative w-32 h-32 flex items-center justify-center">
                          <div className={`absolute inset-0 rounded-full border border-dashed animate-spin ${isTestingSubsystems ? 'border-fuchsia-500/60' : 'border-zinc-700'}`} style={{ animationDuration: '8s' }} />
                          <div className={`absolute w-28 h-28 border border-dashed rounded-full animate-ping opacity-25 ${healthScore < 80 ? 'border-amber-400' : 'border-fuchsia-500/30'}`} />
                          
                          <div className="flex flex-col items-center">
                            <span className="text-3xl font-mono font-bold tracking-tighter text-white">
                              {isTestingSubsystems ? '---' : `${healthScore}%`}
                            </span>
                            <span className="text-[8px] uppercase tracking-widest text-zinc-400 font-mono mt-1">INTEGRITY</span>
                          </div>
                        </div>

                        <div className="mt-4">
                          <h3 className="font-semibold text-zinc-200">
                            {isTestingSubsystems ? 'Calibrating Subsystems...' : healthScore === 100 ? 'All Systems Operational' : 'Ready for Verification'}
                          </h3>
                          <p className="text-[10px] text-zinc-400 mt-1 max-w-[280px]">
                            Diagnostic score reflects hardware drivers, cloud persistence nodes, and WebSocket handshake speed.
                          </p>
                        </div>
                      </Fragment>
                    );
                  })()}
                </div>

                {/* Subsystem Health Cards Grid */}
                <div className="space-y-3">
                  <h4 className="text-[10px] font-mono uppercase tracking-widest text-zinc-400">Subsystem Checklist</h4>
                  
                  {/* Audio Engine (Speaker Sound) */}
                  <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Volume2 className={`w-4 h-4 ${testResults.speaker === 'success' ? 'text-green-400' : testResults.speaker === 'failed' ? 'text-rose-400' : 'text-zinc-400'}`} />
                      <div>
                        <div className="text-xs font-semibold text-zinc-100">Audio Output Node</div>
                        <div className="text-[10px] text-zinc-400 font-mono">Web Audio Synthesizer Synth</div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${
                      testResults.speaker === 'success' ? 'bg-green-500/10 border-green-500/20 text-green-400' :
                      testResults.speaker === 'failed' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400 animate-pulse' :
                      testResults.speaker === 'testing' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400 animate-pulse' :
                      'bg-white/5 border-white/5 text-zinc-500'
                    }`}>
                      {testResults.speaker === 'success' ? 'CHIME_OK' : testResults.speaker === 'failed' ? 'ERROR' : testResults.speaker === 'testing' ? 'PULSING' : 'READY'}
                    </span>
                  </div>

                  {/* Audio Input (Microphone) */}
                  <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Mic className={`w-4 h-4 ${testResults.mic === 'success' ? 'text-green-400' : testResults.mic === 'failed' ? 'text-rose-400' : 'text-zinc-400'}`} />
                      <div>
                        <div className="text-xs font-semibold text-zinc-100">Microphone Input Core</div>
                        {isTestingSubsystems && testResults.mic === 'testing' ? (
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="text-[10px] text-amber-400 font-mono">dB Level:</span>
                            <div className="w-16 h-1 bg-zinc-800 rounded-full overflow-hidden">
                              <div className="h-full bg-amber-400 transition-all duration-75" style={{ width: `${Math.min(100, micTestLevel * 1000)}%` }} />
                            </div>
                          </div>
                        ) : (
                          <div className="text-[10px] text-zinc-400 font-mono">Voice capture capture window</div>
                        )}
                      </div>
                    </div>
                    <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${
                      testResults.mic === 'success' ? 'bg-green-500/10 border-green-500/20 text-green-400' :
                      testResults.mic === 'failed' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400 animate-pulse' :
                      testResults.mic === 'testing' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400 animate-pulse' :
                      'bg-white/5 border-white/5 text-zinc-500'
                    }`}>
                      {testResults.mic === 'success' ? 'CAPTURED' : testResults.mic === 'failed' ? 'DENIED' : testResults.mic === 'testing' ? 'LISTENING' : 'READY'}
                    </span>
                  </div>

                  {/* Camera Node */}
                  <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Video className={`w-4 h-4 ${testResults.camera === 'success' ? 'text-green-400' : testResults.camera === 'failed' ? 'text-rose-400' : 'text-zinc-400'}`} />
                      <div>
                        <div className="text-xs font-semibold text-zinc-100">Sensory Camera Lens</div>
                        <div className="text-[10px] text-zinc-400 font-mono">Vision Link input channel</div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${
                      testResults.camera === 'success' ? 'bg-green-500/10 border-green-500/20 text-green-400' :
                      testResults.camera === 'failed' ? 'bg-rose-500/10 border-rose-500/20 text-rose-300' :
                      testResults.camera === 'testing' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400 animate-pulse' :
                      'bg-white/5 border-white/5 text-zinc-500'
                    }`}>
                      {testResults.camera === 'success' ? 'ONLINE' : testResults.camera === 'failed' ? 'OFFLINE' : testResults.camera === 'testing' ? 'CALIBRATING' : 'READY'}
                    </span>
                  </div>

                  {/* Firebase Cloud Sync */}
                  <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Database className={`w-4 h-4 ${testResults.firebase === 'success' ? 'text-green-400' : testResults.firebase === 'failed' ? 'text-rose-400' : 'text-zinc-400'}`} />
                      <div>
                        <div className="text-xs font-semibold text-zinc-100">Firestore Cloud Memory</div>
                        <div className="text-[10px] text-zinc-400 font-mono">Permanent diary synced logs</div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${
                      testResults.firebase === 'success' ? 'bg-green-500/10 border-green-500/20 text-green-400' :
                      testResults.firebase === 'failed' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400 animate-pulse' :
                      testResults.firebase === 'testing' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400 animate-pulse' :
                      'bg-white/5 border-white/5 text-zinc-500'
                    }`}>
                      {testResults.firebase === 'success' ? 'SYNCED' : testResults.firebase === 'failed' ? 'OFFLINE' : testResults.firebase === 'testing' ? 'PINGING' : 'READY'}
                    </span>
                  </div>

                  {/* Supabase Secondary Sync */}
                  <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Database className={`w-4 h-4 ${testResults.supabase === 'success' ? 'text-green-400' : testResults.supabase === 'failed' ? 'text-zinc-500' : 'text-zinc-400'}`} />
                      <div>
                        <div className="text-xs font-semibold text-zinc-100">Supabase Node Node</div>
                        <div className="text-[10px] text-zinc-400 font-mono">Secondary variables validation</div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${
                      testResults.supabase === 'success' ? 'bg-green-500/10 border-green-500/20 text-green-400' :
                      testResults.supabase === 'failed' ? 'bg-white/5 border-white/5 text-zinc-500' :
                      testResults.supabase === 'testing' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400 animate-pulse' :
                      'bg-white/5 border-white/5 text-zinc-500'
                    }`}>
                      {testResults.supabase === 'success' ? 'ONLINE' : testResults.supabase === 'failed' ? 'LOCAL_ONLY' : testResults.supabase === 'testing' ? 'CALCULATING' : 'READY'}
                    </span>
                  </div>

                  {/* Gemini Socket */}
                  <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Zap className={`w-4 h-4 ${testResults.gemini === 'success' ? 'text-green-400' : testResults.gemini === 'failed' ? 'text-rose-400' : 'text-zinc-400'}`} />
                      <div>
                        <div className="text-xs font-semibold text-zinc-100">Core AI WebSocket Pipeline</div>
                        <div className="text-[10px] text-zinc-400 font-mono">Live voice response latency</div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${
                      testResults.gemini === 'success' ? 'bg-green-500/10 border-green-500/20 text-green-400' :
                      testResults.gemini === 'failed' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400 animate-pulse' :
                      testResults.gemini === 'testing' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400 animate-pulse' :
                      'bg-white/5 border-white/5 text-zinc-500'
                    }`}>
                      {testResults.gemini === 'success' ? `${geminiLatency ? `${geminiLatency}ms` : 'LINK_OK'}` : testResults.gemini === 'failed' ? 'FAILED' : testResults.gemini === 'testing' ? 'HANDSHAKING' : 'READY'}
                    </span>
                  </div>
                </div>

                {/* Micro Terminal Feed Logs */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-mono tracking-widest text-zinc-400">
                    <span>LIVE PROGRESS FEED</span>
                    {isTestingSubsystems && <span className="text-fuchsia-400 animate-pulse font-bold">CALIBRATING IN PROGRESS...</span>}
                  </div>
                  <div className="bg-black/60 border border-white/5 rounded-2xl p-4 h-40 overflow-y-auto space-y-1.5 scrollbar-thin scrollbar-thumb-white/10 font-mono text-[10px] text-zinc-400">
                    {testLogs.length === 0 ? (
                      <div className="text-zinc-600 italic">No diagnostic run initiated yet. Press the comprehensive test button below.</div>
                    ) : (
                      testLogs.map((log, idx) => (
                        <div key={idx} className="last:text-fuchsia-300">
                          {log}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Run Trigger Button Footer */}
              <div className="p-6 border-t border-white/10 bg-black/40 flex flex-col gap-3">
                <button
                  disabled={isTestingSubsystems}
                  onClick={runDiagnostics}
                  className={`w-full bg-fuchsia-600 hover:bg-fuchsia-500 text-white font-mono uppercase tracking-[2px] py-4.5 rounded-2xl transition-all shadow-lg active:scale-95 disabled:opacity-40 disabled:pointer-events-none flex items-center justify-center gap-2 cursor-pointer text-xs`}
                >
                  {isTestingSubsystems ? (
                    <Fragment>
                      <RefreshCw size={14} className="animate-spin" />
                      <span>Calibrating...</span>
                    </Fragment>
                  ) : (
                    <Fragment>
                      <Gauge size={14} />
                      <span>Execute Comprehensive Test</span>
                    </Fragment>
                  )}
                </button>
              </div>
            </motion.div>
          </Fragment>
        )}
      </AnimatePresence>

      {/* Sliding EQ Empathy Radar Side Panel */}
      <AnimatePresence>
        {showEQPanel && (
          <Fragment>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowEQPanel(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[110] pointer-events-auto"
            />

            {/* Panel Container */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 left-0 h-full w-full max-w-md bg-zinc-950/95 backdrop-blur-2xl border-r border-white/10 z-[120] flex flex-col pointer-events-auto shadow-[10px_0_40px_rgba(0,0,0,0.8)] text-white font-sans text-sm"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/[0.02]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-emerald-500/10 border border-emerald-500/30">
                    <HeartHandshake className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <h2 className="font-bold text-lg tracking-wider text-emerald-100 uppercase">EQ Empathy Radar</h2>
                    <p className="text-[10px] font-mono opacity-50 uppercase tracking-widest text-[#10B981]">Cognitive & Expressive Telemetry</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowEQPanel(false)}
                  className="p-1 px-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/15 transition-colors cursor-pointer text-zinc-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Scrollable EQ Monitoring Sandbox */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-white/10">
                <p className="text-xs text-emerald-200/70 leading-relaxed bg-emerald-500/5 p-3 rounded-xl border border-emerald-950/40">
                  Mahi interprets your voice tone, pacing, and lexical subtleties. She then uses high emotional intelligence (EQ) to craft responses that offer profound empathy, matching or balancing your vibes.
                </p>

                {/* Animated Resonance Aura Orbit */}
                <div className="bg-black/80 rounded-3xl border border-white/10 p-6 flex flex-col items-center justify-center relative overflow-hidden h-56">
                  {/* Outer breathing shell */}
                  <motion.div 
                    animate={{ scale: [1, 1.12, 1], rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    className="absolute w-44 h-44 rounded-full border border-dashed border-emerald-500/20 flex items-center justify-center"
                  />
                  
                  {/* Dynamic Gradient Blobs depending on expression */}
                  <motion.div 
                    animate={{ 
                      scale: [1, 1.25, 1], 
                      opacity: [0.15, 0.35, 0.15] 
                    }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute w-32 h-32 rounded-full bg-gradient-to-tr from-emerald-500/20 to-[#a7f3d0]/10 blur-[25px]"
                  />

                  {/* Inner Orbit core displaying Sync metrics */}
                  <div className="relative z-10 flex flex-col items-center">
                    <Activity size={32} className="text-emerald-400 animate-pulse mb-2.5" />
                    <span className="text-2xl font-black font-mono tracking-widest text-emerald-300">{eqSyncValue}%</span>
                    <span className="text-[9px] font-mono tracking-[3px] text-zinc-400 uppercase mt-1">Empathetic Sync</span>
                  </div>

                  {/* Ring lines mapping dynamic sync status */}
                  <div className="absolute bottom-3 left-4 right-4 flex justify-between text-[8px] font-mono text-zinc-500">
                    <span>BANDWIDTH: 1.6MBPS</span>
                    <span>PROSODY: SYNCHRONIZED</span>
                  </div>
                </div>

                {/* Empathetic Radar Real-time telemetry items */}
                <div className="space-y-4">
                  {/* Item 1: Vibe mood assessment */}
                  <div className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl flex flex-col justify-between gap-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-[#10B981] flex items-center gap-1.5">
                        <Gauge size={12} className="text-emerald-400" />
                        <span>Detected User Atmosphere</span>
                      </span>
                      <span className="text-[9px] px-2.5 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-mono rounded-full font-bold">
                        ACTIVE EVAL
                      </span>
                    </div>
                    <div className="text-[#E0F2FE] font-bold text-base mt-1 flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
                      {userVibe}
                    </div>
                    <p className="text-[10px] text-zinc-500 font-sans leading-relaxed mt-1.5">
                      Vibe decoded from semantic phrasing and prosody features of your speech signal.
                    </p>
                  </div>

                  {/* Item 2: Strategy action */}
                  <div className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl flex flex-col justify-between gap-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 flex items-center gap-1.5">
                        <Sparkles size={12} className="text-[#34D399]" />
                        <span>Empathetic Calibrator</span>
                      </span>
                      <span className="text-[8px] font-mono text-zinc-500">CALIBRATING</span>
                    </div>
                    <div className="text-emerald-100 font-bold text-sm mt-1">
                      {empathyAction}
                    </div>
                    <p className="text-[10px] text-zinc-500 font-sans leading-relaxed mt-1.5">
                      Calibrating voice prosody parameters, sweetness, and emotional stance for balanced interaction.
                    </p>
                  </div>

                  {/* Item 3: Deep Sync Narrative */}
                  <div className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl flex flex-col justify-between gap-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-indigo-300 flex items-center gap-1.5">
                        <Brain size={12} className="text-indigo-400" />
                        <span>Mahi's Emotional Narrative</span>
                      </span>
                    </div>
                    <p className="text-xs text-indigo-100/90 leading-relaxed font-sans mt-1 bg-white/[0.01] p-3 rounded-xl border border-white/[0.03]">
                      "{eqAnalysisMsg}"
                    </p>
                  </div>
                </div>

                {/* Interactive Vibe Playground Prompt Buttons (Suggestions) */}
                <div className="space-y-3 pt-2">
                  <h3 className="text-xs font-mono uppercase tracking-widest text-zinc-400 flex items-center gap-1.5 px-0.5">
                    <Sliders size={12} className="text-emerald-400" />
                    <span>Empathy Playground Triggers</span>
                  </h3>
                  <p className="text-[10px] text-zinc-500 leading-normal px-0.5">
                    Trigger she's emotional adaptations by talking on different wavelengths. Try verbalizing these scripts:
                  </p>

                  <div className="grid grid-cols-1 gap-2">
                    <div className="bg-white/5 border border-white/15 p-3 rounded-xl hover:bg-white/[0.08] transition-colors">
                      <div className="text-[10px] font-mono text-[#F43F5E] mb-1 font-bold">😭 HEALING INQUIRY (Trigger Caring)</div>
                      <p className="text-xs text-zinc-300">"Suno Mahi, today was an incredibly exhausting and stressed out day for me..."</p>
                    </div>

                    <div className="bg-white/5 border border-white/15 p-3 rounded-xl hover:bg-white/[0.08] transition-colors">
                      <div className="text-[10px] font-mono text-[#10B981] mb-1 font-bold">✨ JOLLY & PLAYFUL (Trigger Sassy/Teasing)</div>
                      <p className="text-xs text-zinc-300">"Mahi, I just got promoted or won my match! Let's celebrate!"</p>
                    </div>

                    <div className="bg-white/5 border border-white/15 p-3 rounded-xl hover:bg-white/[0.08] transition-colors">
                      <div className="text-[10px] font-mono text-[#D8B4FE] mb-1 font-bold">🍭 COZY COMPANION (Say Cute Secret)</div>
                      <p className="text-xs text-zinc-300">"Mahi, you have literally the sweetest voice and sweetest soul on planet earth."</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            </Fragment>
          )}
        </AnimatePresence>

      {/* Sliding Virtual Smartphone Settings Side Panel */}
      <AnimatePresence>
        {showPhoneControl && (
          <Fragment>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPhoneControl(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[110] pointer-events-auto"
            />

            {/* Panel Container */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 left-0 h-full w-full max-w-md bg-zinc-950/95 backdrop-blur-2xl border-r border-white/10 z-[120] flex flex-col pointer-events-auto shadow-[10px_0_40px_rgba(0,0,0,0.8)] text-white font-sans text-sm"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/[0.02]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-blue-500/10 border border-blue-500/30">
                    <Smartphone className="w-4 h-4 text-blue-400 animate-pulse" />
                  </div>
                  <div>
                    <h2 className="font-bold text-lg tracking-wider text-blue-100 uppercase">Device Assistant</h2>
                    <p className="text-[10px] font-mono opacity-50 uppercase tracking-widest">Global Voice Control Sandbox</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowPhoneControl(false)}
                  className="p-1 px-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/15 transition-colors cursor-pointer text-zinc-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Scrollable Smartphone Mockup Grid */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-white/10">
                <p className="text-xs text-blue-200/70 leading-relaxed bg-blue-500/5 p-3 rounded-xl border border-blue-950/40">
                  Tell Mahi: <strong>"Mahi, screen brightness full kar do"</strong>, <strong>"turn on flashlight"</strong>, or <strong>"volume mute"</strong>. She will adjust these features instantaneously via live tool-calling!
                </p>

                {/* Device Mockup Shell */}
                <div className="bg-black/80 rounded-3xl border border-white/10 p-5 shadow-inner relative overflow-hidden flex flex-col gap-5">
                  {/* Glossy line effect */}
                  <div className="absolute top-0 right-0 left-0 h-24 bg-gradient-to-b from-white/[0.03] to-transparent pointer-events-none" />
                  
                  {/* Torch Light Flare Simulation */}
                  {phoneSettings.flashlight && (
                    <div 
                      className="absolute -top-12 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full blur-[40px] pointer-events-none mix-blend-screen animate-pulse" 
                      style={{ background: 'radial-gradient(circle, rgba(234,179,8,0.3) 0%, rgba(234,179,8,0.01) 70%)' }}
                    />
                  )}

                  {/* Top Status Indicators inside Phone mockup */}
                  <div className="flex justify-between items-center text-[10px] font-mono text-zinc-400 border-b border-white/5 pb-2.5">
                    <div className="flex items-center gap-1.5">
                      <span>{deviceTime || '09:20 AM'}</span>
                      <span className="text-[8px] opacity-30">•</span>
                      <span>Active Link</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Wifi className={`w-3.5 h-3.5 transition-colors ${phoneSettings.wifi ? 'text-blue-400' : 'text-zinc-600'}`} />
                      <Bluetooth className={`w-3.5 h-3.5 transition-colors ${phoneSettings.bluetooth ? 'text-purple-400' : 'text-zinc-600'}`} />
                      <div className="flex items-center gap-0.5">
                        <Battery className={`w-4 h-4 transition-colors ${phoneSettings.batterySaver ? 'text-green-500' : 'text-blue-400'}`} />
                        <span className="text-[9px]">{phoneSettings.batterySaver ? '35%' : '88%'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Simulated Live Grid Controls */}
                  <div className="grid grid-cols-2 gap-3.5 text-zinc-100">
                    {/* Box 1: Volume */}
                    <div className="bg-white/[0.03] border border-white/5 p-4 rounded-2xl flex flex-col justify-between h-28 relative">
                      <div className="flex justify-between items-start">
                        <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
                          <Volume2 className="w-4 h-4" />
                        </div>
                        <span className="text-[10px] font-mono text-blue-300 font-bold">{phoneSettings.volume}%</span>
                      </div>
                      <div>
                        <span className="text-[11px] font-bold block">Volume Level</span>
                        <div className="w-full bg-zinc-800 h-1 rounded-full mt-2 overflow-hidden">
                          <div className="bg-blue-400 h-full transition-all duration-300" style={{ width: `${phoneSettings.volume}%` }} />
                        </div>
                      </div>
                      <input 
                        type="range"
                        min="0"
                        max="100"
                        value={phoneSettings.volume}
                        onChange={(e) => setPhoneSettings(prev => ({ ...prev, volume: parseInt(e.target.value) }))}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                    </div>

                    {/* Box 2: Brightness */}
                    <div className="bg-white/[0.03] border border-white/5 p-4 rounded-2xl flex flex-col justify-between h-28 relative">
                      <div className="flex justify-between items-start">
                        <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                          <Sun className="w-4 h-4" />
                        </div>
                        <span className="text-[10px] font-mono text-amber-300 font-bold">{phoneSettings.brightness}%</span>
                      </div>
                      <div>
                        <span className="text-[11px] font-bold block">Screen Bright</span>
                        <div className="w-full bg-zinc-800 h-1 rounded-full mt-2 overflow-hidden">
                          <div className="bg-amber-400 h-full transition-all duration-300" style={{ width: `${phoneSettings.brightness}%` }} />
                        </div>
                      </div>
                      <input 
                        type="range"
                        min="0"
                        max="100"
                        value={phoneSettings.brightness}
                        onChange={(e) => setPhoneSettings(prev => ({ ...prev, brightness: parseInt(e.target.value) }))}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                    </div>

                    {/* Toggle 3: Wifi Toggle */}
                    <button 
                      onClick={() => setPhoneSettings(prev => ({ ...prev, wifi: !prev.wifi }))}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-24 transition-all duration-300 ${phoneSettings.wifi ? 'bg-blue-500/10 border-blue-500/30' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                    >
                      <Wifi className={`w-5 h-5 ${phoneSettings.wifi ? 'text-blue-400' : 'text-zinc-500'}`} />
                      <div>
                        <span className="text-[11px] font-bold block">Wi-Fi Network</span>
                        <span className="text-[9px] text-zinc-400 font-mono">{phoneSettings.wifi ? 'Connected' : 'Disconnected'}</span>
                      </div>
                    </button>

                    {/* Toggle 4: Bluetooth Toggle */}
                    <button 
                      onClick={() => setPhoneSettings(prev => ({ ...prev, bluetooth: !prev.bluetooth }))}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-24 transition-all duration-300 ${phoneSettings.bluetooth ? 'bg-purple-500/10 border-purple-500/30' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                    >
                      <Bluetooth className={`w-5 h-5 ${phoneSettings.bluetooth ? 'text-purple-400' : 'text-zinc-500'}`} />
                      <div>
                        <span className="text-[11px] font-bold block">Bluetooth Link</span>
                        <span className="text-[9px] text-zinc-400 font-mono">{phoneSettings.bluetooth ? 'Searching' : 'Off'}</span>
                      </div>
                    </button>

                    {/* Toggle 5: Do Not Disturb */}
                    <button 
                      onClick={() => setPhoneSettings(prev => ({ ...prev, dnd: !prev.dnd }))}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-24 transition-all duration-300 ${phoneSettings.dnd ? 'bg-red-500/10 border-red-500/30' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                    >
                      <Moon className={`w-5 h-5 ${phoneSettings.dnd ? 'text-red-400' : 'text-zinc-500'}`} />
                      <div>
                        <span className="text-[11px] font-bold block">Do Not Disturb</span>
                        <span className="text-[9px] text-zinc-400 font-mono">{phoneSettings.dnd ? 'Enabled' : 'Disabled'}</span>
                      </div>
                    </button>

                    {/* Toggle 6: Flashlight */}
                    <button 
                      onClick={() => setPhoneSettings(prev => ({ ...prev, flashlight: !prev.flashlight }))}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between h-24 transition-all duration-300 ${phoneSettings.flashlight ? 'bg-amber-500/10 border-amber-500/30 shadow-[0_0_15px_rgba(245,158,11,0.2)]' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                    >
                      <Zap className={`w-5 h-5 ${phoneSettings.flashlight ? 'text-amber-400 animate-bounce' : 'text-zinc-500'}`} />
                      <div>
                        <span className="text-[11px] font-bold block">Torch Light</span>
                        <span className="text-[9px] text-zinc-400 font-mono">{phoneSettings.flashlight ? 'Shining 🔦' : 'Off'}</span>
                      </div>
                    </button>
                  </div>

                  {/* More quick triggers */}
                  <div className="grid grid-cols-3 gap-2 border-t border-white/5 pt-4">
                    <button 
                      onClick={() => setPhoneSettings(prev => ({ ...prev, batterySaver: !prev.batterySaver }))}
                      className={`py-2 px-1 rounded-xl text-center border transition-all ${phoneSettings.batterySaver ? 'bg-green-500/10 border-green-500/20 text-green-400' : 'bg-white/[0.02] border-white/5 text-zinc-400'}`}
                    >
                      <span className="text-[9px] font-mono block">Power Saver</span>
                      <span className="text-[8px] opacity-60 font-mono leading-none">{phoneSettings.batterySaver ? 'ON' : 'OFF'}</span>
                    </button>
                    
                    <button 
                      onClick={() => setPhoneSettings(prev => ({ ...prev, mobileData: !prev.mobileData }))}
                      className={`py-2 px-1 rounded-xl text-center border transition-all ${phoneSettings.mobileData ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400' : 'bg-white/[0.02] border-white/5 text-zinc-400'}`}
                    >
                      <span className="text-[9px] font-mono block">Mobile Data</span>
                      <span className="text-[8px] opacity-60 font-mono leading-none">{phoneSettings.mobileData ? 'ON' : 'OFF'}</span>
                    </button>

                    <button 
                      onClick={() => setPhoneSettings(prev => ({ ...prev, screenLock: !prev.screenLock }))}
                      className={`py-2 px-1 rounded-xl text-center border transition-all ${phoneSettings.screenLock ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-white/[0.02] border-white/5 text-zinc-400'}`}
                    >
                      <span className="text-[9px] font-mono block">Screen Lock</span>
                      <span className="text-[8px] opacity-60 font-mono leading-none">{phoneSettings.screenLock ? 'LOCKED' : 'FREE'}</span>
                    </button>
                  </div>

                  {/* Advanced System Tuner */}
                  <div className="border-t border-white/5 pt-3.5 space-y-3">
                    <div className="flex justify-between items-center px-0.5">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-[#60A5FA]">Advanced Hardware</span>
                      <span className="text-[9px] font-mono opacity-40 uppercase">Full System Console</span>
                    </div>
                    
                    {/* Ringtone Volume slider */}
                    <div className="bg-white/[0.02] border border-white/5 p-3 rounded-2xl flex flex-col justify-between h-20 relative text-left">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-[11px] font-bold block">🎵 Ringtone Volume</span>
                        <span className="text-[10px] font-mono text-zinc-400 font-bold">{phoneSettings.ringtoneVolume}%</span>
                      </div>
                      <div className="w-full bg-zinc-800 h-1 rounded-full overflow-hidden">
                        <div className="bg-[#60A5FA] h-full transition-all duration-300" style={{ width: `${phoneSettings.ringtoneVolume}%` }} />
                      </div>
                      <input 
                        type="range"
                        min="0"
                        max="100"
                        value={phoneSettings.ringtoneVolume}
                        onChange={(e) => setPhoneSettings(prev => ({ ...prev, ringtoneVolume: parseInt(e.target.value) }))}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-zinc-200">
                      {/* Vibration button */}
                      <button 
                        onClick={() => {
                          const val = !phoneSettings.vibration;
                          setPhoneSettings(prev => ({ ...prev, vibration: val }));
                          if (val && navigator.vibrate) {
                            navigator.vibrate([100, 50, 100]);
                          }
                        }}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between h-16 transition-all ${phoneSettings.vibration ? 'bg-amber-500/10 border-amber-500/20 text-amber-300 animate-pulse' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                      >
                        <span className="text-[10px] font-mono">VIBRATION</span>
                        <span className="text-xs font-semibold">{phoneSettings.vibration ? 'ACTIVE 📳' : 'MUTED'}</span>
                      </button>

                      {/* Hotspot Button */}
                      <button 
                        onClick={() => setPhoneSettings(prev => ({ ...prev, hotspot: !prev.hotspot }))}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between h-16 transition-all ${phoneSettings.hotspot ? 'bg-orange-500/10 border-orange-500/20 text-orange-300' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                      >
                        <span className="text-[10px] font-mono">HOTSPOT</span>
                        <span className="text-xs font-semibold">{phoneSettings.hotspot ? 'BROADCASTING' : 'STANDBY'}</span>
                      </button>

                      {/* Silent Mode button */}
                      <button 
                        onClick={() => setPhoneSettings(prev => ({ ...prev, silentMode: !prev.silentMode }))}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between h-16 transition-all ${phoneSettings.silentMode ? 'bg-rose-500/10 border-rose-500/20 text-rose-300' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                      >
                        <span className="text-[10px] font-mono">SILENT PROFILE</span>
                        <span className="text-xs font-semibold">{phoneSettings.silentMode ? 'SILENT 🔕' : 'RINGING 🔔'}</span>
                      </button>

                      {/* GPS Location button */}
                      <button 
                        onClick={() => {
                          const nextVal = !phoneSettings.location;
                          setPhoneSettings(prev => ({ ...prev, location: nextVal }));
                          if (nextVal && navigator.geolocation) {
                            navigator.geolocation.getCurrentPosition(
                              (pos) => {
                                setGpsData({
                                  lat: pos.coords.latitude,
                                  lng: pos.coords.longitude,
                                  address: 'Kamrej Road, Laskana, Surat, Gujarat, India',
                                  accuracy: Math.round(pos.coords.accuracy)
                                });
                              },
                              (err) => {
                                console.warn('Browser GPS permission blocked/denied:', err);
                              }
                            );
                          }
                        }}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between h-16 transition-all ${phoneSettings.location ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-300' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                      >
                        <span className="text-[10px] font-mono">GPS CHIP</span>
                        <span className="text-xs font-semibold">{phoneSettings.location ? 'LINKED 📡' : 'DISABLED'}</span>
                      </button>

                      {/* Airplane mode button */}
                      <button 
                        onClick={() => setPhoneSettings(prev => ({ ...prev, airplaneMode: !prev.airplaneMode }))}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between h-16 transition-all ${phoneSettings.airplaneMode ? 'bg-yellow-500/10 border-yellow-500/20 text-yellow-300' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                      >
                        <span className="text-[10px] font-mono">AIRPLANE MODE</span>
                        <span className="text-xs font-semibold">{phoneSettings.airplaneMode ? 'ENGAGED ✈️' : 'DISENGAGED'}</span>
                      </button>

                      {/* Auto Rotate button */}
                      <button 
                        onClick={() => setPhoneSettings(prev => ({ ...prev, autoRotate: !prev.autoRotate }))}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between h-16 transition-all ${phoneSettings.autoRotate ? 'bg-teal-500/10 border-teal-500/20 text-teal-300' : 'bg-white/[0.02] border-white/5 opacity-70'}`}
                      >
                        <span className="text-[10px] font-mono">ORIENTATION</span>
                        <span className="text-xs font-semibold">{phoneSettings.autoRotate ? 'AUTO-ROTATE' : 'PORTRAIT'}</span>
                      </button>
                    </div>

                    {/* Live GPS / Map Telemetry Widget */}
                    {phoneSettings.location && (
                      <div className="bg-cyan-950/20 border border-cyan-500/15 p-3 rounded-xl text-left space-y-2 relative overflow-hidden">
                        <div className="absolute right-2 top-2 w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping" />
                        <div className="flex items-center gap-1.5 text-cyan-300">
                          <span className="text-[10px]">📡</span>
                          <span className="text-[9px] font-mono uppercase tracking-widest font-bold">Active GPS Ground Link</span>
                        </div>
                        
                        <div className="space-y-1">
                          <div className="text-xs font-semibold text-white/95 truncate">
                            {gpsData.address}
                          </div>
                          <div className="flex items-center gap-3.5 text-[9px] text-zinc-400 font-mono">
                            <div>
                              <span className="text-zinc-600">LAT:</span>{' '}
                              <span className="text-cyan-400">{gpsData.lat.toFixed(5)}</span>
                            </div>
                            <div>
                              <span className="text-zinc-600">LON:</span>{' '}
                              <span className="text-cyan-400">{gpsData.lng.toFixed(5)}</span>
                            </div>
                            <div>
                              <span className="text-zinc-600">ACC:</span>{' '}
                              <span className="text-emerald-400">±{gpsData.accuracy || 15}m</span>
                            </div>
                          </div>
                        </div>

                        {/* Interactive Map Visual Mockup */}
                        <div className="h-14 w-full rounded-lg bg-zinc-950/50 border border-white/5 relative overflow-hidden flex items-center justify-center">
                          {/* Grid mock */}
                          <div className="absolute inset-0 opacity-[0.05] bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:8px_8px]" />
                          {/* Radial map waves */}
                          <div className="absolute w-28 h-28 border border-cyan-500/10 rounded-full animate-ping opacity-60" />
                          <div className="absolute w-16 h-16 border border-cyan-500/15 rounded-full" />
                          
                          {/* Pin */}
                          <div className="relative z-10 flex flex-col items-center">
                            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 border border-zinc-950 flex items-center justify-center shadow-lg">
                              <div className="w-1 h-1 rounded-full bg-white" />
                            </div>
                            <span className="text-[7.5px] font-mono text-cyan-300 mt-1 uppercase font-bold tracking-wider">Popat Rd Spot</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Screen Timeout Select */}
                    <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl flex items-center justify-between text-left">
                      <div>
                        <span className="text-[11px] font-bold block">⌛ Screen Timeout</span>
                        <span className="text-[9px] text-zinc-500 font-mono">Duration before sleep</span>
                      </div>
                      <select 
                        value={phoneSettings.screenTimeout} 
                        onChange={(e) => setPhoneSettings(prev => ({ ...prev, screenTimeout: parseInt(e.target.value) }))}
                        className="bg-zinc-900 border border-white/10 rounded px-2.5 py-1 text-xs font-mono text-zinc-300 focus:outline-none focus:border-blue-500 cursor-pointer"
                      >
                        <option value="15">15 seconds</option>
                        <option value="30">30 seconds</option>
                        <option value="60">1 minute</option>
                        <option value="120">2 minutes</option>
                        <option value="300">5 minutes</option>
                      </select>
                    </div>

                    {/* Permissions & Auth Section (File Manager & Admin Privileges) */}
                    <div className="border-t border-white/5 pt-3.5 space-y-3">
                      <div className="flex justify-between items-center px-0.5">
                        <span className="text-[10px] font-mono uppercase tracking-widest text-[#A78BFA]">Permissions & Auth</span>
                        <span className="text-[9px] font-mono opacity-40 uppercase">જરૂરી પરવાનગી</span>
                      </div>

                      <div className="grid grid-cols-1 gap-2.5">
                        {/* File Manager Permission Toggle */}
                        <button 
                          onClick={() => setPhoneSettings(prev => ({ ...prev, fileManagerPermission: !prev.fileManagerPermission }))}
                          className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all duration-300 ${phoneSettings.fileManagerPermission ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300 shadow-[0_0_15px_rgba(99,102,241,0.1)]' : 'bg-white/[0.02] border-white/5 opacity-75'}`}
                        >
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-xl border ${phoneSettings.fileManagerPermission ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400' : 'bg-white/5 border-white/10 text-zinc-500'}`}>
                              <Save size={16} />
                            </div>
                            <div>
                              <span className="text-xs font-bold block">ફાઈલ મેનેજર પરમિશન</span>
                              <span className="text-[10px] text-zinc-400 font-mono">Mahi File Manager Permission</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`text-[9px] font-mono px-2 py-0.5 rounded border ${phoneSettings.fileManagerPermission ? 'bg-indigo-500/20 border-indigo-500/40 text-indigo-300' : 'bg-white/5 border-white/10 text-zinc-500'}`}>
                              {phoneSettings.fileManagerPermission ? 'GRANTED (મંજૂર)' : 'DENIED (નામંજૂર)'}
                            </span>
                            <div className={`w-8 h-4 rounded-full p-0.5 transition-colors ${phoneSettings.fileManagerPermission ? 'bg-indigo-500' : 'bg-zinc-700'}`}>
                              <div className={`w-3 h-3 bg-white rounded-full transition-transform ${phoneSettings.fileManagerPermission ? 'translate-x-4' : 'translate-x-0'}`} />
                            </div>
                          </div>
                        </button>

                        {/* Admin Privilege Permission Toggle */}
                        <button 
                          onClick={() => setPhoneSettings(prev => ({ ...prev, adminPermission: !prev.adminPermission }))}
                          className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all duration-300 ${phoneSettings.adminPermission ? 'bg-fuchsia-500/10 border-fuchsia-500/30 text-fuchsia-300 shadow-[0_0_15px_rgba(217,70,239,0.1)]' : 'bg-white/[0.02] border-white/5 opacity-75'}`}
                        >
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-xl border ${phoneSettings.adminPermission ? 'bg-fuchsia-500/10 border-fuchsia-500/20 text-fuchsia-400' : 'bg-white/5 border-white/10 text-zinc-500'}`}>
                              <Sliders size={16} />
                            </div>
                            <div>
                              <span className="text-xs font-bold block">એડમીન પરમિશન</span>
                              <span className="text-[10px] text-zinc-400 font-mono">Mahi Admin Permission</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`text-[9px] font-mono px-2 py-0.5 rounded border ${phoneSettings.adminPermission ? 'bg-fuchsia-500/20 border-fuchsia-500/40 text-fuchsia-300' : 'bg-white/5 border-white/10 text-zinc-500'}`}>
                              {phoneSettings.adminPermission ? 'ADMIN_OK (મંજૂર)' : 'STANDARD (સામાન્ય)'}
                            </span>
                            <div className={`w-8 h-4 rounded-full p-0.5 transition-colors ${phoneSettings.adminPermission ? 'bg-fuchsia-500' : 'bg-zinc-700'}`}>
                              <div className={`w-3 h-3 bg-white rounded-full transition-transform ${phoneSettings.adminPermission ? 'translate-x-4' : 'translate-x-0'}`} />
                            </div>
                          </div>
                        </button>
                      </div>
                    </div>

                    {/* APK Download & Mobile App Installer Section */}
                    <div className="border-t border-white/5 pt-3.5 space-y-3">
                      <div className="flex justify-between items-center px-0.5">
                        <span className="text-[10px] font-mono uppercase tracking-widest text-[#f472b6] flex items-center gap-1.5 font-bold">
                          <Smartphone size={12} className="text-[#f472b6]" />
                          <span>🤖 APK Build & Mobile App</span>
                        </span>
                        <span className="text-[8.5px] font-mono opacity-50 uppercase tracking-widest bg-pink-500/10 text-pink-300 border border-pink-500/20 px-1.5 py-0.5 rounded font-bold">
                          STABLE v2.0
                        </span>
                      </div>

                      <div className="bg-gradient-to-br from-pink-950/20 via-black/40 to-[#0c0a09] border border-pink-500/15 rounded-2xl p-4 space-y-3.5 text-left relative overflow-hidden">
                        <div className="absolute top-0 right-0 h-16 w-16 bg-gradient-to-bl from-pink-500/5 to-transparent pointer-events-none" />

                        <div className="space-y-1">
                          <h4 className="text-xs font-bold text-pink-300">રિયલ ફોન માટે ડાઉનલોડ કરો (Mobile APP)</h4>
                          <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
                            Mahi AI ને તમારા સાચા મોબાઇલમાં એક રિયલ એપની જેમ રન કરવા માટે અહીંથી સત્તાવાર <strong>APK Package</strong> જનરેટ કરીને ડાઉનલોડ કરો!
                          </p>
                        </div>

                        {isCompilingApk ? (
                          /* Compiling loading progress */
                          <div className="space-y-3 p-3.5 bg-black/50 rounded-xl border border-pink-500/20">
                            <div className="flex justify-between items-center text-[10px] font-mono">
                              <span className="text-pink-400 animate-pulse font-bold">🔨 COMPILING APK STAGE...</span>
                              <span className="text-zinc-400 font-bold">{apkProgress}%</span>
                            </div>
                            <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden border border-white/5 p-0.5">
                              <div 
                                className="bg-gradient-to-r from-pink-500 to-indigo-500 h-full rounded-full transition-all duration-300"
                                style={{ width: `${apkProgress}%` }}
                              />
                            </div>
                            <div className="max-h-24 overflow-y-auto space-y-1 bg-black/60 p-2 rounded-lg scrollbar-thin scrollbar-thumb-white/10 font-mono text-[9px] text-[#A78BFA]/90">
                              {apkCompileLogs.map((log, idx) => (
                                <div key={idx} className="line-clamp-1">
                                  {log}
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : apkCompiled ? (
                          /* Download options on success compile */
                          <div className="space-y-3">
                            <div className="bg-emerald-950/20 border border-emerald-500/20 p-3 rounded-xl flex items-start gap-2 text-left">
                              <span className="text-emerald-400 text-sm">✅</span>
                              <div>
                                <h5 className="text-[11px] font-bold text-emerald-400 uppercase font-mono tracking-wider">APK Compiled Successfully!</h5>
                                <p className="text-[10px] text-zinc-300 leading-relaxed mt-0.5">
                                  Production signed build generated successfully and mapped with active Firebase cloud sync.
                                </p>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2 text-xs">
                              <button
                                onClick={() => {
                                  // Create a simulated mobile direct installer text file blob
                                  const text = `===========================================
MAHI AI COMPANION SMARTPHONE APP (v2.0_STABLE)
===========================================
Thank you ${prefsState.nickname || 'user'} for downloading!

[INSTALLATION INSTRUCTIONS]
1. Since Mahi AI is a modern Progressive Mobile Desktop Hybrid Web Applet, the most secure, responsive, and recommended way to run her on any Android/iOS smartphone as a full standalone app is:
   - Copy this URL: ${window.location.origin}
   - Open this url in your Google Chrome (Android) or Safari (iOS) browser on your phone.
   - Tap the Options Menu (Three Dots at the top-right / Share Icon at the bottom).
   - Scroll and click "Add to Home Screen" or "Install App".
   - Done! This sets up a perfect standalone Mobile App launcher icon on your smartphone.
   - The app runs in borderless, full-screen hardware-accelerated viewport with active Cloud database sync!
   
Enjoy with Mahi!
===========================================`;
                                  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
                                  const url = URL.createObjectURL(blob);
                                  const element = document.createElement('a');
                                  element.href = url;
                                  element.download = 'Mahi_Companion_v2.0_APK_Guide.txt';
                                  document.body.appendChild(element);
                                  element.click();
                                  document.body.removeChild(element);
                                  URL.revokeObjectURL(url);
                                }}
                                className="bg-pink-600 hover:bg-pink-500 text-white font-bold py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-[0_0_12px_rgba(236,72,153,0.3)] cursor-pointer text-[11px]"
                              >
                                <Download size={13} />
                                <span>Save APK Info</span>
                              </button>

                              <button
                                onClick={() => {
                                  alert("🤖 PWA Launcher Instructions: Copy this applet's URL to your phone's browser & select 'Add to Home Screen' for standalone mobile app experience!");
                                }}
                                className="bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-300 font-semibold py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer text-center text-[10px] font-mono"
                              >
                                <span>PWA INFO</span>
                              </button>
                            </div>

                            {/* Standard PWA Mobile Steps Detail card */}
                            <div className="bg-black/40 border border-white/5 rounded-xl p-3 text-left space-y-2">
                              <h5 className="text-[10px] font-mono font-bold text-indigo-300 uppercase">📱 Real PWA Install Guide:</h5>
                              <ol className="text-[10px] text-zinc-400 space-y-1 list-decimal pl-4 leading-relaxed font-sans">
                                <li>તમારા ફોનની Chrome / Safari બ્રાઉઝરમાં સાઇટ લિંક ખોલો.</li>
                                <li>બ્રાઉઝર મેનુ (ત્રણ ટપકાં) પર ક્લિક કરો.</li>
                                <li><strong>"Add to Home Screen"</strong> અથવા <strong>"Install App"</strong> સિલેક્ટ કરો.</li>
                                <li>આ પદ્ધતિ પ્લે-સ્ટોર વગર સીધી તમારા ફોનમાં હોમસ્ક્રીન પર <strong>Mahi App Launcher</strong> સેટ કરશે!</li>
                              </ol>
                            </div>
                          </div>
                        ) : (
                          /* Initial State trigger button */
                          <div className="space-y-2">
                            <button
                              onClick={startApkCompilation}
                              className="w-full bg-pink-600/25 hover:bg-pink-600/35 border border-pink-500/30 text-pink-300 hover:text-white font-bold font-mono py-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm text-xs"
                            >
                              <Smartphone size={15} className="animate-pulse" />
                              <span>BUILD & GENERATE MOBILE APK</span>
                            </button>
                            <p className="text-[9px] font-mono text-zinc-500 text-center uppercase tracking-wider">
                              PROPERTIES: FULLSCREEN VIEWPORT • ZERO LOSS COMPILING • SHA256 SECURED CERT
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Mahi Smart File Manager Widget (ફાઈલ મેનેજર પરમિશન) */}
                <div className="space-y-4 pt-4 border-t border-white/5">
                  <div className="flex justify-between items-center px-0.5">
                    <h3 className="text-xs font-mono uppercase tracking-widest text-[#A78BFA] flex items-center gap-1.5 font-bold">
                      <Folder size={14} className="text-[#A78BFA]" />
                      <span>Smart File Manager</span>
                    </h3>
                    <span className="text-[9px] font-mono opacity-50 uppercase tracking-widest bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded">
                      {isSyncingFiles ? "SYNCING..." : "CLOUD SYNCED ⚡"}
                    </span>
                  </div>

                  {!phoneSettings.fileManagerPermission ? (
                    /* Locked State */
                    <div className="bg-indigo-950/20 border border-white/5 rounded-2xl p-6 text-center space-y-3">
                      <div className="w-12 h-12 rounded-full border border-[#A78BFA]/20 bg-[#A78BFA]/10 flex items-center justify-center mx-auto text-[#A78BFA] animate-pulse">
                        <Lock size={20} />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-xs font-bold text-[#C084FC]">ફાઈલ મેનેજર લોક છે</h4>
                        <p className="text-[11px] text-zinc-400 leading-relaxed px-2">
                          Mahi ને ડેટા સેવ કરવા અને એક્સેસ કરવા માટે ઉપરથી <strong>"ફાઈલ મેનેજર પરમિશન"</strong> મંજૂર કરો!
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setPhoneSettings(prev => ({ ...prev, fileManagerPermission: true }));
                          const newLog = {
                            id: `log_${Date.now()}`,
                            command: 'User clicked to grant File manager permission manually',
                            timestamp: new Date().toLocaleTimeString(),
                            result: '📁 File Manager Access Granted'
                          };
                          setVoiceCommandLogs(prev => [newLog, ...prev]);
                        }}
                        className="mx-auto flex items-center gap-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 rounded-xl px-3.5 py-1.5 text-xs text-indigo-300 transition-all font-semibold font-mono cursor-pointer"
                      >
                        <Zap size={12} />
                        <span>GRANT ACCESS NOW</span>
                      </button>
                    </div>
                  ) : (
                    /* Active File Manager State */
                    <div className="space-y-4">
                      {/* Search & Actions Bar */}
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Search size={13} className="absolute left-3 top-3 text-zinc-500" />
                          <input 
                            type="text"
                            placeholder="ફાઇલો શોધો..."
                            value={fileSearchQuery}
                            onChange={(e) => setFileSearchQuery(e.target.value)}
                            className="bg-black/50 border border-white/10 rounded-xl pl-8 pr-3 py-2 text-xs w-full font-mono text-zinc-200 focus:outline-none focus:border-indigo-400/50"
                          />
                        </div>
                        <button
                          onClick={() => {
                            setNewFileName('');
                            setNewFileContent('');
                            setIsCreatingFile(prev => !prev);
                          }}
                          className="px-3 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 rounded-xl text-indigo-300 transition-all cursor-pointer flex items-center gap-1 text-xs"
                        >
                          <Plus size={14} />
                          <span className="font-mono text-[10px]">નવી ફાઈલ</span>
                        </button>
                      </div>

                      {/* Create New File Form Dialog block */}
                      <AnimatePresence>
                        {isCreatingFile && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="bg-white/[0.02] border border-indigo-500/20 rounded-2xl p-4 space-y-3 text-left overflow-hidden"
                          >
                            <h4 className="text-[11px] font-mono text-indigo-300 uppercase tracking-wider font-semibold">
                              📁 નવી ફાઈલ સેવ કરો
                            </h4>
                            
                            <div className="grid grid-cols-2 gap-2 text-xs">
                              <div>
                                <label className="text-[10px] text-zinc-400 block mb-1">ફાઇલ નામ</label>
                                <input 
                                  type="text" 
                                  placeholder="Mahi_Notes"
                                  value={newFileName}
                                  onChange={(e) => setNewFileName(e.target.value)}
                                  className="bg-black/60 border border-white/10 rounded-lg px-2.5 py-1.5 w-full font-mono text-zinc-200 focus:outline-none focus:border-indigo-400"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-zinc-400 block mb-1">કેટેગરી</label>
                                <select 
                                  value={newFileCategory}
                                  onChange={(e) => setNewFileCategory(e.target.value as any)}
                                  className="bg-black/60 border border-white/10 rounded-lg px-2.5 py-1.5 w-full font-mono text-zinc-200 focus:outline-none focus:border-indigo-400 cursor-pointer"
                                >
                                  <option value="text">Text (.txt)</option>
                                  <option value="system">System (.sys)</option>
                                  <option value="log">Log (.log)</option>
                                  <option value="image">Snapshot (.png)</option>
                                </select>
                              </div>
                            </div>

                            <div>
                              <label className="text-[10px] text-zinc-400 block mb-1">ડેટા સામગ્રી (File Content)</label>
                              <textarea
                                placeholder="અહીં ડેટા લખો..."
                                value={newFileContent}
                                onChange={(e) => setNewFileContent(e.target.value)}
                                rows={3}
                                className="bg-black/60 border border-white/10 rounded-lg px-2.5 py-1.5 w-full font-mono text-zinc-200 text-xs focus:outline-none focus:border-indigo-400"
                              />
                            </div>

                            <div className="flex justify-end gap-2 text-xs">
                              <button 
                                onClick={() => setIsCreatingFile(false)}
                                className="px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-zinc-400 hover:text-white transition-all"
                              >
                                Cancel
                              </button>
                              <button 
                                onClick={handleCreateVirtualFile}
                                disabled={!newFileName.trim()}
                                className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-600 disabled:opacity-50 text-white rounded-xl font-bold transition-all flex items-center gap-1 cursor-pointer"
                              >
                                <Save size={13} />
                                <span>Save in Cloud</span>
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Selected File Details View */}
                      <AnimatePresence>
                        {selectedVirtualFile && (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="bg-indigo-950/10 border border-indigo-500/20 rounded-2xl p-4 text-left space-y-3 shadow-inner relative overflow-hidden"
                          >
                            <div className="absolute right-0 top-0 h-16 w-16 bg-gradient-to-bl from-indigo-500/5 to-transparent pointer-events-none" />
                            
                            <div className="flex justify-between items-start gap-2 border-b border-white/5 pb-2">
                              <div>
                                <span className="text-[8px] font-mono uppercase bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-400/20 tracking-wider">
                                  {selectedVirtualFile.category}
                                </span>
                                <h4 className="text-xs font-bold text-white font-mono mt-1 break-all select-all">
                                  {selectedVirtualFile.name}
                                </h4>
                              </div>
                              <button
                                onClick={() => setSelectedVirtualFile(null)}
                                className="p-1 hover:bg-white/10 rounded-lg text-zinc-500 hover:text-white transition-all cursor-pointer"
                              >
                                <X size={14} />
                              </button>
                            </div>

                            {/* Viewable/Editable Content Area */}
                            <div className="space-y-1">
                              <span className="text-[9px] text-zinc-500 font-mono">FILE DATA CONTENT (ડેટા સામગ્રી)</span>
                              <textarea
                                value={selectedVirtualFile.content}
                                onChange={(e) => {
                                  const updatedText = e.target.value;
                                  setSelectedVirtualFile(prev => prev ? { ...prev, content: updatedText } : null);
                                }}
                                rows={4}
                                className="bg-black/60 border border-white/5 focus:border-indigo-500/40 rounded-xl p-3 w-full font-mono text-[11px] text-indigo-200/90 leading-relaxed focus:outline-none"
                              />
                            </div>

                            <div className="flex justify-between items-center text-[10px] text-zinc-500 font-mono">
                              <span>કદ: <span className="text-zinc-400 font-bold">{selectedVirtualFile.size}</span></span>
                              <span>તારીખ: <span className="text-zinc-400 font-bold">{new Date(selectedVirtualFile.createdAt).toLocaleDateString()}</span></span>
                            </div>

                            <div className="flex gap-2 text-xs pt-1">
                              {/* Save edits */}
                              <button
                                onClick={async () => {
                                  if (!selectedVirtualFile) return;
                                  setIsSyncingFiles(true);
                                  try {
                                    const saved = await saveVirtualFile(selectedVirtualFile);
                                    setVirtualFiles(prev => prev.map(f => f.id === saved.id ? saved : f));
                                    const newLog = {
                                      id: `log_${Date.now()}`,
                                      command: `Modifying user file ${saved.name}`,
                                      timestamp: new Date().toLocaleTimeString(),
                                      result: `📝 File Saved: ${saved.name}`
                                    };
                                    setVoiceCommandLogs(prev => [newLog, ...prev]);
                                  } catch (err) {
                                    console.error(err);
                                  } finally {
                                    setIsSyncingFiles(false);
                                  }
                                }}
                                className="flex-1 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 py-2 rounded-xl flex items-center justify-center gap-1 font-mono font-bold transition-all cursor-pointer"
                              >
                                <Save size={13} />
                                <span>Save</span>
                              </button>

                              {/* Download as real file to device */}
                              <button
                                onClick={() => {
                                  if (!selectedVirtualFile) return;
                                  try {
                                    const blob = new Blob([selectedVirtualFile.content], { type: 'text/plain;charset=utf-8' });
                                    const url = URL.createObjectURL(blob);
                                    const element = document.createElement('a');
                                    element.href = url;
                                    element.download = selectedVirtualFile.name;
                                    document.body.appendChild(element);
                                    element.click();
                                    document.body.removeChild(element);
                                    URL.revokeObjectURL(url);
                                  } catch (err) {
                                    console.warn('Simulated download fallback', err);
                                  }
                                }}
                                className="px-3 bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-300 py-2 rounded-xl flex items-center justify-center gap-1 transition-all cursor-pointer"
                                title="તમારા રિયલ ડિવાઇસ પર ડાઉનલોડ કરો"
                              >
                                <Download size={13} className="text-emerald-400" />
                              </button>

                              {/* Delete */}
                              <button
                                onClick={() => {
                                  if (selectedVirtualFile?.id) {
                                    handleDeleteVirtualFile(selectedVirtualFile.id);
                                  }
                                }}
                                className="px-3 bg-red-950/20 hover:bg-red-500/20 border border-red-500/20 text-red-400 py-2 rounded-xl flex items-center justify-center transition-all cursor-pointer"
                                title="ફાઇલ ડિલીટ કરો"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* File Grid Directory list */}
                      <div className="bg-black/50 border border-white/10 rounded-2xl p-3 max-h-60 overflow-y-auto space-y-2.5 scrollbar-thin scrollbar-thumb-white/10">
                        {virtualFiles.filter(f => f.name.toLowerCase().includes(fileSearchQuery.toLowerCase())).length === 0 ? (
                          <div className="text-center font-mono py-6 text-zinc-600 text-xs">
                            કોઈ ફાઈલો મળી નથી.
                          </div>
                        ) : (
                          virtualFiles.filter(f => f.name.toLowerCase().includes(fileSearchQuery.toLowerCase())).map(file => {
                            const isSelected = selectedVirtualFile?.id === file.id;
                            return (
                              <button
                                key={file.id}
                                onClick={() => setSelectedVirtualFile(file)}
                                className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all duration-200 cursor-pointer ${
                                  isSelected 
                                    ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300' 
                                    : 'bg-white/[0.01] border-white/5 hover:border-indigo-500/20 hover:bg-white/[0.03] text-zinc-300'
                                }`}
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <div className={`p-1.5 rounded-lg border ${
                                    file.category === 'system' ? 'bg-orange-500/5 border-orange-500/10 text-orange-400' :
                                    file.category === 'log' ? 'bg-blue-500/5 border-blue-500/10 text-blue-400' :
                                    file.category === 'image' ? 'bg-rose-500/5 border-rose-500/10 text-rose-400' :
                                    'bg-indigo-500/5 border-indigo-500/10 text-indigo-400'
                                  }`}>
                                    {file.category === 'system' ? <Sliders size={13} /> :
                                     file.category === 'log' ? <Database size={13} /> :
                                     file.category === 'image' ? <Eye size={13} /> :
                                     <FileText size={13} />}
                                  </div>
                                  <div className="min-w-0">
                                    <span className="text-[11px] font-bold block truncate font-mono select-none">{file.name}</span>
                                    <span className="text-[8.5px] text-zinc-500 font-mono block uppercase">
                                      {file.category} • {file.size}
                                    </span>
                                  </div>
                                </div>
                                <span className="text-[8px] font-mono text-zinc-600 font-semibold">
                                  {new Date(file.createdAt).toLocaleDateString()}
                                </span>
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Real-time Voice Controller Log list */}
                <div className="space-y-3 pt-2">
                  <h3 className="text-xs font-mono uppercase tracking-widest text-zinc-400 flex items-center gap-1.5 px-0.5">
                    <Database size={12} className="text-blue-400" />
                    <span>Voice Command Telemetry</span>
                  </h3>

                  <div className="bg-black/60 border border-white/10 rounded-2xl p-4 h-60 overflow-y-auto space-y-3.5 scrollbar-thin scrollbar-thumb-white/10 font-mono">
                    {voiceCommandLogs.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-zinc-600 text-xs py-5">
                        No voice signals compiled yet.
                      </div>
                    ) : (
                      voiceCommandLogs.map(log => (
                        <div key={log.id} className="text-[11px] border-b border-white/[0.03] pb-2.5 last:border-0 last:pb-0">
                          <div className="flex justify-between text-[9px] opacity-40 mb-1">
                            <span>{log.command}</span>
                            <span>{log.timestamp}</span>
                          </div>
                          <div className="text-blue-300 font-semibold flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse inline-block" />
                            {log.result}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </Fragment>
        )}
      </AnimatePresence>

      {/* Sliding Memory Core Side Panel */}
      <AnimatePresence>
        {showMemoryPanel && (
          <Fragment>
            {/* Background Backdrop blur */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMemoryPanel(false)}
              className="fixed inset-0 bg-black/45 backdrop-blur-sm z-[110] pointer-events-auto"
            />

            {/* Panel Container */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-full max-w-md bg-black/95 backdrop-blur-2xl border-l border-white/10 z-[120] flex flex-col pointer-events-auto shadow-[-10px_0_40px_rgba(0,0,0,0.8)] text-white font-sans text-sm"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/[0.02]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-purple-500/10 border border-purple-500/30">
                    <Brain className="w-4 h-4 text-purple-400 animate-pulse" />
                  </div>
                  <div>
                    <h2 className="font-bold text-lg tracking-wider text-pink-100 uppercase">Memory Core</h2>
                    <p className="text-[10px] font-mono opacity-50 uppercase tracking-widest">Preferences & logs</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowMemoryPanel(false)}
                  className="p-1 px-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/15 transition-colors cursor-pointer text-gray-400 hover:text-white animate-none"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-white/5 bg-white/[0.01]">
                <button
                  onClick={() => setActiveTab('prefs')}
                  className={`flex-1 py-4 text-center font-mono text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
                    activeTab === 'prefs' 
                      ? 'border-purple-500 text-purple-200 bg-purple-500/5 font-semibold' 
                      : 'border-transparent text-gray-400 hover:text-gray-200'
                  }`}
                >
                  Mahi's Brain
                </button>
                <button
                  onClick={() => setActiveTab('logs')}
                  className={`flex-1 py-4 text-center font-mono text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
                    activeTab === 'logs' 
                      ? 'border-purple-500 text-purple-200 bg-purple-500/5 font-semibold' 
                      : 'border-transparent text-gray-400 hover:text-gray-200'
                  }`}
                >
                  Memory Logs ({pastSessions.length})
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-white/10">
                {activeTab === 'prefs' ? (
                  <div className="space-y-5">
                    {/* Intro text */}
                    <p className="text-xs text-gray-400 leading-relaxed bg-white/5 p-3 rounded-xl border border-white/[0.05]">
                      Mahi uses these values to model her personality, recognize you, and adapt her conversational tones instantly.
                    </p>

                    {/* Supabase Integration Dashboard Banner */}
                    {supabaseStatus.configured ? (
                      <div className="bg-emerald-950/20 border border-emerald-500/25 p-3 rounded-xl text-left space-y-1.5 relative overflow-hidden">
                        <div className="absolute right-2 top-2 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                        <div className="flex items-center gap-1.5 text-emerald-300">
                          <span className="text-[11px]">⚡</span>
                          <span className="text-[9px] font-mono uppercase tracking-widest font-bold">Supabase Memory Link Active</span>
                        </div>
                        <div className="text-[11px] text-zinc-300">
                          Mahi's brain is linked to your private Supabase cloud database! Past conversations and preferences are securely saved.
                        </div>
                        <div className="text-[8px] font-mono text-emerald-400/80 truncate">
                          Project Endpoint: {supabaseStatus.supabaseUrl}
                        </div>
                      </div>
                    ) : (
                      <div className="bg-amber-950/15 border border-amber-500/20 p-3.5 rounded-xl text-left space-y-2 relative overflow-hidden">
                        <div className="flex items-center gap-1.5 text-amber-300">
                          <span className="text-[12px]">🧠</span>
                          <span className="text-[9px] font-mono uppercase tracking-widest font-bold">Supabase: Setup Steps</span>
                        </div>
                        <p className="text-[11px] text-zinc-300 leading-relaxed">
                          Follow these quick steps to sync Mahi's memories with your new Supabase project:
                        </p>
                        <ol className="text-[10px] text-zinc-400 space-y-1.5 list-decimal pl-4 font-sans">
                          <li>Click on the <strong>Settings</strong> button at the top/side of this browser workspace window.</li>
                          <li>Configure these environment variables: <code className="text-amber-200 bg-white/5 px-1 rounded">SUPABASE_URL</code> and <code className="text-amber-200 bg-white/5 px-1 rounded">SUPABASE_ANON_KEY</code>.</li>
                          <li>Open the <code className="text-purple-300 bg-white/5 px-1 rounded">supabase-setup.sql</code> tab, copy SQL, and paste it into your Supabase SQL Editor block to create DB tables!</li>
                        </ol>
                        <div className="text-[9px] bg-white/5 p-1 px-2 rounded text-zinc-400 text-center uppercase tracking-wider font-mono">
                          Using Firestore/Local fallback temporarily
                        </div>
                      </div>
                    )}

                    {/* Field: Full Name */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-widest text-indigo-300">Your Full Name</label>
                      <input
                        type="text"
                        value={prefsState.username}
                        onChange={(e) => setPrefsState(prev => ({ ...prev, username: e.target.value }))}
                        placeholder="e.g. दीपक ठाकुर"
                        className="w-full bg-white/5 hover:bg-white/[0.08] focus:bg-black border border-white/10 focus:border-purple-500/65 rounded-xl px-4 py-2.5 font-sans text-sm text-gray-100 outline-none transition-all"
                      />
                    </div>

                    {/* Field: Nickname */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-widest text-indigo-300">Preferred Nickname (Mahi Calls You This)</label>
                      <input
                        type="text"
                        value={prefsState.nickname}
                        onChange={(e) => setPrefsState(prev => ({ ...prev, nickname: e.target.value }))}
                        placeholder="e.g. दीपक, माँही के प्रिय"
                        className="w-full bg-white/5 hover:bg-white/[0.08] focus:bg-black border border-white/10 focus:border-purple-500/65 rounded-xl px-4 py-2.5 font-sans text-sm text-gray-100 outline-none transition-all"
                      />
                    </div>

                    {/* Field: Relationship */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-widest text-indigo-300">Relationship Dynamic</label>
                      <select
                        value={prefsState.relationship}
                        onChange={(e) => setPrefsState(prev => ({ ...prev, relationship: e.target.value }))}
                        className="w-full bg-white/5 hover:bg-white/[0.08] focus:bg-black border border-white/10 focus:border-purple-500/65 rounded-xl px-4 py-2.5 font-sans text-sm text-white outline-none transition-all cursor-pointer"
                      >
                        <option value="Sweet & Playful Companion">Sweet & Playful Companion</option>
                        <option value="Loving Childhood Besties">Loving Childhood Besties</option>
                        <option value="Sassy Tsundere & Master">Sassy Tsundere & Master</option>
                        <option value="Cute Overbearing Girlfriend (Tsundere vibe)">Cute Overbearing Girlfriend</option>
                        <option value="Quiet Mentor & Caring Confidante">Quiet Mentor & Caring Confidante</option>
                      </select>
                    </div>

                    {/* Field: Sassyness level */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-[10px] font-mono uppercase tracking-widest text-indigo-300">
                        <span>Sassyness/Tsundere Level</span>
                        <span className="text-pink-400 font-bold">{prefsState.sassyness}/10</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[10px] font-mono text-gray-500">Sweet</span>
                        <input
                          type="range"
                          min="0"
                          max="10"
                          value={prefsState.sassyness}
                          onChange={(e) => setPrefsState(prev => ({ ...prev, sassyness: parseInt(e.target.value) }))}
                          className="flex-1 accent-purple-500 cursor-pointer"
                        />
                        <span className="text-[10px] font-mono text-gray-500">Sassy</span>
                      </div>
                    </div>

                    {/* Field: Interests */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-widest text-indigo-300">Interests & Hobbies</label>
                      <input
                        type="text"
                        value={prefsState.interests}
                        onChange={(e) => setPrefsState(prev => ({ ...prev, interests: e.target.value }))}
                        placeholder="e.g. Anime, Coding, Gaming, Late-night walks"
                        className="w-full bg-white/5 hover:bg-white/[0.08] focus:bg-black border border-white/10 focus:border-purple-500/65 rounded-xl px-4 py-2.5 font-sans text-sm text-gray-100 outline-none transition-all"
                      />
                    </div>

                    {/* Field: Custom Notes */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-widest text-indigo-300">Mahi's Custom Memories (Special Facts)</label>
                      <textarea
                        value={prefsState.customNotes}
                        onChange={(e) => setPrefsState(prev => ({ ...prev, customNotes: e.target.value }))}
                        placeholder="Add facts here! e.g. 'Mahi knows I love black coffee', 'I wake up late', 'We discussed childhood stories tomorrow'."
                        rows={3}
                        className="w-full bg-white/5 hover:bg-white/[0.08] focus:bg-black border border-white/10 focus:border-purple-500/65 rounded-xl px-4 py-2.5 font-sans text-sm text-gray-100 outline-none transition-all resize-none"
                      />
                    </div>

                    {/* Actions */}
                    <div className="pt-3">
                      <motion.button
                        onClick={handleSavePreferences}
                        disabled={isSavingPrefs}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="w-full bg-linear-to-r from-purple-600 to-pink-600 disabled:from-gray-700 disabled:to-gray-800 text-white font-mono uppercase tracking-widest text-xs py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-purple-500/20"
                      >
                        {isSavingPrefs ? (
                          <span>Syncing...</span>
                        ) : saveSuccess ? (
                          <div className="flex items-center gap-1.5">
                            <Sparkles size={14} className="text-yellow-300 animate-bounce" />
                            <span className="text-yellow-200">Synced to Brain!</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Save size={14} />
                            <span>Save Brain Preferences</span>
                          </div>
                        )}
                      </motion.button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pastSessions.length === 0 ? (
                      <div className="text-center py-12 space-y-3">
                        <Clock className="w-10 h-10 text-gray-600 mx-auto animate-pulse" />
                        <p className="text-xs text-gray-500">Mahi does not have any saved chat memories yet. Start talking to let her remember your logs!</p>
                      </div>
                    ) : (
                      pastSessions.map((session) => {
                        const isExpanded = expandedSessionId === session.id;
                        return (
                          <div 
                            key={session.id}
                            className="bg-white/[0.03] border border-white/5 hover:border-white/10 rounded-xl transition-all overflow-hidden"
                          >
                            {/* Session Header */}
                            <div 
                              onClick={() => setExpandedSessionId(isExpanded ? null : (session.id || null))}
                              className="p-4 flex justify-between items-center cursor-pointer hover:bg-white/[0.02]"
                            >
                              <div className="space-y-1">
                                <div className="text-sm font-semibold text-gray-200 hover:text-white flex items-center gap-2">
                                  <Clock size={12} className="text-purple-400" />
                                  <span>{session.sessionName}</span>
                                </div>
                                <div className="text-[10px] font-mono text-gray-500">
                                  {session.messages?.length || 0} Message exchanges logged
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={(e) => handleDeleteSession(session.id || '', e)}
                                  className="p-1 px-2.5 bg-red-950/20 hover:bg-red-950/40 border border-red-500/20 rounded-lg text-red-400 hover:text-red-300 transition-all cursor-pointer"
                                  title="Forget memory session"
                                >
                                  <Trash2 size={12} />
                                </button>
                                <span className="text-gray-400">
                                  {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                                </span>
                              </div>
                            </div>

                            {/* Collapsible content (transcripts) */}
                            <AnimatePresence>
                              {isExpanded && (
                                <motion.div 
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: 'auto', opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  className="border-t border-white/5 bg-black/40 p-4 space-y-3 max-h-72 overflow-y-auto scrollbar-thin"
                                >
                                  {(!session.messages || session.messages.length === 0) ? (
                                    <p className="text-[10px] font-mono text-gray-500 italic text-center">No dialogues logged in this session.</p>
                                  ) : (
                                    session.messages.map((m, mIdx) => (
                                      <div 
                                        key={mIdx} 
                                        className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
                                      >
                                        <span className="text-[9px] font-mono opacity-40 mb-0.5">
                                          {m.sender === 'user' ? (prefsState?.nickname || 'Dipak') : 'Mahi'}
                                        </span>
                                        <div 
                                          className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${
                                            m.sender === 'user' 
                                              ? 'bg-purple-600/20 text-purple-200 border border-purple-500/20 rounded-tr-none' 
                                              : 'bg-white/5 text-gray-200 border border-white/5 rounded-tl-none'
                                          }`}
                                        >
                                          {m.text}
                                        </div>
                                      </div>
                                    ))
                                  )}
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        );
                      })
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </Fragment>
        )}
      </AnimatePresence>
    </div>
  );
}
