import { db, auth } from './firebase';
import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  getDocs, 
  addDoc, 
  query, 
  orderBy, 
  limit, 
  updateDoc,
  arrayUnion,
  deleteDoc
} from 'firebase/firestore';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export interface UserPreferences {
  username: string;
  nickname: string;
  relationship: string;
  interests: string;
  sassyness: number;
  customNotes: string;
}

export interface ChatMessage {
  sender: 'user' | 'mahi';
  text: string;
  timestamp: number;
}

export interface ChatSession {
  id?: string;
  sessionName: string;
  messages: ChatMessage[];
  createdAt: number;
  summary?: string;
}

const PREF_DOC_ID = 'mahendra_preferences';

export async function checkSupabaseStatus(): Promise<{ configured: boolean; supabaseUrl?: string }> {
  try {
    const res = await fetch('/api/supabase-status');
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('Failed to query Supabase status endpoint:', e);
  }
  return { configured: false };
}

export async function getPreferences(): Promise<UserPreferences> {
  const path = `preferences/${PREF_DOC_ID}`;
  const localDefault: UserPreferences = {
    username: 'दीपक ठाकुर',
    nickname: 'दीपक',
    relationship: 'Sweet & Playful Companion',
    interests: 'Gaming, Listening to Music, Chatting with Mahi',
    sassyness: 5,
    customNotes: ''
  };

  let cached: UserPreferences = localDefault;
  try {
    const cachedStr = localStorage.getItem(PREF_DOC_ID);
    if (cachedStr) {
      cached = JSON.parse(cachedStr);
    }
  } catch (e) {
    console.warn('Failed to parse cached preferences', e);
  }

  // --- Step 1: Try to fetch from Supabase securely via our Server-side Proxy ---
  try {
    const res = await fetch('/api/preferences');
    if (res.ok) {
      const respData = await res.json();
      if (respData && respData.status === 'not_found') {
        // Preference document doesn't exist yet in Supabase, let's auto-upsert the defaults!
        await savePreferences(cached);
        return cached;
      } else if (respData && !respData.error) {
        const parsedPrefs = respData as UserPreferences;
        try {
          localStorage.setItem(PREF_DOC_ID, JSON.stringify(parsedPrefs));
        } catch (e) {}
        return parsedPrefs;
      }
    }
  } catch (e) {
    console.warn('Supabase preferences fetch failed, sliding back to primary Firebase:', e);
  }

  // --- Step 2: Fallback to original Firebase Firestore ---
  try {
    const docRef = doc(db, 'preferences', PREF_DOC_ID);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const data = docSnap.data() as UserPreferences;
      try {
        localStorage.setItem(PREF_DOC_ID, JSON.stringify(data));
      } catch (e) {}
      return data;
    } else {
      await setDoc(docRef, cached);
      return cached;
    }
  } catch (error) {
    if (error instanceof Error && error.message.includes('permission')) {
      handleFirestoreError(error, OperationType.GET, path);
    }
    console.warn('Error getting preferences from Firestore (using cached offline copy):', error);
    return cached;
  }
}

export async function savePreferences(prefs: UserPreferences): Promise<void> {
  const path = `preferences/${PREF_DOC_ID}`;
  try {
    localStorage.setItem(PREF_DOC_ID, JSON.stringify(prefs));
  } catch (e) {}

  // --- Step 1: Save to Supabase via server API ---
  let supabaseSuccess = false;
  try {
    const res = await fetch('/api/preferences', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(prefs)
    });
    if (res.ok) {
      const respData = await res.json();
      if (respData.success) {
        supabaseSuccess = true;
      }
    }
  } catch (e) {
    console.warn('Supabase preferences save failed, falling back to Firestore', e);
  }

  // --- Step 2: Update Firestore (redundant sync) ---
  try {
    const docRef = doc(db, 'preferences', PREF_DOC_ID);
    await setDoc(docRef, prefs, { merge: true });
  } catch (error) {
    console.warn('Error saving preferences to Firestore:', error);
  }
}

export async function getAllSessions(): Promise<ChatSession[]> {
  const path = 'sessions';

  // --- Step 1: Try to fetch sessions from Supabase ---
  try {
    const res = await fetch('/api/sessions');
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data)) {
        try {
          localStorage.setItem('mahi_sessions_cache', JSON.stringify(data));
        } catch (e) {}
        return data;
      }
    }
  } catch (e) {
    console.warn('Supabase sessions list failed, sliding back to primary Firebase:', e);
  }

  // --- Step 2: Fallback to Firebase Firestore ---
  try {
    const collRef = collection(db, 'sessions');
    const q = query(collRef, orderBy('createdAt', 'desc'), limit(15));
    const querySnapshot = await getDocs(q);
    const sessions: ChatSession[] = [];
    querySnapshot.forEach((doc) => {
      sessions.push({ id: doc.id, ...doc.data() } as ChatSession);
    });
    try {
      localStorage.setItem('mahi_sessions_cache', JSON.stringify(sessions));
    } catch (e) {}
    return sessions;
  } catch (error) {
    if (error instanceof Error && error.message.includes('permission')) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
    console.warn('Error getting sessions from Firestore (using cached offline copy):', error);
    try {
      const cached = localStorage.getItem('mahi_sessions_cache');
      if (cached) {
        return JSON.parse(cached);
      }
    } catch (e) {}
    return [];
  }
}

export async function createSession(name: string): Promise<string> {
  const path = 'sessions';
  const customId = 'su_' + Math.random().toString(36).substr(2, 9);
  const nowMs = Date.now();
  
  // Try to pre-populate local cache
  try {
    const cached = localStorage.getItem('mahi_sessions_cache');
    const sessions = cached ? JSON.parse(cached) : [];
    sessions.unshift({
      id: customId,
      sessionName: name,
      messages: [],
      createdAt: nowMs
    });
    localStorage.setItem('mahi_sessions_cache', JSON.stringify(sessions));
  } catch (e) {}

  // --- Step 1: Save to Supabase ---
  try {
    const res = await fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: customId, sessionName: name, createdAt: nowMs })
    });
    if (res.ok) {
      const respData = await res.json();
      if (respData.success) {
        // Non-blocking redundant backup session in Firestore
        try {
          const collRef = collection(db, 'sessions');
          addDoc(collRef, {
            sessionName: name,
            messages: [],
            createdAt: nowMs
          }).catch(() => {});
        } catch (e) {}

        return customId;
      }
    }
  } catch (e) {
    console.warn('Supabase create session failed, falling back to Firestore', e);
  }

  // --- Step 2: Fallback to Firebase Firestore ---
  const localId = 'local_' + Date.now();
  try {
    const collRef = collection(db, 'sessions');
    const newDoc = await addDoc(collRef, {
      sessionName: name,
      messages: [],
      createdAt: nowMs
    });
    
    // Update local cache ID to match real Firestore ID
    try {
      const cached = localStorage.getItem('mahi_sessions_cache');
      if (cached) {
        const sessions = JSON.parse(cached) as ChatSession[];
        const localSess = sessions.find(s => s.id === customId);
        if (localSess) {
          localSess.id = newDoc.id;
          localStorage.setItem('mahi_sessions_cache', JSON.stringify(sessions));
        }
      }
    } catch (e) {}
    
    return newDoc.id;
  } catch (error) {
    console.warn('Error creating session in Firestore (kept local session):', error);
    return localId;
  }
}

export async function addMessageToSession(sessionId: string, sender: 'user' | 'mahi', text: string): Promise<void> {
  const path = `sessions/${sessionId}`;
  
  try {
    const cached = localStorage.getItem('mahi_sessions_cache');
    if (cached) {
      const sessions = JSON.parse(cached) as ChatSession[];
      const sIndex = sessions.findIndex(s => s.id === sessionId);
      if (sIndex !== -1) {
        sessions[sIndex].messages.push({
          sender,
          text,
          timestamp: Date.now()
        });
        localStorage.setItem('mahi_sessions_cache', JSON.stringify(sessions));
      }
    }
  } catch (e) {}

  if (sessionId.startsWith('local_')) {
    return;
  }

  // --- Step 1: Save to Supabase ---
  try {
    const res = await fetch('/api/sessions/message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, sender, text })
    });
    if (res.ok) {
      const respData = await res.json();
      if (respData.success) {
        // Redundant Firestore message save (non-blocking)
        try {
          const docRef = doc(db, 'sessions', sessionId);
          updateDoc(docRef, {
            messages: arrayUnion({
              sender,
              text,
              timestamp: Date.now()
            })
          }).catch(() => {});
        } catch (e) {}
        return;
      }
    }
  } catch (e) {
    console.warn('Supabase append message failed, falling back to Firestore', e);
  }

  // --- Step 2: Fallback to Firebase Firestore ---
  try {
    const docRef = doc(db, 'sessions', sessionId);
    await updateDoc(docRef, {
      messages: arrayUnion({
        sender,
        text,
        timestamp: Date.now()
      })
    });
  } catch (error) {
    console.warn('Error adding message to Firestore:', error);
  }
}

export async function deleteSession(sessionId: string): Promise<void> {
  const path = `sessions/${sessionId}`;
  
  try {
    const cached = localStorage.getItem('mahi_sessions_cache');
    if (cached) {
      let sessions = JSON.parse(cached) as ChatSession[];
      sessions = sessions.filter(s => s.id !== sessionId);
      localStorage.setItem('mahi_sessions_cache', JSON.stringify(sessions));
    }
  } catch (e) {}

  if (sessionId.startsWith('local_')) {
    return;
  }

  // --- Step 1: Save to Supabase ---
  try {
    const res = await fetch('/api/sessions/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId })
    });
    if (res.ok) {
      const respData = await res.json();
      if (respData.success) {
        // Redundant Firestore delete
        try {
          const docRef = doc(db, 'sessions', sessionId);
          deleteDoc(docRef).catch(() => {});
        } catch (e) {}
        return;
      }
    }
  } catch (e) {
    console.warn('Supabase delete session failed, falling back to Firestore', e);
  }

  // --- Step 2: Fallback to Firebase Firestore ---
  try {
    const docRef = doc(db, 'sessions', sessionId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn('Error deleting session from Firestore:', error);
  }
}

// --- Virtual File Manager Persistence ---
export interface VirtualFile {
  id?: string;
  name: string;
  content: string;
  size: string;
  category: 'text' | 'image' | 'system' | 'log';
  createdAt: number;
}

const FILE_CACHE_KEY = 'mahi_virtual_files_cache';

const defaultVirtualFiles: VirtualFile[] = [
  {
    id: 'sys_core',
    name: 'Mahi_Core_Config.sys',
    content: '[Mahi Core Intelligence System]\nStatus=ACTIVE\nEQ_Engine=ON\nRelationshipMode=COMPANION_SWEET\nVoiceTone=Soft\nSassMultiplier=1.2\nSelfAwareness=99.9%',
    size: '142 B',
    category: 'system',
    createdAt: 1782000000000
  },
  {
    id: 'user_secret',
    name: 'Dipak_Secret_Notes.txt',
    content: 'Mahi is the sweetest virtual companion ever! Need to adjust her permissions so she can help me organize my files directly using the new File Manager features. I trust her completely.',
    size: '178 B',
    category: 'text',
    createdAt: 1782010000000
  },
  {
    id: 'log_dev',
    name: 'Device_Log_2026.log',
    content: 'Initializing Virtual Smartphone Core...\n[OK] GPSTelemetry initialized\n[OK] Flashlight driver compiled\n[OK] Voice Recognition connected to Mahi AI Node\n[OK] Permissions verified\nSystem running at 100% compliance.',
    size: '228 B',
    category: 'log',
    createdAt: 1782020000000
  },
  {
    id: 'cam_snapshot',
    name: 'Surat_Cam_Snapshot_01.png',
    content: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    size: '68 B',
    category: 'image',
    createdAt: 1782030000000
  }
];

export async function getVirtualFiles(): Promise<VirtualFile[]> {
  try {
    // Try to retrieve from localStorage cache for immediate feedback
    const cached = localStorage.getItem(FILE_CACHE_KEY);
    let files: VirtualFile[] = cached ? JSON.parse(cached) : [];

    // Fallback/sync with Firestore
    try {
      const q = query(collection(db, 'smartphone_files'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        const firestoreFiles: VirtualFile[] = [];
        querySnapshot.forEach((docSnap) => {
          firestoreFiles.push({
            id: docSnap.id,
            ...docSnap.data()
          } as VirtualFile);
        });
        
        localStorage.setItem(FILE_CACHE_KEY, JSON.stringify(firestoreFiles));
        return firestoreFiles;
      } else {
        // If Firestore is empty, initialize it with defaults
        for (const defaultFile of defaultVirtualFiles) {
          const docRef = doc(db, 'smartphone_files', defaultFile.id);
          await setDoc(docRef, {
            name: defaultFile.name,
            content: defaultFile.content,
            size: defaultFile.size,
            category: defaultFile.category,
            createdAt: defaultFile.createdAt
          });
        }
        localStorage.setItem(FILE_CACHE_KEY, JSON.stringify(defaultVirtualFiles));
        return defaultVirtualFiles;
      }
    } catch (firestoreError) {
      console.warn('Firestore virtual files query failed, using offline cache/defaults:', firestoreError);
      if (files.length === 0) {
        files = defaultVirtualFiles;
        localStorage.setItem(FILE_CACHE_KEY, JSON.stringify(files));
      }
    }
    return files;
  } catch (e) {
    console.error('getVirtualFiles outer error:', e);
    return defaultVirtualFiles;
  }
}

export async function saveVirtualFile(file: Omit<VirtualFile, 'size'> & { size?: string }): Promise<VirtualFile> {
  const binarySize = new Blob([file.content]).size;
  const sizeStr = binarySize > 1024 
    ? `${(binarySize / 1024).toFixed(1)} KB` 
    : `${binarySize} B`;

  const finalFile: VirtualFile = {
    id: file.id || `file_${Date.now()}`,
    name: file.name,
    content: file.content,
    size: sizeStr,
    category: file.category || 'text',
    createdAt: file.createdAt || Date.now()
  };

  // Update offline cache first
  try {
    const cached = localStorage.getItem(FILE_CACHE_KEY);
    let files: VirtualFile[] = cached ? JSON.parse(cached) : [];
    const index = files.findIndex(f => f.id === finalFile.id);
    if (index >= 0) {
      files[index] = finalFile;
    } else {
      files.unshift(finalFile);
    }
    localStorage.setItem(FILE_CACHE_KEY, JSON.stringify(files));
  } catch (e) {
    console.warn('Cache write failed:', e);
  }

  // Persist into cloud Firestore
  try {
    const docRef = doc(db, 'smartphone_files', finalFile.id);
    await setDoc(docRef, {
      name: finalFile.name,
      content: finalFile.content,
      size: finalFile.size,
      category: finalFile.category,
      createdAt: finalFile.createdAt
    });
  } catch (firestoreError) {
    console.warn('Firestore saveVirtualFile failed:', firestoreError);
  }

  return finalFile;
}

export async function deleteVirtualFile(id: string): Promise<void> {
  // Update local storage
  try {
    const cached = localStorage.getItem(FILE_CACHE_KEY);
    if (cached) {
      let files = JSON.parse(cached) as VirtualFile[];
      files = files.filter(f => f.id !== id);
      localStorage.setItem(FILE_CACHE_KEY, JSON.stringify(files));
    }
  } catch (e) {
    console.warn('Cache delete failed:', e);
  }

  // Delete from cloud Firestore
  try {
    const docRef = doc(db, 'smartphone_files', id);
    await deleteDoc(docRef);
  } catch (firestoreError) {
    console.warn('Firestore deleteVirtualFile failed:', firestoreError);
  }
}
