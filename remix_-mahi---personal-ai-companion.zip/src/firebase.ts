import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, initializeFirestore, setLogLevel } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Silence distracting "Could not reach Cloud Firestore backend" warning/info logs in sandboxed iframe previews
try {
  setLogLevel('error');
} catch (e) {
  console.warn('Could not set firestore log level:', e);
}

// Initialize Firestore with the dedicated database ID and long polling
const db = initializeFirestore(app, {
  experimentalForceLongPolling: true
}, firebaseConfig.firestoreDatabaseId || '(default)');

const auth = getAuth(app);

export { app, db, auth };


