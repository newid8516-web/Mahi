-- ==========================================================
-- MAHI - SUPABASE DATABASE SCHEMA SETUP
-- copy and paste this script into your Supabase project SQL Editor
-- to create the tables required for persistent user preferences and chat memories.
-- ==========================================================

-- 1. Tablename: user_preferences
-- Stores the custom nickname, relationship types, interests, and sassy levels.
CREATE TABLE IF NOT EXISTS public.user_preferences (
    id TEXT PRIMARY KEY DEFAULT 'mahendra_preferences',
    username TEXT NOT NULL DEFAULT 'दीपक ठाकुर',
    nickname TEXT NOT NULL DEFAULT 'दीपक',
    relationship TEXT NOT NULL DEFAULT 'Sweet & Playful Companion',
    interests TEXT NOT NULL DEFAULT 'Gaming, Listening to Music, Chatting with Mahi',
    sassyness INTEGER NOT NULL DEFAULT 5,
    custom_notes TEXT DEFAULT '',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;

-- Create policies so anyone can read/write the single configuration row safely
CREATE POLICY "Allow anonymous read check" ON public.user_preferences
    FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Allow anonymous update modify" ON public.user_preferences
    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- 2. Tablename: chat_sessions
-- Stores conversation histories / memory lines.
CREATE TABLE IF NOT EXISTS public.chat_sessions (
    id TEXT PRIMARY KEY,
    session_name TEXT NOT NULL,
    messages JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at BIGINT NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;

-- Create policies so anyone can read/update chat history data safely
CREATE POLICY "Allow anonymous read select on sessions" ON public.chat_sessions
    FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Allow anonymous all actions on sessions" ON public.chat_sessions
    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- Insert original default preferences row
INSERT INTO public.user_preferences (id, username, nickname, relationship, interests, sassyness, custom_notes)
VALUES ('mahendra_preferences', 'दीपक ठाकुर', 'दीपक', 'Sweet & Playful Companion', 'Gaming, Listening to Music, Chatting with Mahi', 5, '')
ON CONFLICT (id) DO NOTHING;
